import{a as t}from"./index-1ubonxNq.js";async function n(){const{data:a}=await t.get("/employees/reporting-managers");return a}export{n as l};
