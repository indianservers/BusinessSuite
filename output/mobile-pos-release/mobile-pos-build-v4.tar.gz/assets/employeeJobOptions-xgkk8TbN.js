import{a as t}from"./index-BA7kg7DB.js";async function n(){const{data:a}=await t.get("/employees/reporting-managers");return a}export{n as l};
