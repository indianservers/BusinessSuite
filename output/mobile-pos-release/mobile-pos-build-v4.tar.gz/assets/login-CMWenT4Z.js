import{s as i}from"./index-BA7kg7DB.js";function o(t){return i(t)||"/dashboard"}export{o as l};
