import{s as i}from"./index-si6BVSwJ.js";function o(t){return i(t)||"/dashboard"}export{o as l};
