import{a as t}from"./index-d_ul-X9Q.js";async function n(){const{data:a}=await t.get("/employees/reporting-managers");return a}export{n as l};
