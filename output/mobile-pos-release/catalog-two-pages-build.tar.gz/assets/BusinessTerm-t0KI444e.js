import{ag as n}from"./index-d_ul-X9Q.js";function m({name:s,plural:e=!1}){const{term:r}=n();return r(s,e)}export{m as B};
