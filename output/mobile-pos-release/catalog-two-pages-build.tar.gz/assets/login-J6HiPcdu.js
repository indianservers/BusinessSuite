import{s as i}from"./index-d_ul-X9Q.js";function o(t){return i(t)||"/dashboard"}export{o as l};
