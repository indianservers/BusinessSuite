import{ag as n}from"./index-nIAZnTco.js";function m({name:s,plural:e=!1}){const{term:r}=n();return r(s,e)}export{m as B};
