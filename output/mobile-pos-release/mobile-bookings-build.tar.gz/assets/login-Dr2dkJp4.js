import{s as i}from"./index-nIAZnTco.js";function o(t){return i(t)||"/dashboard"}export{o as l};
