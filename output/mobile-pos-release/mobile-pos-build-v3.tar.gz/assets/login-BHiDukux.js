import{s as i}from"./index-C75rGpfe.js";function o(t){return i(t)||"/dashboard"}export{o as l};
