import { ActionToolbar } from "@/components/actions";
import { NativeSelect } from "@/components/ui/native-select";
import HRTransfer from "./HRTransfer";
import {useState} from "react";

import {Link, useNavigate} from "react-router-dom";

import {useQuery,useQueryClient} from "@tanstack/react-query";

import {api} from "@/services/api";

import {Button} from "@/components/ui/button";

import {Input} from "@/components/ui/input";

import {Dialog,DialogContent,DialogTitle} from "@/components/ui/dialog";

import {HR,errorText} from "./shared";
import { openPerson } from "@/apps/project-management/components/people/peopleTypes";



export default function EmployeeActions({id,changed}:{id:number;changed?:()=>void}){
 const navigate=useNavigate();

 const [transfer,setTransfer]=useState(false);
 const qc=useQueryClient(),[action,setAction]=useState(""),[reason,setReason]=useState(""),[lastDay,setLastDay]=useState(new Date().toLocaleDateString("en-CA")),[error,setError]=useState(""),[busy,setBusy]=useState(false),[notice,setNotice]=useState("");

 const query=useQuery({queryKey:["hr-person-actions",id],queryFn:()=>api.get<any>(`${HR}/people/${id}`).then(r=>r.data)});

 const checklist=useQuery({queryKey:["hr-lifecycle-checklist",id],queryFn:()=>api.get<any>(`${HR}/people/${id}/lifecycle-checklist`).then(r=>r.data)});

 const templates=useQuery({queryKey:["hr-onboarding-templates"],enabled:!!query.data?.permissions.edit,queryFn:()=>api.get<any>(`${HR}/onboarding-templates`).then(r=>r.data)});

 const [templateId,setTemplateId]=useState("");

 const data=query.data;

 async function apply(){setBusy(true);setError("");try{if(action.startsWith("scheduled:"))await api.post(`${HR}/people/${id}/transfers/${action.split(":")[1]}/apply`);else if(action.startsWith("joiner:")||action.startsWith("offboarding:")){const [kind,item]=action.split(":");await api.post(`${HR}/people/${id}/${kind}/${item}/complete`,{reason});}else if(action==="template")await api.post(`${HR}/people/${id}/onboarding-template`,{template_id:Number(templateId)});else if(action==="start_exit")await api.post(`${HR}/people/${id}/start-exit`,{reason,last_working_date:lastDay});else await api.post(`${HR}/people/${id}/actions`,{action,reason,version:data.version});setNotice("Employee action saved and recorded in history");setAction("");setReason("");await Promise.all([qc.invalidateQueries({queryKey:["hr-person-actions",id]}),qc.invalidateQueries({queryKey:["hr-lifecycle-checklist",id]}),qc.invalidateQueries({queryKey:["employee"]}),qc.invalidateQueries({queryKey:["hr-work-home"]})]);changed?.();}catch(e){setError(errorText(e));}finally{setBusy(false);}}

 if(query.isPending)return <p role="status">Checking employee action permissions…</p>;

 if(query.isError)return <p role="alert">{errorText(query.error)} <button onClick={()=>query.refetch()}>Retry employee actions</button></p>;

 return <section aria-label="Employee management" className="space-y-4 rounded-xl border bg-card p-4"><div className="flex flex-wrap items-start justify-between gap-3"><div><h2 className="text-lg font-semibold">Employee actions</h2><p className="text-xs">Scope: {data.scope.company} · {data.scope.branch} · {data.scope.department} · {data.employee_code}</p></div><div className="flex flex-wrap gap-2 text-sm"><span className="rounded border px-3 py-2">Employment: <strong>{data.employment_status}</strong></span><span className="rounded border px-3 py-2">Login access: <strong>{data.login_status}</strong></span></div></div><p className="text-sm">{data.user_id?<>Linked login: {data.account_email||`Account #${data.user_id}`} · <Link className="underline" to={`/hrms/employees/${id}?tab=account`}>Account details</Link></>:"This employee has no linked login. Employment records can exist without sign-in access; link an eligible account from the Account tab."}</p>

 <ActionToolbar label="Employee management actions" actions={[
 {id:"edit",available:!!data.permissions.edit,kind:"edit",label:"Edit employee",prominent:true,disabled:!data.permissions.edit,disabledReason:!data.permissions.edit ? "Employee update permission is required" : undefined,onSelect:()=>navigate(`/hrms/employees/${id}?tab=personal`)},
 {id:"membership",available:!!data.user_id,kind:"assign",label:"Add to project / workspace",prominent:true,disabled:!data.user_id,disabledReason:!data.user_id ? "Link an employee login account first" : undefined,onSelect:()=>openPerson({userId:data.user_id,compactMemberships:true})},
 {id:"transfer",available:!!data.permissions.edit,kind:"assign",label:"Transfer / Change manager",disabled:!data.permissions.edit,disabledReason:!data.permissions.edit ? "Employee update permission is required" : undefined,onSelect:()=>setTransfer(true)},
 {id:"work",kind:"task",label:"Assign work",prominent:true,onSelect:()=>navigate(`/hrms/people-work?employee_id=${id}`)},
 {id:"access",available:!!data.permissions.access,kind:"profile",label:data.login_status === "Active" ? "Suspend login" : "Reactivate login",disabled:!data.permissions.access,disabledReason:!data.permissions.access ? "Account access permission is required" : undefined,danger:data.login_status === "Active",onSelect:()=>setAction(data.login_status === "Active" ? "suspend_access" : "reactivate_access")},
 {id:"exit",available:!!data.permissions.exit && !checklist.data?.exit,kind:"review",label:"Start Exit",danger:true,disabled:!data.permissions.exit || !!checklist.data?.exit,disabledReason:checklist.data?.exit ? "An exit process already exists" : !data.permissions.exit ? "Exit management permission is required" : undefined,onSelect:()=>setAction("start_exit")},
 {id:"employment",available:!!data.permissions.terminate,kind:["Terminated","Exited","Resigned","Retired","Absconding"].includes(data.employment_status) ? "profile" : "delete",label:["Terminated","Exited","Resigned","Retired","Absconding"].includes(data.employment_status) ? "Reactivate employment" : "Terminate employment",danger:true,disabled:!data.permissions.terminate,disabledReason:!data.permissions.terminate ? "Employment lifecycle permission is required" : undefined,onSelect:()=>setAction(["Terminated","Exited","Resigned","Retired","Absconding"].includes(data.employment_status) ? "reactivate_employment" : "terminate_employment")},
 ]}/>
{!data.permissions.edit&&<p className="text-xs">Employee update permission is required to edit fields or change organizational assignments.</p>}{data.access_reason&&<p className="text-xs text-muted-foreground">{data.access_reason}</p>}<p className="text-xs text-muted-foreground">Suspend login blocks sign-in and revokes sessions; employment stays unchanged. Terminate employment ends employment and disables the linked login. Start Exit opens a checklist and does not change either status.</p>

 {notice&&<p role="status">{notice}</p>}<details><summary className="cursor-pointer font-medium">Profile completion checklist</summary><div className="mt-2 grid gap-2 sm:grid-cols-2">{data.completion.map((c:any)=><Link className="rounded border p-2 text-sm" key={c.label} to={c.url}>{c.complete?"✓":"○"} {c.label}</Link>)}</div><p className="mt-2 text-xs">Restricted personal, bank and tax fields remain masked according to your field permissions.</p></details>

 {data.permissions.edit&&<details><summary className="cursor-pointer font-medium">Apply onboarding template</summary><p className="mt-2 text-xs">Choose the department / location template appropriate to this employee. Employment-type applicability is displayed; existing completed tasks remain recorded.</p><div className="mt-2 flex flex-wrap gap-2"><NativeSelect loading={templates.isFetching} error={templates.isError} aria-label="Onboarding template" className="rounded border p-2 text-sm" value={templateId} onChange={e=>setTemplateId(e.target.value)}><option value="">Select template</option>{templates.data?.items.map((t:any)=><option key={t.id} value={t.id}>{t.name} · {t.applicable_for}</option>)}</NativeSelect><Button variant="outline" disabled={!templateId} onClick={()=>{setReason("Apply selected onboarding template");setAction("template");}}>Review template application</Button></div></details>}

 {checklist.isError&&<p role="alert">Lifecycle checklist could not load. <Button type="submit" variant="outline" onClick={()=>checklist.refetch()}>Retry</Button></p>}{checklist.data&&<details open={!!checklist.data.exit}><summary className="cursor-pointer font-medium">{checklist.data.exit?"Offboarding checklist":"Joiner checklist"}</summary><div className="mt-3 space-y-2">{(checklist.data.exit?checklist.data.offboarding:checklist.data.joiner).map((c:any)=><div className="flex flex-wrap justify-between gap-2 rounded border p-3 text-sm" key={c.id}><div><strong>{c.complete===true?"✓ ":"○ "}{c.label}</strong><p className="text-xs">{c.status||c.remarks} {c.owner_role&&`· Owner: ${c.owner_role}`}{c.owner_user_id&&` · Assigned user #${c.owner_user_id}`}{c.due&&` · Due ${c.due}`}</p></div><div className="flex gap-2"><Button asChild variant="outline"><Link className="underline" to={c.url}>Open</Link></Button>{!c.complete&&(checklist.data.exit?checklist.data.can_complete_exit:c.can_complete)&&<button className="underline" onClick={()=>{setReason("");setError("");setAction(checklist.data.exit?`offboarding:${c.id}`:`joiner:${String(c.id).split(":")[1]}`);}}>Complete item</button>}</div></div>)}{checklist.data.exit&&<div className="rounded border p-3 text-sm"><p>Exit #{checklist.data.exit.id} · {checklist.data.exit.status} · Last working day: {checklist.data.exit.last_working_date}</p><p>Login: {checklist.data.dependencies.login_active?"Still active — review access before completing exit":"Disabled / no account"}</p><p>Assets: {checklist.data.dependencies.active_assets===null?"Restricted":`${checklist.data.dependencies.active_assets} still assigned`}</p><p>Final settlement: {checklist.data.dependencies.settlement_restricted?"Payroll access required":checklist.data.dependencies.settlements.length?checklist.data.dependencies.settlements.map((s:any)=>`#${s.id} ${s.status}${s.exit_record_id===checklist.data.exit.id?" · linked to this exit":" · check exit linkage"}`).join(", "):"Not prepared"}</p><Button asChild variant="outline"><Link className="underline" to={`/hrms/fnf-settlements?employee_id=${id}`}>Open final settlement</Link></Button> · <Link className="underline" to={data.user_id?`/pms/management?view=tasks&owner=${data.user_id}`:`/hrms/people-work?employee_id=${id}`}>Task handover workspace</Link></div>}</div></details>}

 <details><summary className="cursor-pointer font-medium">Employee change timeline</summary><div className="mt-2 max-h-80 space-y-2 overflow-y-auto">{[...data.timeline].sort((a,b)=>String(b.at).localeCompare(String(a.at))).map((e:any)=><div className="border-b pb-2 text-sm" key={e.id}><strong>{e.action}</strong><p>{e.reason}</p><p className="text-xs">{e.at?new Date(e.at).toLocaleString():""} · Actor #{e.actor||"System"}{e.from&&` · ${e.from} → ${e.to}`}{e.effective_from&&` · Effective ${e.effective_from}`}</p>{e.can_apply&&<button className="underline" onClick={()=>{setReason("Apply previously reviewed scheduled transfer");setAction(`scheduled:${e.event_id}`);}}>Apply due transfer</button>}</div>)}{!data.timeline.length&&<p className="text-sm">{data.timeline_restricted?"Employee change history requires HR edit permission or the employee’s own profile.":"No lifecycle changes recorded yet."}</p>}</div></details>

 {transfer&&<HRTransfer initial={data} close={()=>setTransfer(false)} saved={()=>{void query.refetch();changed?.();}}/>}
 {action&&<Dialog open onOpenChange={open=>{if(!open&&!busy)setAction("");}}><DialogContent><DialogTitle>{({suspend_access:"Suspend login access",reactivate_access:"Reactivate login access",terminate_employment:"Terminate employment",reactivate_employment:"Reactivate employment",start_exit:"Start employee exit"} as any)[action]|| (action==="template"?"Apply onboarding template":"Complete checklist item")}</DialogTitle><p className="text-sm">{data.name} · {data.employee_code} · {data.scope.branch} · {data.scope.department}</p><p className="text-sm">{action==="reactivate_employment"?"Restore employment to Active and retain the reactivation event in history. Login stays disabled until Reactivate login is applied separately.":action.startsWith("scheduled:")?"Apply the due transfer previously reviewed for this employee. Current assignments must still match its recorded starting values.":action.startsWith("joiner:")||action.startsWith("offboarding:")?"Record completion evidence. Asset clearance and access sign-off are checked against actual assignments and login status.":action==="template"?"Apply the selected active template to this employee. Existing onboarding history is retained.":action==="terminate_employment"?"Employment ends today. The linked login is disabled and sessions are revoked. The employee record and history are retained; complete the exit checklist and final settlement separately.":action==="start_exit"?"Create one checklist for task handover, access, asset return, documentation and settlement. Employment and login stay unchanged.":action==="suspend_access"?"Block sign-in and revoke current sessions. Employment and assigned work stay unchanged.":"Restore sign-in for the linked account. Employment status is checked separately."}</p>{action==="start_exit"&&<label>Last working date<Input aria-label="Last working date" type="date" value={lastDay} onChange={e=>setLastDay(e.target.value)}/></label>}<label>Reason<Input aria-label="Action reason" value={reason} onChange={e=>setReason(e.target.value)}/></label>{error&&<p role="alert">{error}</p>}<Button disabled={busy||reason.trim().length<3} onClick={()=>void apply()}>Apply employee action</Button></DialogContent></Dialog>}

 </section>;

}
