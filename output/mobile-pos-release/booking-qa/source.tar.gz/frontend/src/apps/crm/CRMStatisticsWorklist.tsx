import CRMRowQuickActions from "./CRMRowQuickActions";
import {useModuleAction} from "@/hooks/use-module-action";
import GridTable from "@/shared/data-grid/GridTable";
import { recordPreviewProps } from "@/components/RecordQuickPreview";
import {Link,useParams,useSearchParams} from "react-router-dom";
import {useQuery} from "@tanstack/react-query";
import {api} from "@/services/api";
import {useAuthStore} from "@/store/authStore";
import {Button} from "@/components/ui/button";

type Worklist={total:number;page:number;pages:number;unit:string;context:{definition:string;period:string;timezone:string;as_of:string};items:{entity:string;id:number;name:string;status:string;due?:string;currency?:string;amount?:number}[]};
export default function CRMStatisticsWorklist(){
 const {kind}=useParams(),[params,setParams]=useSearchParams(),user=useAuthStore(s=>s.user);
 const canEdit=useModuleAction("edit");
 const page=Number(params.get("page"))||1,period=params.get("period")||"all";
 const query=useQuery({queryKey:["suite-metrics","crm-worklist",user?.id,user?.access?.companyId,kind,period,page],staleTime:0,queryFn:()=>api.get<Worklist>("/crm/statistics/records",{params:{kind,period,page,page_size:25}}).then(r=>r.data)});
 const move=(next:number)=>setParams(old=>{const copy=new URLSearchParams(old);copy.set("page",String(next));return copy});
 return <section className="space-y-4 min-w-0"><Link to="/crm/dashboard" className="text-primary underline">Back to CRM dashboard</Link><h1 className="text-2xl font-semibold">{kind==="leads"?"New leads":kind==="open-deals"?"Open deals":"Overdue follow-up commitments"}</h1><p className="text-sm text-muted-foreground">{query.data?.context.definition||"Loading reporting context…"}</p>{query.data&&<p>{query.data.total.toLocaleString()} matching {query.data.unit.toLowerCase()} · {query.data.context.period} · {query.data.context.timezone} · refreshed {new Date(query.data.context.as_of).toLocaleString()}</p>}{query.isLoading&&<p role="status">Loading full-query results…</p>}{query.isError&&<div role="alert">Could not load this scoped worklist. <Button variant="outline" onClick={()=>query.refetch()}>Retry</Button></div>}<div className="overflow-x-auto rounded-lg border"><GridTable pinActions gridId="apps/crm/CRMStatisticsWorklist:table-1" className="w-full text-left text-sm"><thead className="bg-muted"><tr>{["Record","Status","Due / expected close","Value","Quick actions"].map(h=><th key={h} className="p-3">{h}</th>)}</tr></thead><tbody>{query.data?.items.map(row=><tr {...recordPreviewProps(row)} key={row.entity+row.id} className="border-t"><td className="p-3"><Link className="text-primary underline" to={row.entity==="leads"?`/crm/leads/${row.id}`:row.entity==="deals"?`/crm/deals/${row.id}`:`/crm/tasks#task-${row.id}`}>{row.name}</Link><small className="block">{row.entity} #{row.id}</small></td><td className="p-3">{row.status}</td><td className="p-3">{row.due||"Unscheduled"}</td><td className="p-3">{row.amount==null?"—":`${row.currency||"Unknown"} ${Number(row.amount).toLocaleString()}`}</td><td><CRMRowQuickActions record={row} entity={row.entity} canEdit={canEdit} loadContact/></td></tr>)}</tbody></GridTable></div>{query.data?.total===0&&<p>No matching records in this reporting context.</p>}<div className="flex items-center gap-3"><Button variant="outline" disabled={page<=1} onClick={()=>move(page-1)}>Previous</Button><span>Page {page} of {Math.max(1,query.data?.pages||0)}</span><Button variant="outline" disabled={!query.data||page>=query.data.pages} onClick={()=>move(page+1)}>Next</Button></div></section>
}
