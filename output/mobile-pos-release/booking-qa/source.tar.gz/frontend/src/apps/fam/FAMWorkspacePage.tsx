import StockAlertSettings from "@/apps/srm/components/StockAlertSettings";
import LowStockPanel from "@/apps/srm/components/LowStockPanel";
import RetailWorkspace from "@/apps/srm/components/RetailWorkspace";
import InventoryProductionOrderForm from "./InventoryProductionOrderForm";
import InventoryBomForm from "./InventoryBomForm";
import InventoryProductionPostingForm from "./InventoryProductionPostingForm";
import InventoryPriceListForm from "./InventoryPriceListForm";
import InventoryTrackingForms from "./InventoryTrackingForms";
import PharmaInventory from "./PharmaInventory";
import InventoryLedgerMappingPage from "./InventoryLedgerMappingPage";
import "./inventory-master.css";
import InventoryItemCreateForm from "./InventoryItemCreateForm";
import InventoryMovementForm from "./InventoryMovementForm";
import InventoryProcurementForms from "./InventoryProcurementForms";
import { SmartCreateModal } from "@/shared/creation/SmartCreateModal";
import FinancialRecordLookup from "./FinancialRecordLookup";
import FinancialYearSetupGuidance from "./FinancialYearSetupGuidance";
import FinancialMobileLineEditor from "./FinancialMobileLineEditor";
import "./fam-purchase-mobile.css";
import {useMobile} from "@/components/mobile/useMobile";
import VoucherMobileLineEditor from "./VoucherMobileLineEditor";
import "./fam-voucher-mobile.css";
import { SmartCreateSection } from "@/shared/creation/SmartCreateSection";
import ModuleWorkflowBoard from "@/shared/workflow-board/ModuleWorkflowBoard";
import { LoadingState } from "@/components/ui/state";
import RecordMaintenance from "@/components/RecordMaintenance";
import {Dialog,DialogContent,DialogTitle} from "@/components/ui/dialog";
import { api } from "@/services/api";
import GroupedRecords from "@/shared/data-grid/GroupedRecords";
import { standardRecordGroups } from "@/shared/data-grid/record-group-fields";
import RecordDefinitionActions from "@/components/RecordDefinitionActions";
import { useFinanceWrite } from "./useFinanceWrite";
import { defaultFiscalYear, defaultText, defaultId, defaultDateAfter } from "@/lib/form-defaults";
import SuiteBarChart from "@/components/visuals/SuiteBarChart";
import { SuiteHeading, SuiteMetric } from "@/components/visuals/SuiteVisuals";
import GridTable from "@/shared/data-grid/GridTable";
import CompactActions from "@/components/actions/CompactActions";
import { ActionToolbar } from "@/components/actions";
import RecordSections from "@/components/RecordSections";
import { NativeSelect } from "@/components/ui/native-select";
import CompactForm, { CompactFields } from "@/components/forms/CompactForm";
import { useRecordScope } from "@/shared/records/Record360Workspace";
import { recordPreviewProps } from "@/components/RecordQuickPreview";
import { ImportWizard, DataExportButton, csvText } from "@/shared/data-transfer";
import { bankStatementFields } from "@/shared/data-transfer/fields";
import { RichTextField, RichTextContent, richTextPlainText } from "@/components/rich-text/LazyRichText";
import { useNewRecordFocus } from "@/hooks/use-new-record-focus";
import ModuleWorkflows from "@/components/app/ModuleWorkflows";
import SecondaryDetails from "@/components/app/SecondaryDetails";
import { cloneElement, forwardRef, isValidElement, useMemo, useState, type ElementType } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Link as RouterLink, useLocation, useParams, type LinkProps } from "react-router-dom";
import { Bar, BarChart, Cell, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { AlertTriangle, ArrowRight, BadgeIndianRupee, BarChart3, BookOpen, Box, Boxes, Building2, CalendarDays, Copy, FileText, GitBranch, GitCompareArrows, Landmark, Layers3, LockKeyhole, Package, Plus, Receipt, RefreshCw, RotateCcw, Save, ScrollText, Settings, ShieldCheck, Sparkles, Users, Warehouse } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "@/hooks/use-toast";
import { inventorySourceFeatures } from "@/apps/inventory/sourceCatalog";
import { srmApi } from "@/apps/srm/api";
import { syncSrmNow, useSrmRealtimeInvalidation } from "@/apps/srm/realtime";
import { famApi } from "./api";
import type { FAMRecord, FAMViewKind } from "./types";

type ViewMeta = { title: string; description: string; icon: ElementType };

// Accounting workbenches retain their financial permissions and API context.
const Link = forwardRef<HTMLAnchorElement, LinkProps>(({ to, ...props }, ref) => {
  const location = useLocation();
  const destination = location.pathname.startsWith("/fam/") && typeof to === "string" && to.startsWith("/srm/inventory")
    ? to.replace(/^\/srm\/inventory/, "/fam/inventory") : to;
  return <RouterLink ref={ref} to={destination} {...props} />;
});
Link.displayName = "FinancialWorkspaceLink";

const viewMeta: Record<FAMViewKind, ViewMeta> = {
  dashboard: { title: "FAM Dashboard", description: "India-first accounting foundation, books status, balances, and audit activity.", icon: BarChart3 },
  settings: { title: "Company Financial Settings", description: "Country, currency, GST, PAN, TAN, books start, and India statutory identifiers.", icon: Settings },
  financialYears: { title: "Financial Years", description: "Open, close, lock, and select financial years for statutory books.", icon: CalendarDays },
  chartOfAccounts: { title: "Chart of Accounts", description: "Tree view of ledger groups and ledgers by accounting nature.", icon: GitBranch },
  ledgerGroups: { title: "Ledger Groups", description: "Maintain group hierarchy, system groups, gross-profit behavior, and active status.", icon: Layers3 },
  ledgers: { title: "Ledgers", description: "General, customer, vendor, bank, cash, tax, employee, income, expense, and asset ledgers.", icon: FileText },
  openingBalances: { title: "Opening Balances", description: "Enter debit and credit balances and post only when books are balanced.", icon: BadgeIndianRupee },
  voucherTypes: { title: "Voucher Types", description: "Journal, receipt, payment, contra, sales, purchase, debit note, credit note, opening, and adjustment numbering.", icon: ScrollText },
  vouchers: { title: "Vouchers", description: "Draft, post, cancel, reverse, and clone balanced double-entry accounting vouchers.", icon: BookOpen },
  voucherNew: { title: "New Voucher", description: "Create a balanced voucher draft with debit and credit ledger lines.", icon: Plus },
  voucherDetail: { title: "Voucher Detail", description: "Review voucher lines, immutable entries, lifecycle actions, and voucher audit trail.", icon: BookOpen },
  journal: { title: "Journal Voucher", description: "Fast journal entry screen using the double-entry voucher engine.", icon: FileText },
  dayBook: { title: "Day Book", description: "Date-wise posted and draft voucher register with debit and credit totals.", icon: CalendarDays },
  ledgerEntries: { title: "Ledger Entries", description: "Immutable ledger postings created from posted vouchers.", icon: ScrollText },
  ledgerDetailEntries: { title: "Ledger Drill-Down", description: "Opening balance, debit/credit movement, closing balance, and voucher postings by ledger.", icon: ScrollText },
  parties: { title: "Parties", description: "Customer and vendor accounting masters linked to real FAM ledgers.", icon: Users },
  customers: { title: "Customers", description: "Customer ledgers, credit limits, receivables, statements, and bill-wise tracking.", icon: Users },
  vendors: { title: "Vendors", description: "Vendor ledgers, payables, statements, payment terms, and bill-wise tracking.", icon: Users },
  partyDetail: { title: "Party Detail", description: "Master data, ledger link, GST/PAN, outstanding, statements, bills, and allocations.", icon: Users },
  ar: { title: "Accounts Receivable", description: "Customer outstanding, aging, credit terms, and bill-wise receivables.", icon: BadgeIndianRupee },
  arAging: { title: "AR Aging", description: "Not due, 0-30, 31-60, 61-90, 91-180, and >180 receivable buckets.", icon: BadgeIndianRupee },
  arOutstanding: { title: "AR Outstanding", description: "Party-wise and bill-wise receivables driven by FAM bill references.", icon: BadgeIndianRupee },
  ap: { title: "Accounts Payable", description: "Vendor outstanding, aging, payment terms, and bill-wise payables.", icon: Landmark },
  apAging: { title: "AP Aging", description: "Not due, 0-30, 31-60, 61-90, 91-180, and >180 payable buckets.", icon: Landmark },
  apOutstanding: { title: "AP Outstanding", description: "Party-wise and bill-wise payables driven by FAM bill references.", icon: Landmark },
  billReferences: { title: "Bill References", description: "Invoice, bill, debit note, credit note, opening, and advance references.", icon: FileText },
  billAllocations: { title: "Bill Allocations", description: "Receipt/payment/credit/debit note/advance/write-off allocation foundation.", icon: ScrollText },
  srmIntegration: { title: "SRM Accounting Integration", description: "Post SRM invoices, receipts, allocations, collections, and reversals into FAM statutory books.", icon: Copy },
  postingJobs: { title: "Posting Jobs", description: "SRM to FAM posting queue, status, linked vouchers, retry state, and errors.", icon: RotateCcw },
  postingJobDetail: { title: "Posting Job Detail", description: "Source SRM record, FAM mappings, retry state, voucher link, and accounting status.", icon: RotateCcw },
  postingRules: { title: "Posting Rules", description: "Configure source transaction ledger rules for SRM accounting postings.", icon: Settings },
  banking: { title: "Banking", description: "Ledger-driven bank accounts, statements, matching, reconciliation, bank book, cash book, charges, and contra.", icon: Landmark },
  bankAccounts: { title: "Bank Accounts", description: "Bank masters linked to FAM bank ledgers with masked account numbers and IFSC.", icon: Landmark },
  paymentModes: { title: "Payment Modes", description: "Cash, cheque, NEFT, RTGS, UPI, card, wallet, and other payment modes linked to ledgers.", icon: BadgeIndianRupee },
  bankStatements: { title: "Bank Statements", description: "Manual CSV/imported bank statements with duplicate prevention and no automatic posting.", icon: FileText },
  bankStatementDetail: { title: "Bank Statement Detail", description: "Review statement lines, auto-match suggestions, manual matching, ignored lines, and reconciliation readiness.", icon: FileText },
  bankReconciliation: { title: "Bank Reconciliation", description: "Book balance, statement balance, unreconciled items, sessions, and reconciliation status.", icon: ShieldCheck },
  bankBook: { title: "Bank Book", description: "Ledger-driven bank book with opening, debit, credit, closing, and voucher drill-down rows.", icon: BookOpen },
  cashBook: { title: "Cash Book", description: "Ledger-driven cash book and cash register balances.", icon: BookOpen },
  contra: { title: "Contra", description: "Post bank-to-cash, cash-to-bank, or bank-to-bank transfers through FAM contra vouchers.", icon: RotateCcw },
  bankCharges: { title: "Bank Charges", description: "Post bank fees as payment vouchers against bank and expense ledgers.", icon: BadgeIndianRupee },
  gst: { title: "India GST", description: "GST registrations, rates, HSN/SAC, registers, returns, e-invoice, e-way bill, and reconciliation readiness.", icon: ShieldCheck },
  gstSettings: { title: "GST Settings", description: "GST compliance settings are configurable; portal providers remain clearly not configured until credentials exist.", icon: Settings },
  gstRegistrations: { title: "GST Registrations", description: "Company GSTIN, state, legal name, trade name, registration type, and effective date.", icon: Landmark },
  gstRates: { title: "GST Rates", description: "Versioned CGST, SGST, IGST, and cess rates with effective dates.", icon: BadgeIndianRupee },
  gstHsnSac: { title: "HSN/SAC Master", description: "India HSN/SAC codes linked to configurable GST rates.", icon: FileText },
  gstSalesRegister: { title: "GST Sales Register", description: "Outward GST transaction lines reconciled to FAM voucher/accounting data.", icon: ScrollText },
  gstPurchaseRegister: { title: "GST Purchase Register", description: "Inward, import, and reverse-charge GST transaction lines with ITC flags.", icon: ScrollText },
  gstr1: { title: "GSTR-1 Framework", description: "Prepare working GSTR-1 records from GST sales register data; no fake portal filing.", icon: FileText },
  gstr3b: { title: "GSTR-3B Framework", description: "Prepare working GSTR-3B summary from outward tax and eligible ITC data.", icon: FileText },
  gstReconciliation: { title: "GST Reconciliation", description: "Foundation for books-to-return and portal reconciliation exceptions.", icon: ShieldCheck },
  einvoice: { title: "E-Invoice Readiness", description: "Provider settings and IRN job placeholders; actions show not configured without credentials.", icon: FileText },
  ewaybill: { title: "E-Way Bill Readiness", description: "Threshold, transporter, vehicle, and job placeholders; no fake EWB generation.", icon: FileText },
  purchases: { title: "Purchases", description: "Vendor bills, expense vouchers, TDS deductions, purchase register, and AP readiness for India.", icon: Landmark },
  purchaseBills: { title: "Vendor Purchase Bills", description: "Create, review, post, cancel, and track vendor bills with GST input and TDS deductions.", icon: FileText },
  purchaseBillNew: { title: "New Purchase Bill", description: "Capture vendor bill lines, GST input tax, TDS section, due date, and payable amount.", icon: Plus },
  purchaseBillDetail: { title: "Purchase Bill Detail", description: "Review bill totals, accounting voucher link, TDS transactions, audit trail, and posting actions.", icon: FileText },
  expenses: { title: "Expenses", description: "Employee and operational expense claims posted through the FAM voucher engine.", icon: BadgeIndianRupee },
  expenseNew: { title: "New Expense Claim", description: "Capture expense lines and post approved expenses into statutory books.", icon: Plus },
  tds: { title: "TDS", description: "Configurable India TDS sections, rates, deductions, payable position, and transaction register.", icon: ShieldCheck },
  tdsSections: { title: "TDS Sections", description: "Maintain section codes, default rates, thresholds, effective dates, and active flags.", icon: Settings },
  tdsTransactions: { title: "TDS Transactions", description: "Deducted, paid, and reversed TDS entries linked to vouchers and vendors.", icon: ScrollText },
  tdsPayable: { title: "TDS Payable", description: "TDS payable by section and vendor without pretending return filing is integrated.", icon: BadgeIndianRupee },
  purchaseRegister: { title: "Purchase Register", description: "Posted and draft vendor bills with GST input and TDS tracked separately.", icon: BookOpen },
  expenseRegister: { title: "Expense Register", description: "Expense claims and posted vouchers by employee, claim date, and status.", icon: BookOpen },
  vendorPayments: { title: "Vendor Payments", description: "Prepare and post vendor payment runs against AP bills through bank or cash ledgers.", icon: Landmark },
  payablesDashboard: { title: "Payables Dashboard", description: "Vendor outstanding, AP aging buckets, draft bills, posted bills, and paid bills.", icon: BarChart3 },
  inventory: { title: "Inventory", description: "Merged AI Inventory Management Software capabilities inside FAM statutory books.", icon: Package },
  inventoryAccounting: { title: "Inventory Accounting", description: "Inventory valuation, GL, GRNI, COGS, GST and item ledger mapping controls.", icon: Landmark },
  inventoryDashboard: { title: "Inventory Dashboard", description: "Stock value, low-stock alerts, warehouses, and recent stock movements.", icon: Package },
  inventoryItems: { title: "Stock Items", description: "GST-ready item master with HSN, units, stock groups, reorder levels, rates, and valuation ledgers.", icon: Package },
  inventoryProducts: { title: "Products & Barcodes", description: "Operational product master with SKU, barcode, rates, tax, stock tracking, and labels.", icon: Package },
  inventoryItemDetail: { title: "Stock Item Detail", description: "Item master, stock quantity, valuation, and latest item ledger entries.", icon: Package },
  inventoryLedgerMapping: { title: "Item Ledger Mapping", description: "Map stock item ledgers for inventory asset, purchases, sales, COGS, GRNI, GST, branch and valuation.", icon: GitBranch },
  inventoryCategories: { title: "Inventory Categories", description: "Category view mapped to FAM stock groups from the source inventory app.", icon: Layers3 },
  inventoryStockGroups: { title: "Stock Groups", description: "Hierarchical inventory groups for item classification.", icon: Layers3 },
  inventoryUnits: { title: "Units of Measure", description: "Units, symbols, and decimal settings for stock items.", icon: FileText },
  inventoryWarehouses: { title: "Warehouses", description: "Warehouse masters linked to FAM branches and stock movements.", icon: Building2 },
  inventoryStockIn: { title: "Stock In", description: "Post inward stock movements using the FAM inventory ledger.", icon: Plus },
  inventoryStockOut: { title: "Stock Out", description: "Post outward stock movements with stock availability validation.", icon: RotateCcw },
  inventoryStockTransfers: { title: "Stock Transfers", description: "Move stock between warehouses with idempotent posted movement records.", icon: RotateCcw },
  inventoryStockAdjustments: { title: "Stock Adjustments", description: "Post stock gains/losses and optional accounting vouchers.", icon: ShieldCheck },
  inventoryOpeningStock: { title: "Opening Stock", description: "Capture opening balances for operational stock and warehouse quantities.", icon: Package },
  inventoryPurchaseReceipts: { title: "Purchase Receipts", description: "Receive purchased items into inventory without duplicating purchase bill accounting.", icon: Landmark },
  inventoryDeliveryNotes: { title: "Delivery Notes", description: "Issue stock for delivery and keep inventory movement evidence.", icon: FileText },
  inventoryBatches: { title: "Batches & Serials", description: "Batch, expiry, and serial tracking source map for controlled inventory.", icon: ShieldCheck },
  inventoryPriceLists: { title: "Price Lists", description: "Price list source map for customer, segment, and channel pricing.", icon: Receipt },
  inventoryPurchaseOrders: { title: "Purchase Orders", description: "Procurement source map for replenishment orders, vendor fulfilment, and GRN handoff.", icon: Receipt },
  inventoryManufacturing: { title: "Manufacturing", description: "Manufacturing source map for BOM, assembly, repacking, and production orders.", icon: Layers3 },
  inventoryStockSummary: { title: "Stock Summary", description: "Item-wise quantity, average cost, stock value, and low-stock flags.", icon: BookOpen },
  inventoryItemLedger: { title: "Item Ledger", description: "Movement lines, balances, rates, and values for a stock item.", icon: ScrollText },
  inventoryWarehouseStock: { title: "Warehouse Stock", description: "Warehouse-wise stock quantities and values from posted inventory movements.", icon: Building2 },
  inventoryStockAging: { title: "Stock Aging", description: "Age inventory by last stock movement date to identify slow-moving stock.", icon: ScrollText },
  inventoryReorderReport: { title: "Reorder Report", description: "Items below reorder and minimum levels with available quantity after reservations.", icon: AlertTriangle },
  inventoryDeadStock: { title: "Dead Stock", description: "Items with no recent movement based on audited inventory ledger activity.", icon: AlertTriangle },
  inventoryFastSlowMoving: { title: "Fast/Slow Moving Items", description: "Rank items by outward movement quantity for velocity analysis.", icon: BarChart3 },
  inventoryValuation: { title: "Inventory Valuation", description: "Weighted-average valuation layers and total inventory value.", icon: BarChart3 },
  inventoryGrossMargin: { title: "Gross Margin", description: "Inventory revenue, COGS, and gross margin by item.", icon: BadgeIndianRupee },
  inventoryReconciliation: { title: "Inventory Reconciliation", description: "Inventory-to-GL and Inventory-to-SRM reconciliation checks.", icon: ShieldCheck },
  inventoryReconciliationGl: { title: "Inventory to GL", description: "Reconcile inventory valuation total with inventory asset ledger balance.", icon: ShieldCheck },
  inventoryReconciliationGrni: { title: "GRNI Reconciliation", description: "Compare goods received not invoiced with purchase bill evidence.", icon: ShieldCheck },
  inventoryReconciliationCogs: { title: "COGS Reconciliation", description: "Compare stock issue value with posted COGS vouchers.", icon: ShieldCheck },
  inventoryReconciliationGst: { title: "GST Item Reconciliation", description: "Check stock item HSN/GST mappings against GST item register readiness.", icon: ShieldCheck },
  inventoryCogs: { title: "COGS Report", description: "Delivery and stock issue value with COGS voucher posting evidence.", icon: BadgeIndianRupee },
  inventoryGrni: { title: "GRNI", description: "Goods received not invoiced outstanding and clearing status.", icon: Landmark },
  inventoryHsnSummary: { title: "HSN Summary", description: "Item-wise HSN grouping, quantity, value, and GST readiness.", icon: ScrollText },
  inventoryAudit: { title: "Inventory Audit", description: "Audit trail for stock postings, reservations, controls, and integration links.", icon: ScrollText },
  inventoryCrmLink: { title: "CRM Inventory Link", description: "CRM product catalog links, stock availability, reorder status, and margin signals.", icon: Package },
  inventorySrmLink: { title: "SRM Inventory Link", description: "SRM reservations, posted inventory movements, and duplicate deduction controls.", icon: Package },
  inventoryReorderAlerts: { title: "Reorder Alerts", description: "Items at or below reorder/minimum stock thresholds.", icon: AlertTriangle },
  inventoryReports: { title: "Inventory Reports", description: "Stock summary, valuation, reorder alerts, and generated report audit evidence.", icon: BarChart3 },
  inventoryCompleteReports: { title: "Complete Inventory Reports", description: "Complete stock report index for valuation, reorder, expiry, movement, and velocity.", icon: BarChart3 },
  inventoryAI: { title: "Inventory AI", description: "Audited AI insight requests with honest provider readiness status.", icon: Sparkles },
  costCenters: { title: "Cost Centers", description: "Track accounting dimensions by department, project, branch, or operating unit.", icon: Building2 },
  branches: { title: "Branches", description: "GST/location-aware branches for India-first books setup.", icon: Landmark },
  audit: { title: "Accounting Audit", description: "Trace FAM setup, chart, ledger, opening balance, and settings changes.", icon: ScrollText },
};

function money(value: unknown) {
  return Number(value || 0).toLocaleString("en-IN", { style: "currency", currency: defaultText("currency", "fam"), maximumFractionDigits: 0 });
}

function text(value: unknown) {
  if (typeof value === "string" && value.startsWith("<!--suite-richtext:v1-->")) return richTextPlainText(value);
  if (value === null || value === undefined || value === "") return "-";
  if (typeof value === "boolean") return value ? "Yes" : "No";
  if (typeof value === "number") return value.toLocaleString("en-IN");
  if (typeof value === "object") return "Linked";
  return String(value).replace(/_/g, " ");
}

function numberValue(value: unknown) {
  const amount = Number(value);
  return Number.isFinite(amount) ? amount : 0;
}

function optionalText(value: unknown) {
  if (value === null || value === undefined || value === "") return "-";
  return text(value);
}

function listItems(data: unknown): FAMRecord[] {
  if (data && typeof data === "object" && "items" in data) return ((data as { items?: FAMRecord[] }).items || []);
  return [];
}

function statusTone(value: unknown) {
  const status = String(value || "").toLowerCase();
  if (["open", "active", "posted", "ready", "configured", "passed", "matched"].includes(status)) return "default";
  if (["locked", "closed", "inactive", "not_configured", "manual_import_only", "gateway_not_connected"].includes(status)) return "secondary";
  if (["failed", "error", "overdue", "unsupported"].includes(status)) return "destructive";
  return "outline";
}

function apiErrorMessage(err: unknown, fallback = "Action failed") {
  return (err as { response?: { data?: { detail?: string } } })?.response?.data?.detail || (err as Error)?.message || fallback;
}

function downloadTextFile(fileName: string, content: string, contentType = "text/csv") {
  const blob = new Blob([content], { type: contentType });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = fileName;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  URL.revokeObjectURL(url);
}

function ExportButton({exportType,label}:{exportType:string;label?:string}) { return <DataExportButton label={label||"Export"} filename={exportType} load={async()=>{const job=await famApi.createExport({export_type:exportType,export_format:"csv",filters_json:{}}) as FAMRecord;if(job.status!=="ready")throw Error(text((job.error_json as FAMRecord|undefined)?.message||"Export is not ready"));const file=await famApi.downloadExport(String(job.id)) as FAMRecord;return new Blob([String(file.file_content||"")],{type:"text/csv"});}}/>;}

function PageHeader({ meta, isFetching, onRefresh }: { meta: ViewMeta; isFetching?: boolean; onRefresh?: () => void }) {
  return <SuiteHeading title={meta.title} icon={meta.icon} description={<RichTextContent legacyFormat="plain" value={meta.description}/>} actions={<>{onRefresh ? <Button variant="outline" onClick={onRefresh} disabled={isFetching}><RefreshCw className="h-4 w-4"/>Refresh</Button> : null}</>}/>;
}

function State({ label, isLoading, isError }: { label: string; isLoading?: boolean; isError?: boolean }) {
  if (isLoading) return <LoadingState label={`Loading ${label}`} variant="table"/>;
  if (isError) return <div className="rounded-lg border border-destructive/40 p-6 text-sm text-destructive"><AlertTriangle className="mr-2 inline h-4 w-4" />Unable to load {label}.</div>;
  return null;
}
// Keep feedback identification stable in production bundles.
State.displayName = "State";

function DashboardView() {
  const query = useQuery({ queryKey: ["fam", "dashboard"], queryFn: famApi.dashboard });
  const data = (query.data || {}) as FAMRecord;
  const baseMoney=(value:unknown)=>value==null?"Not available":data.baseCurrency?`${String(data.baseCurrency)} ${Number(value).toLocaleString(undefined,{maximumFractionDigits:2})}`:"Base currency not configured";
  const kpis: Array<[string, React.ReactNode]> = [
    ["Current FY", text((data.currentFinancialYear as FAMRecord | undefined)?.name)],
    ["Total assets", baseMoney(data.totalAssets)],
    ["Total liabilities", baseMoney(data.totalLiabilities)],
    ["Total income", baseMoney(data.totalIncome)],
    ["Total expenses", baseMoney(data.totalExpenses)],
    ["Cash and bank", baseMoney(data.cashAndBankBalance)],
    ["Receivables", baseMoney(data.receivablesOutstanding)],
    ["Payables", baseMoney(data.payablesOutstanding)],
    ["Overdue AR", baseMoney(data.overdueReceivables)],
    ["Overdue AP", baseMoney(data.overduePayables)],
  ];
  return (
    <div className="space-y-5">
      <State label="FAM dashboard" isLoading={query.isLoading} isError={query.isError} />
<ModuleWorkflows module="fam" />
      <div className="grid gap-3 md:grid-cols-4">
        {kpis.filter(([label]) => ["Cash and bank", "Receivables", "Payables", "Overdue AR"].includes(label)).map(([label, value]) => (
          <Card key={label}><SuiteMetric label={label} value={value} icon={label === "Cash and bank" ? Landmark : label === "Overdue AR" ? AlertTriangle : Receipt}/></Card>
        ))}
      </div>
      <ModuleWorkflowBoard module="fam" />
      {!query.isLoading && !query.isError && !!data.baseCurrency && [data.totalIncome, data.totalExpenses].every(value => typeof value === "number" && Number.isFinite(value)) && <SuiteBarChart title="Income and expenses" unit={String(data.baseCurrency)} data={[{name:"Income",value:Number(data.totalIncome)},{name:"Expenses",value:Number(data.totalExpenses)}]}/>}
      <SecondaryDetails title="Financial summary and books status">
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">{kpis.filter(([label]) => !["Cash and bank", "Receivables", "Payables", "Overdue AR"].includes(label)).map(([label, value]) => <div key={label} className="border-b py-3"><p className="text-xs text-muted-foreground">{label}</p><p className="mt-1 font-semibold">{value}</p></div>)}</div>
      <div className="grid gap-4 lg:grid-cols-[1fr_22rem]">
        <Card>
          <CardHeader><CardTitle className="text-base">Recent accounting activity</CardTitle></CardHeader>
          <CardContent className="space-y-2">
            {listItems({ items: data.recentAccountingActivity as FAMRecord[] || [] }).map((item) => <AuditRow key={String(item.id)} item={item} />)}
            {!(data.recentAccountingActivity as FAMRecord[] | undefined)?.length ? <p className="text-sm text-muted-foreground">No accounting activity yet.</p> : null}
          </CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle className="text-base">Books status</CardTitle></CardHeader>
          <CardContent className="space-y-3 text-sm">
            <Badge variant={statusTone(data.booksStatus)}>{text(data.booksStatus)}</Badge>
            <p className="text-muted-foreground">GST portal filing is disabled until provider credentials are configured.</p>
            <Badge variant={statusTone(data.gstComplianceStatus)}>{text(data.gstComplianceStatus)}</Badge>
            <p>{text(data.gstComplianceMessage)}</p>
          </CardContent>
        </Card>
      </div>
      </SecondaryDetails>
    </div>
  );
}

function SettingsView() {
  const queryClient = useQueryClient();
  const query = useQuery({ queryKey: ["fam", "settings"], queryFn: famApi.settings });
  const settings = (query.data || {}) as FAMRecord;
  const [draft, setDraft] = useState<FAMRecord>({});
  const effective = { ...settings, ...draft };
  const mutation = useMutation({
    mutationFn: () => famApi.updateSettings(effective),
    onSuccess: () => { toast({ title: "FAM settings saved" }); setDraft({}); queryClient.invalidateQueries({ queryKey: ["fam"] }); },
   onError: showMutationError });
  const patch = (key: string, value: unknown) => setDraft((current) => ({ ...current, [key]: value }));
  return (
    <Card>
      <CardContent className="grid gap-4 p-5 md:grid-cols-3">
        <State label="settings" isLoading={query.isLoading} isError={query.isError} />
        {[
          ["legal_name", "Legal Name"], ["trade_name", "Trade Name"], ["gstin", "GSTIN"], ["pan", "PAN"], ["tan", "TAN"], ["cin", "CIN"], ["state_code", "State Code"], ["base_currency", "Base Currency"], ["country_code", "Country"]
        ].map(([key, label]) => <Field key={key} label={label}><Input value={String(effective[key] || "")} onChange={(event) => patch(key, event.target.value)} /></Field>)}
        <Field label="Financial Year Start Month"><Input type="number" min={1} max={12} value={String(effective.financial_year_start_month || 4)} onChange={(event) => patch("financial_year_start_month", Number(event.target.value))} /></Field>
        <Field label="Books Start Date"><Input type="date" value={String(effective.books_start_date || "")} onChange={(event) => patch("books_start_date", event.target.value)} /></Field>
        <Field label="Decimal Places"><Input type="number" value={String(effective.decimal_places || 2)} onChange={(event) => patch("decimal_places", Number(event.target.value))} /></Field>
        <div className="md:col-span-3">
          <Field label="Registered Address"><textarea className="min-h-24 w-full rounded-md border bg-background px-3 py-2 text-sm" value={String(effective.registered_address || "")} onChange={(event) => patch("registered_address", event.target.value)} /></Field>
        </div>
        <div className="md:col-span-3 flex justify-end"><Button onClick={() => mutation.mutate()} disabled={mutation.isPending}>Save settings</Button></div>
      </CardContent>
    </Card>
  );
}

function DataTable({ rows, columns, renderActions, gridId="apps/fam/FAMWorkspacePage:table-1", preview=true }: { rows: FAMRecord[]; columns: string[]; renderActions?:(row:FAMRecord)=>React.ReactNode; gridId?:string; preview?:boolean }) {
  const { pathname } = useLocation();
  const detailRoutes: Record<string, string> = { "/fam/vouchers": "/fam/vouchers", "/fam/customers": "/fam/parties", "/fam/vendors": "/fam/parties", "/fam/parties": "/fam/parties", "/fam/purchase-bills": "/fam/purchase-bills", "/fam/expenses": "/fam/expenses", "/fam/bank-statements": "/fam/bank-statements", "/fam/posting-jobs": "/fam/posting-jobs" };
  const detailBase = /^\/(fam|srm)\/inventory\/items$/.test(pathname) ? pathname : detailRoutes[pathname];
  const definitionName=pathname==="/fam/ledger-groups"?"group_name":pathname==="/fam/ledgers"?"ledger_name":null;
  return (
    <div className="overflow-x-auto rounded-lg border">
      <GridTable gridId={gridId} className="w-full min-w-[780px] text-sm">
        <thead className="bg-muted/60 text-left text-xs uppercase text-muted-foreground"><tr>{columns.map((column) => <th key={column} className="px-3 py-2">{column.replace(/_/g, " ")}</th>)}{renderActions&&<th className="px-3 py-2">Actions</th>}{definitionName&&<th className="px-3 py-2">Ledger actions</th>}</tr></thead>
        <tbody>{rows.map((row) => <tr {...(preview?recordPreviewProps(row):{})} key={String(row.id)} className="border-t">{columns.map((column, index) => <td key={column} className="px-3 py-2">{index === 0 && detailBase && row.id ? <Link data-context-action={`Open ${pathname.split("/").pop()?.replace(/-/g, " ")} · ${text(row[column])}`} to={`${detailBase}/${row.id}`} className="text-primary underline">{text(row[column])}</Link> : column.includes("status") || column === "nature" ? <Badge variant={statusTone(row[column])}>{text(row[column])}</Badge> : ["notes","remarks","narration","description"].includes(column) ? <RichTextContent legacyFormat="plain" value={String(row[column] || "")}/> : text(row[column])}</td>)}{renderActions&&<td>{renderActions(row)}</td>}{definitionName&&<td className="flex gap-2 px-3 py-2"><RecordDefinitionActions record={row} nameField={definitionName} endpoint={`${pathname}/${row.id}`} queryKeys={["fam"]} permissions={["fam_admin","fam_chart_manage"]}/></td>}</tr>)}</tbody>
      </GridTable>
    </div>
  );
}

function ChartView() {
  const query = useQuery({ queryKey: ["fam", "chart"], queryFn: famApi.chartOfAccounts });
  const data = (query.data || {}) as { groups?: FAMRecord[]; ledgers?: FAMRecord[] };
  const ledgersByGroup = useMemo(() => new Map((data.groups || []).map((group) => [Number(group.id), (data.ledgers || []).filter((ledger) => Number(ledger.ledger_group_id) === Number(group.id))])), [data.groups, data.ledgers]);
  return (
    <div className="grid gap-4 lg:grid-cols-[22rem_1fr]">
      <Card><CardHeader><CardTitle className="text-base">Ledger group tree</CardTitle></CardHeader><CardContent className="space-y-2">
        <State label="chart of accounts" isLoading={query.isLoading} isError={query.isError} />
        {(data.groups || []).map((group) => <div key={String(group.id)} className="rounded-md border p-3"><div className="flex items-center justify-between gap-2"><span className="font-medium">{text(group.group_name)}</span><Badge variant="outline">{text(group.nature)}</Badge></div><p className="text-xs text-muted-foreground">{ledgersByGroup.get(Number(group.id))?.length || 0} ledgers {group.system_group ? "System group" : ""}</p></div>)}
      </CardContent></Card>
      <Card><CardHeader><CardTitle className="text-base">Ledgers</CardTitle></CardHeader><CardContent><DataTable rows={data.ledgers || []} columns={["ledger_code", "ledger_name", "nature", "ledger_type", "active"]} /></CardContent></Card>
    </div>
  );
}

function ListCreateView({ kind }: { kind: FAMViewKind }) {
  const queryClient = useQueryClient();
  const canWrite = useFinanceWrite(["fam_admin","fam_chart_manage"],"create");
  const config = getListConfig(kind);
  const query = useQuery({ queryKey: ["fam", kind], queryFn: config.query });
  const ledgerGroups = useQuery({ queryKey: ["fam", "ledgerGroups"], queryFn: famApi.ledgerGroups, enabled: kind === "ledgers" });
  const groups = listItems(ledgerGroups.data);
  const rows = listItems(query.data);
  const [draft, setDraft] = useState<FAMRecord>(config.initial);
  const mutation = useMutation({
    mutationFn: () => config.create(draft),
    onSuccess: () => { toast({ title: `${config.label} created` }); setDraft(config.initial); queryClient.invalidateQueries({ queryKey: ["fam"] }); },
   onError: showMutationError });
  return (
    <div className="grid gap-4 lg:grid-cols-[22rem_1fr]">
      <SmartCreateSection title={<>Create {config.label}</>} size="compact"><Card><CardHeader><CardTitle className="text-base">Create {config.label}</CardTitle></CardHeader><CardContent><form className="space-y-3" onSubmit={event => { event.preventDefault(); if (canWrite && !mutation.isPending) mutation.mutate(); }}>
        {config.fields.map((field) => kind === "ledgers" && field === "ledger_group_id" ? <Field key={field} label="Ledger group"><NativeSelect required loading={ledgerGroups.isPending} error={ledgerGroups.isError} value={String(draft.ledger_group_id || "")} onChange={event => { const group = groups.find(row => Number(row.id) === Number(event.target.value)); setDraft(current => ({ ...current, ledger_group_id: Number(event.target.value) || "", nature: group?.nature || "" })); }}><option value="">Choose ledger group</option>{groups.map(group => <option key={String(group.id)} value={String(group.id)}>{String(group.group_name)}</option>)}</NativeSelect></Field> : kind === "ledgers" && (field === "nature" || field === "ledger_type") ? <Field key={field} label={field.replace(/_/g, " ")}><NativeSelect required value={String(draft[field] || "")} onChange={event => setDraft(current => ({ ...current, [field]: event.target.value }))}><option value="">Choose {field.replace(/_/g, " ")}</option>{(field === "nature" ? ["asset", "liability", "equity", "income", "expense"] : ["general", "customer", "vendor", "bank", "cash", "tax", "employee", "asset", "liability", "income", "expense"]).map(value => <option key={value} value={value}>{value.charAt(0).toUpperCase() + value.slice(1)}</option>)}</NativeSelect></Field> : <Field key={field} label={field.replace(/_/g, " ")}><Input required={kind === "ledgers"} value={String(draft[field] || "")} onChange={(event) => setDraft((current) => ({ ...current, [field]: numericFields.has(field) ? Number(event.target.value) : event.target.value }))} /></Field>)}
        {kind === "ledgers" && ledgerGroups.isError && <div role="alert">Ledger groups could not be loaded. <Button type="button" variant="outline" onClick={() => { void ledgerGroups.refetch(); }}>Retry ledger groups</Button></div>}
        {kind === "ledgers" && ledgerGroups.isSuccess && !groups.length && <p role="status">Create a ledger group before adding a ledger.</p>}
        <Button type="submit" className="w-full" disabled={!canWrite || mutation.isPending || kind === "ledgers" && !groups.length} title={!canWrite ? "Write permission required" : undefined}><Plus className="h-4 w-4" />{mutation.isPending ? "Saving…" : "Create"}</Button>
      </form></CardContent></Card></SmartCreateSection>
      <Card><CardHeader><CardTitle className="text-base">{config.label} list</CardTitle></CardHeader><CardContent><State label={config.label} isLoading={query.isLoading} isError={query.isError} /><DataTable rows={rows} columns={config.columns} /></CardContent></Card>
    </div>
  );
}

function OpeningBalancesView() {
  const scope=useRecordScope();
  return <OpeningBalancesForm key={scope} scope={scope}/>;
}
function OpeningBalancesForm({scope}: {scope:string}) {
  const queryClient = useQueryClient();
  const canWrite = useFinanceWrite(["fam_admin","fam_opening_balance_manage"],"create"),canPost=useFinanceWrite(["fam_admin","fam_opening_balance_manage"],"approve");
  const query = useQuery({ queryKey: ["fam", "openingBalances",scope], queryFn: famApi.openingBalances });
  const data = (query.data || {}) as FAMRecord;
  const rows = listItems(data);
  const yearsQuery=useQuery({queryKey:["fam","opening-reference-years",scope],queryFn:famApi.financialYears,staleTime:30000,retry:false});
  const ledgersQuery=useQuery({queryKey:["fam","opening-reference-ledgers",scope],queryFn:famApi.ledgers,staleTime:30000,retry:false});
  const years=listItems(yearsQuery.data),ledgers=listItems(ledgersQuery.data);
  const openYears=years.filter(row=>!row.status||row.status==="open"),activeLedgers=ledgers.filter(row=>row.active!==false);
  const [draft, setDraft] = useState<FAMRecord>({ financial_year_id: "", ledger_id: "", debit_amount: "0", credit_amount: "0", narration: "" });
  const [entryError,setEntryError]=useState("");
  const createMutation = useMutation({ mutationFn: () => famApi.createOpeningBalance({...draft,financial_year_id:Number(draft.financial_year_id),ledger_id:Number(draft.ledger_id),debit_amount:Number(draft.debit_amount),credit_amount:Number(draft.credit_amount)}), onSuccess: () => { toast({ title: "Opening balance saved" }); queryClient.invalidateQueries({ queryKey: ["fam"] }); } , onError: showMutationError });
  const postMutation = useMutation({ mutationFn: famApi.postOpeningBalances, onSuccess: () => { toast({ title: "Opening balances posted" }); queryClient.invalidateQueries({ queryKey: ["fam"] }); } , onError: showMutationError });
  const difference = Number(data.difference || 0);
  return (
    <div className="space-y-4">
      <div className="grid gap-3 md:grid-cols-4">
        <Card><CardContent className="p-4"><p className="text-xs text-muted-foreground">Debit</p><p className="text-lg font-semibold">{money(data.debitTotal)}</p></CardContent></Card>
        <Card><CardContent className="p-4"><p className="text-xs text-muted-foreground">Credit</p><p className="text-lg font-semibold">{money(data.creditTotal)}</p></CardContent></Card>
        <Card><CardContent className="p-4"><p className="text-xs text-muted-foreground">Difference</p><p className={difference ? "text-lg font-semibold text-destructive" : "text-lg font-semibold text-emerald-700"}>{money(difference)}</p></CardContent></Card>
        <Button className="h-full min-h-20" onClick={() => postMutation.mutate()} disabled={!canPost || query.isPending || query.isError || !rows.length || Boolean(difference) || postMutation.isPending}><LockKeyhole className="h-4 w-4" />Post balanced opening</Button>
      </div>
      <CompactForm onSubmit={event=>{
        event.preventDefault();if(!canWrite||createMutation.isPending)return;
        if(yearsQuery.isError||ledgersQuery.isError||!openYears.some(row=>String(row.id)===String(draft.financial_year_id))||!activeLedgers.some(row=>String(row.id)===String(draft.ledger_id))){setEntryError("Choose an available financial year and ledger.");return;}
        const debit=Number(draft.debit_amount),credit=Number(draft.credit_amount);
        if(!Number.isFinite(debit)||!Number.isFinite(credit)||debit<0||credit<0){setEntryError("Debit and credit must be zero or greater.");return;}
        if(![draft.debit_amount,draft.credit_amount].every(value=>/^(?:\d+\.?\d*|\.\d+)?$/.test(String(value).trim()))){setEntryError("Use decimal numbers for debit and credit amounts.");return;}
        if(debit&&credit){setEntryError("Enter either a debit or a credit, not both.");return;}
        setEntryError("");createMutation.mutate();
      }}><fieldset disabled={!canWrite||createMutation.isPending} className="grid gap-3 rounded-lg border p-4 md:grid-cols-3">
        <Field label="Financial year"><NativeSelect className="h-11 w-full rounded-md border bg-background px-3" required loading={yearsQuery.isFetching} error={yearsQuery.isError} disabled={yearsQuery.isPending||yearsQuery.isError} value={String(draft.financial_year_id)} onChange={event=>setDraft(current=>({...current,financial_year_id:event.target.value}))}><option value="">Choose financial year</option>{openYears.map(row=><option key={String(row.id)} value={String(row.id)}>{String(row.name)}</option>)}</NativeSelect></Field>
        <Field label="Ledger"><NativeSelect className="h-11 w-full rounded-md border bg-background px-3" required searchable loading={ledgersQuery.isFetching} error={ledgersQuery.isError} disabled={ledgersQuery.isPending||ledgersQuery.isError} value={String(draft.ledger_id)} onChange={event=>setDraft(current=>({...current,ledger_id:event.target.value}))}><option value="">Choose ledger</option>{activeLedgers.map(row=><option key={String(row.id)} value={String(row.id)}>{String(row.ledger_name)}{row.ledger_code?` · ${row.ledger_code}`:""}</option>)}</NativeSelect></Field>
        <Field label="Debit amount"><Input inputMode="decimal" value={String(draft.debit_amount)} onChange={event=>setDraft(current=>({...current,debit_amount:event.target.value}))}/></Field>
        <Field label="Credit amount"><Input inputMode="decimal" value={String(draft.credit_amount)} onChange={event=>setDraft(current=>({...current,credit_amount:event.target.value}))}/></Field>
        <Field label="Narration"><Input value={String(draft.narration)} onChange={event=>setDraft(current=>({...current,narration:event.target.value}))}/></Field>
        <Button type="submit" disabled={yearsQuery.isPending||ledgersQuery.isPending||yearsQuery.isError||ledgersQuery.isError}>{createMutation.isPending?"Saving…":"Save opening balance"}</Button>
      </fieldset></CompactForm>
      {yearsQuery.isError&&<p role="alert">Financial years could not load. <Button variant="outline" onClick={()=>void yearsQuery.refetch()}>Retry financial years</Button></p>}
      {ledgersQuery.isError&&<p role="alert">Ledgers could not load. <Button variant="outline" onClick={()=>void ledgersQuery.refetch()}>Retry ledgers</Button></p>}
      {yearsQuery.isSuccess&&!openYears.length&&<p>No open financial year is available. <Link to="/fam/financial-years" target="_blank" rel="noopener" className="underline">Open financial year settings</Link></p>}
      {entryError&&<p role="alert">{entryError}</p>}
      <Card><CardHeader><CardTitle className="text-base">Ledger-wise opening balances</CardTitle></CardHeader><CardContent><State label="opening balances" isLoading={query.isLoading} isError={query.isError} /><DataTable rows={rows.map(row=>({...row,financial_year:years.find(year=>year.id===row.financial_year_id)?.name||"Financial year unavailable",ledger:ledgers.find(ledger=>ledger.id===row.ledger_id)?.ledger_name||"Ledger unavailable"}))} columns={["financial_year", "ledger", "debit_amount", "credit_amount", "posted", "narration"]} /></CardContent></Card>
    </div>
  );
}

const defaultVoucherLine = { ledger_id: 1, debit_amount: 0, credit_amount: 0, narration: "" };

function voucherDraft(kind: FAMViewKind): FAMRecord {
  const isJournal = kind === "journal";
  return {
    voucher_type_id: 1,
    voucher_date: "2026-06-06",
    reference_number: "",
    narration: isJournal ? "Journal adjustment" : "",
    source_module: "fam",
    lines: [
      { ...defaultVoucherLine, cost_center_id: defaultId("accounting_cost_center_id", "fam"), debit_amount: 1000, narration: "Debit line" },
      { ...defaultVoucherLine, cost_center_id: defaultId("accounting_cost_center_id", "fam"), ledger_id: 2, credit_amount: 1000, narration: "Credit line" },
    ],
  };
}

function VoucherEntryView({ mode }: { mode: "new" | "journal" | "detail" }) {
  const phone=useMobile(480);
  const params = useParams();
  const canCreate = useFinanceWrite(["fam_admin","fam_vouchers_create"],"create");
  const canUpdate = useFinanceWrite(["fam_admin","fam_vouchers_create"],"edit");
  const canPost = useFinanceWrite(["fam_admin","fam_vouchers_post"],"approve");
  const canCancel = useFinanceWrite(["fam_admin","fam_vouchers_cancel"],"create");
  const canReverse = useFinanceWrite(["fam_admin","fam_vouchers_reverse"],"create");
  const queryClient = useQueryClient();
  const voucherQuery = useQuery({ queryKey: ["fam", "voucher", params.id], queryFn: () => famApi.getVoucher(params.id || ""), enabled: mode === "detail" && Boolean(params.id) });
  const typesQuery = useQuery({ queryKey: ["fam", "voucherTypes"], queryFn: famApi.voucherTypes });
  const ledgersQuery = useQuery({ queryKey: ["fam", "ledgers"], queryFn: famApi.ledgers });
  const [draft, setDraft] = useState<FAMRecord>(() => mode === "detail" ? {} : voucherDraft(mode === "journal" ? "journal" : "voucherNew"));
  const effective = (mode === "detail" ? { ...voucherQuery.data, ...draft } : draft) as FAMRecord;
  const lines = ((effective.lines as FAMRecord[] | undefined) || []) as FAMRecord[];
  const debitTotal = lines.reduce((sum, line) => sum + Number(line.debit_amount || 0), 0);
  const creditTotal = lines.reduce((sum, line) => sum + Number(line.credit_amount || 0), 0);
  const difference = debitTotal - creditTotal;
  const voucherId = String(effective.id || params.id || "");
  const saveMutation = useMutation({
    mutationFn: () => (mode === "detail" && voucherId ? famApi.updateVoucher(voucherId, { ...effective, total_debit: debitTotal, total_credit: creditTotal }) : famApi.createVoucher({ ...effective, total_debit: debitTotal, total_credit: creditTotal })),
    onSuccess: () => { toast({ title: "Voucher draft saved" }); if (mode === "detail") setDraft({}); queryClient.invalidateQueries({ queryKey: ["fam"] }); },
   onError: showMutationError });
  const postMutation = useMutation({ mutationFn: () => famApi.postVoucher(voucherId), onSuccess: () => { toast({ title: "Voucher posted" }); if(phone)setDraft({}); queryClient.invalidateQueries({ queryKey: ["fam"] }); } , onError: showMutationError });
  const cancelMutation = useMutation({ mutationFn: () => famApi.cancelVoucher(voucherId), onSuccess: () => { toast({ title: "Voucher cancelled" }); if(phone)setDraft({}); queryClient.invalidateQueries({ queryKey: ["fam"] }); } , onError: showMutationError });
  const reverseMutation = useMutation({ mutationFn: () => famApi.reverseVoucher(voucherId), onSuccess: () => { toast({ title: "Reversal voucher created" }); queryClient.invalidateQueries({ queryKey: ["fam"] }); } , onError: showMutationError });
  const cloneMutation = useMutation({ mutationFn: () => famApi.cloneVoucher(voucherId), onSuccess: () => { toast({ title: "Voucher cloned" }); queryClient.invalidateQueries({ queryKey: ["fam"] }); } , onError: showMutationError });
  const patch = (key: string, value: unknown) => setDraft((current) => ({ ...effective, ...current, [key]: value }));
  const patchLine = (index: number, key: string, value: unknown) => {
    const next = lines.map((line, lineIndex) => lineIndex === index ? { ...line, [key]: numericFields.has(key) ? Number(value) : value } : line);
    patch("lines", next);
  };
  const addLine = () => patch("lines", [...lines, { ...defaultVoucherLine, cost_center_id: defaultId("accounting_cost_center_id", "fam") }]);
  // A phone confirmation must refer to the saved record the posting API uses.
  const phoneRecordUnavailable=phone&&mode==="detail"&&(!voucherQuery.data||voucherQuery.isFetching||voucherQuery.isError);
  const phoneUnsaved=phone&&mode==="detail"&&!!voucherQuery.data&&JSON.stringify(effective)!==JSON.stringify(voucherQuery.data);
  const voucherStatus=phone&&mode==="detail"?voucherQuery.data?.status:effective.status;
  const phoneLifecyclePending=phone&&(postMutation.isPending||cancelMutation.isPending);
  const canEdit = !phoneLifecyclePending&&!phoneRecordUnavailable&&(mode === "detail"?canUpdate:canCreate) && (mode !== "detail" || !!voucherQuery.data) && String(voucherStatus || "draft") === "draft";
  const fieldsEditable=canEdit&&!(phone&&saveMutation.isPending);
  return (
    <div className="space-y-4 fam-mobile-voucher">
      <State label="voucher" isLoading={voucherQuery.isLoading || typesQuery.isLoading || ledgersQuery.isLoading} isError={voucherQuery.isError || typesQuery.isError || ledgersQuery.isError} />
      <FinancialYearSetupGuidance date={String(effective.voucher_date||"")} errors={[saveMutation.error,postMutation.error,cancelMutation.error,reverseMutation.error,cloneMutation.error]}/>
      <RecordSections label="Voucher information" sections={[
        {id:"overview",label:"Overview",content:<>      <div className="grid gap-3 md:grid-cols-4 fam-voucher-overview">
        <Field label="Voucher Type">
          <NativeSelect loading={typesQuery.isFetching} error={typesQuery.isError} className="h-10 w-full rounded-md border bg-background px-3 text-sm" value={String(effective.voucher_type_id || 1)} onChange={(event) => patch("voucher_type_id", Number(event.target.value))} disabled={!fieldsEditable}>
            {listItems(typesQuery.data).map((type) => <option key={String(type.id)} value={String(type.id)}>{text(type.voucher_type_name)}</option>)}
          </NativeSelect>
        </Field>
        <Field label="Voucher Date"><Input type="date" value={String(effective.voucher_date || "")} onChange={(event) => patch("voucher_date", event.target.value)} disabled={!fieldsEditable} /></Field>
        <Field label="Reference Number"><Input value={String(effective.reference_number || "")} onChange={(event) => patch("reference_number", event.target.value)} disabled={!fieldsEditable} /></Field>
        <Field label="Narration"><RichTextField value={String(effective.narration || "")} onChange={(event) => patch("narration", event.target.value)} disabled={!fieldsEditable} /></Field>
      </div>
</>},
        {id:"lines",label:"Entry lines",content:<>      <Card className="fam-voucher-lines-card">
        <CardHeader><CardTitle className="text-base">Debit / Credit lines</CardTitle></CardHeader>
        <CardContent className="space-y-3">
          {phone&&<><VoucherMobileLineEditor lines={lines} ledgers={listItems(ledgersQuery.data)} loading={ledgersQuery.isFetching} error={ledgersQuery.isError} canEdit={fieldsEditable} onChange={patchLine} onAdd={addLine}/><p className="fam-voucher-scroll-help">Scroll within the full grid for all line fields and tools.</p></>}
          <div className="overflow-x-auto rounded-lg border fam-voucher-line-table" role={phone?"region":undefined} aria-label={phone?"Voucher entry grid, scroll for all fields":undefined} tabIndex={phone?0:undefined}>
            <GridTable gridId="apps/fam/FAMWorkspacePage:table-2" className="w-full min-w-[860px] text-sm">
              <thead className="bg-muted/60 text-left text-xs uppercase text-muted-foreground"><tr><th className="px-3 py-2">Ledger</th><th className="px-3 py-2">Debit</th><th className="px-3 py-2">Credit</th><th className="px-3 py-2">Cost Center</th><th className="px-3 py-2">Narration</th></tr></thead>
              <tbody>
                {lines.map((line, index) => (
                  <tr {...recordPreviewProps(line)} key={index} className="border-t">
                    <td className="px-3 py-2"><NativeSelect aria-label={phone?`Line ${index+1} Ledger`:undefined} loading={ledgersQuery.isFetching} error={ledgersQuery.isError} className="h-9 w-full rounded-md border bg-background px-2" value={String(line.ledger_id || 1)} onChange={(event) => patchLine(index, "ledger_id", event.target.value)} disabled={!fieldsEditable}>{listItems(ledgersQuery.data).map((ledger) => <option key={String(ledger.id)} value={String(ledger.id)}>{text(ledger.ledger_name)}</option>)}</NativeSelect></td>
                    <td className="px-3 py-2"><Input aria-label={phone?`Line ${index+1} Debit`:undefined} type="number" value={String(line.debit_amount || 0)} onChange={(event) => patchLine(index, "debit_amount", event.target.value)} disabled={!fieldsEditable} /></td>
                    <td className="px-3 py-2"><Input aria-label={phone?`Line ${index+1} Credit`:undefined} type="number" value={String(line.credit_amount || 0)} onChange={(event) => patchLine(index, "credit_amount", event.target.value)} disabled={!fieldsEditable} /></td>
                    <td className="px-3 py-2"><Input aria-label={phone?`Line ${index+1} Cost Center`:undefined} value={String(line.cost_center_id || "")} onChange={(event) => patchLine(index, "cost_center_id", event.target.value)} disabled={!fieldsEditable} /></td>
                    <td className="px-3 py-2"><Input aria-label={phone?`Line ${index+1} Narration`:undefined} value={String(line.narration || "")} onChange={(event) => patchLine(index, "narration", event.target.value)} disabled={!fieldsEditable} /></td>
                  </tr>
                ))}
              </tbody>
            </GridTable>
          </div>
          {fieldsEditable ? <Button variant="outline" onClick={addLine}><Plus className="h-4 w-4" />Add line</Button> : null}
        </CardContent>
      </Card>
</>},
        {id:"review",label:"Review totals",content:<>      <div className="grid gap-3 md:grid-cols-4 fam-voucher-totals">
        <Card><CardContent className="p-4"><p className="text-xs text-muted-foreground">Total debit</p><p className="text-lg font-semibold">{money(debitTotal)}</p></CardContent></Card>
        <Card><CardContent className="p-4"><p className="text-xs text-muted-foreground">Total credit</p><p className="text-lg font-semibold">{money(creditTotal)}</p></CardContent></Card>
        <Card><CardContent className="p-4"><p className="text-xs text-muted-foreground">Difference</p><p className={difference ? "text-lg font-semibold text-destructive" : "text-lg font-semibold text-emerald-700"}>{money(difference)}</p></CardContent></Card>
        <Card><CardContent className="p-4"><p className="text-xs text-muted-foreground">Status</p><Badge variant={statusTone(voucherStatus || "draft")}>{text(voucherStatus || "draft")}</Badge></CardContent></Card>
      </div>
</>},
      ]}/>
      <ActionToolbar label="Voucher actions" actions={[
        {id:"save",kind:"save",label:"Save draft",prominent:true,primary:true,available:canEdit,loading:saveMutation.isPending,onSelect:()=>saveMutation.mutate()},
        {id:"post",kind:"approve",label:"Post voucher",prominent:true,available:canPost&&!!voucherId&&String(voucherStatus||"draft")==="draft",loading:postMutation.isPending,disabled:Boolean(difference)||phoneUnsaved||phoneRecordUnavailable,disabledReason:difference?"Balance debit and credit totals before posting":phoneRecordUnavailable?"Load the latest saved voucher before posting":phoneUnsaved?"Save draft changes before posting":undefined,onSelect:()=>postMutation.mutate(),confirm:{title:"Post this voucher?",description:`${effective.voucher_number || voucherId} · debit ${money(debitTotal)} · credit ${money(creditTotal)}. Review the lines before posting to the ledger.`,label:"Post voucher"}},
        {id:"clone",kind:"copy",label:"Clone voucher",prominent:true,available:canCreate&&!!voucherId&&!!voucherQuery.data,loading:cloneMutation.isPending,onSelect:()=>cloneMutation.mutate()},
        {id:"cancel",kind:"reject",label:"Cancel voucher",danger:true,available:canCancel&&!!voucherId&&["draft","posted"].includes(String(voucherStatus)),loading:cancelMutation.isPending,onSelect:()=>cancelMutation.mutate(),confirm:{title:"Cancel this voucher?",description:`Voucher ${effective.voucher_number || voucherId}. Review its accounting impact before cancelling.`,label:"Cancel voucher"}},
        {id:"reverse",kind:"review",label:"Reverse voucher",danger:true,available:canReverse&&!!voucherId&&voucherStatus==="posted",loading:reverseMutation.isPending,onSelect:()=>reverseMutation.mutate(),confirm:{title:"Reverse this posted voucher?",description:`Voucher ${effective.voucher_number || voucherId}. This creates a linked reversal and records it in history.`,label:"Reverse voucher"}},
      ]}/>
    </div>
  );
}

function VouchersView() {
  const query = useQuery({ queryKey: ["fam", "vouchers"], queryFn: famApi.vouchers });
  const rows = listItems(query.data);
  return <Card><CardHeader><CardTitle className="text-base">Voucher register</CardTitle></CardHeader><CardContent><div className="mb-3"><Button asChild><Link to="/fam/vouchers/new"><Plus className="h-4 w-4" />New voucher</Link></Button></div><State label="vouchers" isLoading={query.isLoading} isError={query.isError} /><DataTable rows={rows} columns={["voucher_number", "voucher_date", "status", "total_debit", "total_credit", "source_module"]} /></CardContent></Card>;
}

function DayBookView() {
  const query = useQuery({ queryKey: ["fam", "dayBook"], queryFn: famApi.dayBook });
  const data = (query.data || {}) as FAMRecord;
  const rows = listItems(data);
  return <div className="space-y-4"><div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between"><div className="grid flex-1 gap-3 md:grid-cols-3"><Card><CardContent className="p-4"><p className="text-xs text-muted-foreground">Vouchers</p><p className="text-lg font-semibold">{text(data.total)}</p></CardContent></Card><Card><CardContent className="p-4"><p className="text-xs text-muted-foreground">Debit total</p><p className="text-lg font-semibold">{money(data.debitTotal)}</p></CardContent></Card><Card><CardContent className="p-4"><p className="text-xs text-muted-foreground">Credit total</p><p className="text-lg font-semibold">{money(data.creditTotal)}</p></CardContent></Card></div><div className="flex flex-wrap gap-2"><Button asChild><Link to="/fam/vouchers/new"><Plus className="h-4 w-4" />New Voucher</Link></Button><ExportButton exportType="day_book" label="Export Day Book CSV" /></div></div><Card><CardContent className="p-5"><State label="day book" isLoading={query.isLoading} isError={query.isError} />{!query.isLoading && !query.isError && !rows.length ? <div className="mb-3 rounded-lg border border-dashed p-4 text-sm text-muted-foreground">Day Book is available. Create or post vouchers to populate this register.</div> : null}<DataTable rows={rows} columns={["voucher_date", "voucher_number", "status", "reference_number", "total_debit", "total_credit"]} /></CardContent></Card></div>;
}

function LedgerEntriesView({ detail }: { detail?: boolean }) {
  const params = useParams();
  const query = useQuery({ queryKey: ["fam", "ledgerEntries", detail ? params.id : "all"], queryFn: () => detail && params.id ? famApi.ledgerEntriesForLedger(params.id) : famApi.ledgerEntries() });
  const data = (query.data || {}) as FAMRecord;
  return <div className="space-y-4"><div className="grid gap-3 md:grid-cols-4"><Card><CardContent className="p-4"><p className="text-xs text-muted-foreground">Opening</p><p className="text-lg font-semibold">{money(data.openingBalance)}</p></CardContent></Card><Card><CardContent className="p-4"><p className="text-xs text-muted-foreground">Debit movement</p><p className="text-lg font-semibold">{money(data.debitMovement || data.debitTotal)}</p></CardContent></Card><Card><CardContent className="p-4"><p className="text-xs text-muted-foreground">Credit movement</p><p className="text-lg font-semibold">{money(data.creditMovement || data.creditTotal)}</p></CardContent></Card><Card><CardContent className="p-4"><p className="text-xs text-muted-foreground">Closing</p><p className="text-lg font-semibold">{money(data.closingBalance)}</p></CardContent></Card></div><Card><CardContent className="p-5"><State label="ledger entries" isLoading={query.isLoading} isError={query.isError} /><DataTable rows={listItems(data)} columns={["voucher_date", "voucher_number", "ledger_id", "debit_amount", "credit_amount", "running_balance", "source_module"]} /></CardContent></Card></div>;
}

function PartiesView({ partyType }: { partyType?: "customer" | "vendor" }) {
  const createRef = useNewRecordFocus();
  const queryClient = useQueryClient();
  const canWrite = useFinanceWrite(["fam_admin","fam_parties_manage"],"create"),canEdit=useFinanceWrite(["fam_admin","fam_parties_manage"],"edit"),canDelete=useFinanceWrite(["fam_admin","fam_parties_manage"],"delete");
  const query = useQuery({ queryKey: ["fam", "parties", partyType || "all"], queryFn: () => famApi.parties(partyType) });
  const rows = listItems(query.data).filter(row=>row.active!==false);
  const [draft, setDraft] = useState<FAMRecord>({ party_type: partyType || "customer", party_code: "", legal_name: "", registration_type: "regular", state_code: "29", payment_terms_days: 30, credit_limit: 0, create_ledger: true });
  const mutation = useMutation({ mutationFn: () => famApi.createParty(draft), onSuccess: () => { toast({ title: "Party saved" }); setDraft({ ...draft, party_code: "", legal_name: "" }); queryClient.invalidateQueries({ queryKey: ["fam"] }); } , onError: showMutationError });
  const title = partyType === "customer" ? "customer" : partyType === "vendor" ? "vendor" : "party";
  return (
    <div className="grid gap-4 lg:grid-cols-[24rem_1fr]">
      <SmartCreateSection title={<>Create {title}</>} size="compact"><Card ref={createRef} id="new-record"><CardHeader><CardTitle className="text-base">Create {title}</CardTitle></CardHeader><CardContent className="space-y-3">
        {["party_type", "party_code", "legal_name", "gstin", "pan", "state_code", "payment_terms_days", "credit_limit"].map((field) => <Field key={field} label={field.replace(/_/g, " ")}><Input value={String(draft[field] || "")} onChange={(event) => setDraft((current) => ({ ...current, [field]: numericFields.has(field) ? Number(event.target.value) : event.target.value }))} /></Field>)}
        <Button className="w-full" onClick={() => mutation.mutate()} disabled={!canWrite || mutation.isPending} title={!canWrite ? "Write permission required" : undefined}><Plus className="h-4 w-4" />Create with ledger</Button>
      </CardContent></Card></SmartCreateSection>
      <Card><CardHeader><CardTitle className="text-base">{title} masters</CardTitle></CardHeader><CardContent><State label="parties" isLoading={query.isLoading} isError={query.isError} /><DataTable rows={rows} columns={["party_code", "legal_name", "party_type", "ledger_id", "payment_terms_days", "credit_limit", "active"]} renderActions={row=><RecordMaintenance record={row} name={String(row.legal_name)} endpoint={`/fam/parties/${row.id}`} fields={[{key:"legal_name",label:"Legal name",required:true},{key:"credit_limit",label:"Credit limit",type:"number"}]} queryKeys={["fam"]} canEdit={canEdit} canDelete={canDelete} mergeRecord/>}/></CardContent></Card>
    </div>
  );
}

function PartyDetailView() {
  const params = useParams();
  const id = params.id || "1";
  const party = useQuery({ queryKey: ["fam", "party", id], queryFn: () => famApi.getParty(id) });
  const outstanding = useQuery({ queryKey: ["fam", "partyOutstanding", id], queryFn: () => famApi.partyOutstanding(id) });
  const statement = useQuery({ queryKey: ["fam", "partyStatement", id], queryFn: () => famApi.partyStatement(id) });
  const data = (party.data || {}) as FAMRecord;
  const statementData = (statement.data || {}) as FAMRecord;
  return <div className="space-y-4"><div className="grid gap-3 md:grid-cols-4"><Card><CardContent className="p-4"><p className="text-xs text-muted-foreground">Party</p><p className="text-lg font-semibold">{text(data.legal_name)}</p></CardContent></Card><Card><CardContent className="p-4"><p className="text-xs text-muted-foreground">Ledger</p><p className="text-lg font-semibold">{text(data.ledger_id)}</p></CardContent></Card><Card><CardContent className="p-4"><p className="text-xs text-muted-foreground">Credit limit</p><p className="text-lg font-semibold">{money(data.credit_limit)}</p></CardContent></Card><Card><CardContent className="p-4"><p className="text-xs text-muted-foreground">Outstanding</p><p className="text-lg font-semibold">{money((outstanding.data as FAMRecord | undefined)?.outstanding)}</p></CardContent></Card></div><Card><CardHeader><CardTitle className="text-base">Statement and bill references</CardTitle></CardHeader><CardContent><State label="party detail" isLoading={party.isLoading || statement.isLoading} isError={party.isError || statement.isError} /><DataTable rows={(statementData.billReferences as FAMRecord[] | undefined) || []} columns={["bill_number", "bill_date", "due_date", "bill_type", "original_amount", "outstanding_amount", "status"]} /></CardContent></Card><Card><CardHeader><CardTitle className="text-base">Allocations</CardTitle></CardHeader><CardContent><DataTable rows={(statementData.allocations as FAMRecord[] | undefined) || []} columns={["allocation_date", "allocation_type", "allocated_amount", "from_bill_reference_id", "to_bill_reference_id"]} /></CardContent></Card></div>;
}

function AgingView({ kind }: { kind: "ar" | "ap" }) {
  const query = useQuery({ queryKey: ["fam", kind, "aging"], queryFn: kind === "ar" ? famApi.arAging : famApi.apAging });
  const data = (query.data || {}) as FAMRecord;
  const buckets = data.buckets as Record<string, number> | undefined;
  return <div className="space-y-4"><div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between"><div className="text-sm text-muted-foreground">Bill-wise aging is exportable for collections, audit, and review.</div><ExportButton exportType={kind === "ar" ? "receivables_aging" : "payables_aging"} label={`Export ${kind.toUpperCase()} aging CSV`} /></div><div className="grid gap-3 md:grid-cols-6">{["Not due", "0-30", "31-60", "61-90", "91-180", ">180"].map((bucket) => <Card key={bucket}><CardContent className="p-4"><p className="text-xs text-muted-foreground">{bucket}</p><p className="text-lg font-semibold">{money(buckets?.[bucket])}</p></CardContent></Card>)}</div><Card><CardHeader><CardTitle className="text-base">{kind.toUpperCase()} aging details</CardTitle></CardHeader><CardContent><State label={`${kind} aging`} isLoading={query.isLoading} isError={query.isError} /><DataTable rows={(data.items as FAMRecord[] | undefined) || []} columns={["bill_number", "party_id", "due_date", "aging_bucket", "overdue_days", "outstanding_amount", "status"]} /></CardContent></Card></div>;
}

function OutstandingView({ kind }: { kind: "ar" | "ap" }) {
  const query = useQuery({ queryKey: ["fam", kind, "outstanding"], queryFn: kind === "ar" ? famApi.arOutstanding : famApi.apOutstanding });
  const data = (query.data || {}) as FAMRecord;
  return <div className="space-y-4"><div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between"><Card className="sm:min-w-72"><CardContent className="p-4"><p className="text-xs text-muted-foreground">{kind.toUpperCase()} total outstanding</p><p className="text-2xl font-semibold">{money(data.totalOutstanding)}</p></CardContent></Card><ExportButton exportType={kind === "ar" ? "receivables_aging" : "payables_aging"} label={`Export ${kind.toUpperCase()} outstanding CSV`} /></div><Card><CardContent className="p-5"><State label={`${kind} outstanding`} isLoading={query.isLoading} isError={query.isError} /><DataTable rows={listItems(data)} columns={["bill_number", "party_id", "bill_date", "due_date", "bill_type", "outstanding_amount", "status"]} /></CardContent></Card></div>;
}

function BillReferencesView() {
  const queryClient = useQueryClient();
  const query = useQuery({ queryKey: ["fam", "billReferences"], queryFn: famApi.billReferences });
  const [draft, setDraft] = useState<FAMRecord>({ party_id: 1, bill_number: "", bill_date: "2026-06-06", bill_type: "invoice", original_amount: 1000 });
  const mutation = useMutation({ mutationFn: () => famApi.createBillReference(draft), onSuccess: () => { toast({ title: "Bill reference saved" }); queryClient.invalidateQueries({ queryKey: ["fam"] }); } , onError: showMutationError });
  return <div className="grid gap-4 lg:grid-cols-[24rem_1fr]"><SmartCreateSection title={<>Create bill reference</>} size="compact"><Card><CardHeader><CardTitle className="text-base">Create bill reference</CardTitle></CardHeader><CardContent className="space-y-3">{["party_id", "bill_number", "bill_date", "bill_type", "original_amount"].map((field) => <Field key={field} label={field.replace(/_/g, " ")}><Input value={String(draft[field] || "")} onChange={(event) => setDraft((current) => ({ ...current, [field]: numericFields.has(field) ? Number(event.target.value) : event.target.value }))} /></Field>)}<Button className="w-full" onClick={() => mutation.mutate()}>Create bill</Button></CardContent></Card></SmartCreateSection><Card><CardHeader><CardTitle className="text-base">Bill-wise tracking</CardTitle></CardHeader><CardContent><State label="bill references" isLoading={query.isLoading} isError={query.isError} /><DataTable rows={listItems(query.data)} columns={["bill_number", "party_id", "bill_date", "due_date", "bill_type", "original_amount", "outstanding_amount", "status"]} /></CardContent></Card></div>;
}

function BillAllocationsView() {
  const queryClient = useQueryClient();
  const query = useQuery({ queryKey: ["fam", "billAllocations"], queryFn: famApi.billAllocations });
  const [draft, setDraft] = useState<FAMRecord>({ allocation_date: "2026-06-06", party_id: 1, from_bill_reference_id: 1, to_bill_reference_id: 1, allocated_amount: 100, allocation_type: "receipt" });
  const mutation = useMutation({ mutationFn: () => famApi.createBillAllocation(draft), onSuccess: () => { toast({ title: "Bill allocation saved" }); queryClient.invalidateQueries({ queryKey: ["fam"] }); } , onError: showMutationError });
  return <div className="grid gap-4 lg:grid-cols-[24rem_1fr]"><Card><CardHeader><CardTitle className="text-base">Allocate bill</CardTitle></CardHeader><CardContent className="space-y-3">{["allocation_date", "party_id", "from_bill_reference_id", "to_bill_reference_id", "allocated_amount", "allocation_type"].map((field) => <Field key={field} label={field.replace(/_/g, " ")}><Input value={String(draft[field] || "")} onChange={(event) => setDraft((current) => ({ ...current, [field]: numericFields.has(field) ? Number(event.target.value) : event.target.value }))} /></Field>)}<Button className="w-full" onClick={() => mutation.mutate()}>Allocate</Button></CardContent></Card><Card><CardHeader><CardTitle className="text-base">Allocations</CardTitle></CardHeader><CardContent><State label="bill allocations" isLoading={query.isLoading} isError={query.isError} /><DataTable rows={listItems(query.data)} columns={["allocation_date", "party_id", "allocation_type", "allocated_amount", "from_bill_reference_id", "to_bill_reference_id"]} /></CardContent></Card></div>;
}

function SRMIntegrationView() {
  const queryClient = useQueryClient();
  const query = useQuery({ queryKey: ["fam", "srmIntegration"], queryFn: famApi.srmIntegrationStatus });
  const rules = useQuery({ queryKey: ["fam", "postingRules"], queryFn: famApi.postingRules });
  const data = (query.data || {}) as FAMRecord;
  const [draft, setDraft] = useState<FAMRecord>({ invoice_id: "", receipt_id: "", allocation_id: "", reverse_type: "invoice", reverse_id: "" });
  const [message, setMessage] = useState("");
  const action = useMutation({
    mutationFn: (run: () => Promise<FAMRecord>) => run(),
    onSuccess: () => { setMessage("Accounting integration updated"); toast({ title: "Accounting integration updated" }); queryClient.invalidateQueries({ queryKey: ["fam"] }); },
    onError: (err: unknown) => { const textValue = apiErrorMessage(err, "Posting failed pre-flight checks"); setMessage(textValue); toast({ title: "Posting failed", description: textValue, variant: "destructive" }); },
  });
  const validSource = (value: unknown) => Number.isInteger(Number(value)) && Number(value) > 0;
  const kpis: Array<[string, unknown]> = [["Pending postings", data.pending_postings], ["Failed postings", data.failed_postings], ["Posted today", data.posted_today], ["Unmapped customers", data.unmapped_customers], ["Duplicate prevention", data.duplicate_prevention_status]];
  return (
    <div className="space-y-4">
      <State label="SRM accounting integration" isLoading={query.isLoading} isError={query.isError} />
      <div className="grid gap-3 md:grid-cols-5">{kpis.map(([label, value]) => <Card key={label}><CardContent className="p-4"><p className="text-xs text-muted-foreground">{label}</p><p className="mt-2 text-lg font-semibold">{text(value)}</p></CardContent></Card>)}</div>
      <Card><CardHeader><CardTitle className="text-base">Posting pre-flight checks</CardTitle></CardHeader><CardContent className="grid gap-3 md:grid-cols-3"><MetricGrid items={[["Posting rules", text(listItems(rules.data).length)], ["Unmapped customers", text(data.unmapped_customers)], ["Failed queue", text(data.failed_postings)]]} /><p className="text-sm text-muted-foreground md:col-span-2">Ledger mapping errors are blocked by the API with clear messages before vouchers are posted. Fix posting rules, party ledgers, and required bank/tax ledgers before retrying failed jobs.</p>{message ? <p className="text-sm text-muted-foreground md:col-span-3">{message}</p> : null}</CardContent></Card>
      <Card><CardHeader><CardTitle className="text-base">Manual posting controls</CardTitle></CardHeader><CardContent className="grid gap-3 md:grid-cols-4">
        <Field label="invoice id"><Input value={String(draft.invoice_id || "")} onChange={(event) => setDraft((current) => ({ ...current, invoice_id: Number(event.target.value) }))} /></Field>
        <Field label="receipt id"><Input value={String(draft.receipt_id || "")} onChange={(event) => setDraft((current) => ({ ...current, receipt_id: Number(event.target.value) }))} /></Field>
        <Field label="allocation id"><Input value={String(draft.allocation_id || "")} onChange={(event) => setDraft((current) => ({ ...current, allocation_id: Number(event.target.value) }))} /></Field>
        <Field label="reverse source id"><Input value={String(draft.reverse_id || "")} onChange={(event) => setDraft((current) => ({ ...current, reverse_id: Number(event.target.value) }))} /></Field>
        <ActionToolbar label="Accounting posting actions" actions={[
          {id:"invoice",kind:"save",label:"Post SRM invoice",prominent:true,primary:true,disabled:action.isPending || !validSource(draft.invoice_id),onSelect:()=>action.mutate(()=>famApi.postSrmInvoice(String(draft.invoice_id))),confirm:{title:"Post this invoice to accounting?",description:`Invoice #${draft.invoice_id || "—"}. Review its ledger mapping and amounts before posting.`,label:"Post invoice"}},
          {id:"receipt",kind:"save",label:"Post SRM receipt",prominent:true,disabled:action.isPending || !validSource(draft.receipt_id),onSelect:()=>action.mutate(()=>famApi.postSrmReceipt(String(draft.receipt_id))),confirm:{title:"Post this receipt to accounting?",description:`Receipt #${draft.receipt_id || "—"}. Review its ledger mapping and amounts before posting.`,label:"Post receipt"}},
          {id:"allocation",kind:"save",label:"Post allocation",prominent:true,disabled:action.isPending || !validSource(draft.allocation_id),onSelect:()=>action.mutate(()=>famApi.postSrmAllocation(String(draft.allocation_id))),confirm:{title:"Post this allocation?",description:`Allocation #${draft.allocation_id || "—"}. Confirm the receipt and invoice allocation before posting.`,label:"Post allocation"}},
          {id:"reverse",kind:"review",label:"Reverse posting",danger:true,disabled:action.isPending || !validSource(draft.reverse_id),onSelect:()=>action.mutate(()=>famApi.reverseSrmPosting(String(draft.reverse_type || "invoice"),String(draft.reverse_id))),confirm:{title:"Reverse this accounting posting?",description:`${draft.reverse_type || "Invoice"} #${draft.reverse_id || "—"}. Review the source before creating its reversal.`,label:"Reverse posting"}},
        ]}/>



      </CardContent></Card>
      <Card><CardHeader><CardTitle className="text-base">Recent posting jobs</CardTitle></CardHeader><CardContent><DataTable rows={(data.recent_jobs as FAMRecord[] | undefined) || []} columns={["id", "source_record_type", "source_record_id", "posting_type", "status", "voucher_id", "retry_count"]} /></CardContent></Card>
    </div>
  );
}

function PostingJobsView() {
  const queryClient = useQueryClient();
  const query = useQuery({ queryKey: ["fam", "postingJobs"], queryFn: famApi.postingJobs });
  const retry = useMutation({ mutationFn: (id: number | string) => famApi.retryPostingJob(id), onSuccess: () => { toast({ title: "Posting job retried" }); queryClient.invalidateQueries({ queryKey: ["fam"] }); } , onError: showMutationError });
  return <Card><CardHeader><CardTitle className="text-base">SRM posting queue</CardTitle></CardHeader><CardContent className="space-y-3"><State label="posting jobs" isLoading={query.isLoading} isError={query.isError} /><DataTable rows={listItems(query.data)} columns={["id", "source_module", "source_record_type", "source_record_id", "posting_type", "status", "voucher_id", "retry_count", "error_message"]} />{listItems(query.data).slice(0, 3).map((item) => <div key={String(item.id)} className="flex items-center justify-between rounded-md border p-3 text-sm"><Link className="text-primary underline-offset-4 hover:underline" to={`/fam/posting-jobs/${item.id}`}>Posting job #{text(item.id)}</Link><Button size="sm" variant="outline" onClick={() => retry.mutate(String(item.id))}>Retry</Button></div>)}</CardContent></Card>;
}

function PostingJobDetailView() {
  const params = useParams();
  const id = params.id || "1";
  const query = useQuery({ queryKey: ["fam", "postingJob", id], queryFn: () => famApi.postingJob(id) });
  const data = (query.data || {}) as FAMRecord;
  const status = (data.accountingStatus || {}) as FAMRecord;
  return <div className="space-y-4"><State label="posting job detail" isLoading={query.isLoading} isError={query.isError} /><div className="grid gap-3 md:grid-cols-4">{["status", "posting_type", "source_record_type", "voucher_id"].map((field) => <Card key={field}><CardContent className="p-4"><p className="text-xs text-muted-foreground">{field.replace(/_/g, " ")}</p><p className="text-lg font-semibold">{text(data[field])}</p></CardContent></Card>)}</div><Card><CardHeader><CardTitle className="text-base">Accounting mappings</CardTitle></CardHeader><CardContent><DataTable rows={(status.mappings as FAMRecord[] | undefined) || []} columns={["fam_record_type", "fam_record_id", "mapping_status"]} /></CardContent></Card></div>;
}

function PostingRulesView() {
  const queryClient = useQueryClient();
  const query = useQuery({ queryKey: ["fam", "postingRules"], queryFn: famApi.postingRules });
  const [draft, setDraft] = useState<FAMRecord>({ source_module: "srm", transaction_type: "sales_invoice", debit_ledger_rule_json: '{"type":"customer_ledger"}', credit_ledger_rule_json: '{"ledger_code":"SALES"}', tax_ledger_rule_json: '{"cgst":"OUTPUT-CGST","sgst":"OUTPUT-SGST"}', active: true });
  const mutation = useMutation({ mutationFn: () => famApi.createPostingRule({ ...draft, debit_ledger_rule_json: parseJson(draft.debit_ledger_rule_json), credit_ledger_rule_json: parseJson(draft.credit_ledger_rule_json), tax_ledger_rule_json: parseJson(draft.tax_ledger_rule_json) }), onSuccess: () => { toast({ title: "Posting rule saved" }); queryClient.invalidateQueries({ queryKey: ["fam"] }); } , onError: showMutationError });
  return <div className="grid gap-4 lg:grid-cols-[26rem_1fr]"><SmartCreateSection title={<>Create posting rule</>} size="compact"><Card><CardHeader><CardTitle className="text-base">Create posting rule</CardTitle></CardHeader><CardContent className="space-y-3">{["source_module", "transaction_type", "debit_ledger_rule_json", "credit_ledger_rule_json", "tax_ledger_rule_json"].map((field) => <Field key={field} label={field.replace(/_/g, " ")}><Input value={String(draft[field] || "")} onChange={(event) => setDraft((current) => ({ ...current, [field]: event.target.value }))} /></Field>)}<Button className="w-full" onClick={() => mutation.mutate()}>Save posting rule</Button></CardContent></Card></SmartCreateSection><Card><CardHeader><CardTitle className="text-base">Posting rules</CardTitle></CardHeader><CardContent><State label="posting rules" isLoading={query.isLoading} isError={query.isError} /><DataTable rows={listItems(query.data)} columns={["source_module", "transaction_type", "active", "roundoff_ledger_id"]} /></CardContent></Card></div>;
}

function ListCreateInline({ fields, draft, setDraft, onCreate }: { fields: string[]; draft: FAMRecord; setDraft: (value: FAMRecord | ((current: FAMRecord) => FAMRecord)) => void; onCreate: () => void }) {
  return <Card><CardContent className="grid gap-3 p-4 md:grid-cols-6">{fields.map((field) => <Field key={field} label={field.replace(/_/g, " ")}>{["notes","remarks","narration"].includes(field) ? <RichTextField value={String(draft[field] || "")} onChange={(event) => setDraft((current) => ({ ...current, [field]: numericFields.has(field) ? Number(event.target.value) : event.target.value }))} /> : <Input value={String(draft[field] || "")} onChange={(event) => setDraft((current) => ({ ...current, [field]: numericFields.has(field) ? Number(event.target.value) : event.target.value }))} />}</Field>)}<div className="flex items-end"><Button onClick={onCreate}>Add</Button></div></CardContent></Card>;
}

function AuditView() {
  const query = useQuery({ queryKey: ["fam", "audit"], queryFn: famApi.auditLogs });
  const rows = listItems(query.data);
  return <Card><CardContent className="p-5"><State label="audit logs" isLoading={query.isLoading} isError={query.isError} /><DataTable rows={rows} columns={["performed_at", "record_type", "record_id", "action", "performed_by", "ip_address"]} /></CardContent></Card>;
}

function BankingView() {
  const accounts = useQuery({ queryKey: ["fam", "bankAccounts"], queryFn: famApi.bankAccounts });
  const statements = useQuery({ queryKey: ["fam", "bankStatements"], queryFn: famApi.bankStatements });
  const reconciliation = useQuery({ queryKey: ["fam", "bankReconciliation"], queryFn: famApi.bankReconciliation });
  const accountRows = listItems(accounts.data);
  const statementRows = listItems(statements.data);
  const recon = (reconciliation.data || {}) as FAMRecord;
  return (
    <div className="space-y-4">
      <div className="grid gap-3 md:grid-cols-4">
        <Card><CardContent className="p-4"><p className="text-xs text-muted-foreground">Bank accounts</p><p className="text-2xl font-semibold">{accountRows.length}</p></CardContent></Card>
        <Card><CardContent className="p-4"><p className="text-xs text-muted-foreground">Statements</p><p className="text-2xl font-semibold">{statementRows.length}</p></CardContent></Card>
        <Card><CardContent className="p-4"><p className="text-xs text-muted-foreground">Unmatched lines</p><p className="text-2xl font-semibold">{text(recon.unmatched_count)}</p></CardContent></Card>
        <Card><CardContent className="p-4"><p className="text-xs text-muted-foreground">Bank feeds</p><p className="text-lg font-semibold">Manual import only</p></CardContent></Card>
      </div>
      <Card><CardHeader><CardTitle className="text-base">Banking actions</CardTitle></CardHeader><CardContent className="grid gap-2 sm:grid-cols-2 lg:grid-cols-5">
        {[["Bank Accounts", "/fam/bank-accounts"], ["Statements", "/fam/bank-statements"], ["Reconciliation", "/fam/bank-reconciliation"], ["Bank Book", "/fam/bank-book"], ["Cash Book", "/fam/cash-book"]].map(([label, to]) => <Button key={to} asChild variant="outline"><Link to={to}>{label}</Link></Button>)}
      </CardContent></Card>
      <Card><CardHeader><CardTitle className="text-base">Recent statements</CardTitle></CardHeader><CardContent><State label="banking" isLoading={accounts.isLoading || statements.isLoading || reconciliation.isLoading} isError={accounts.isError || statements.isError || reconciliation.isError} /><DataTable rows={statementRows} columns={["id", "bank_account_id", "statement_period_start", "statement_period_end", "status", "imported_file_name"]} /></CardContent></Card>
    </div>
  );
}

function BankAccountsView() {
  const queryClient = useQueryClient();
  const canWrite = useFinanceWrite(["fam_admin","fam_banking_manage"],"create"),canEdit=useFinanceWrite(["fam_admin","fam_banking_manage"],"edit"),canDelete=useFinanceWrite(["fam_admin","fam_banking_manage"],"delete");
  const query = useQuery({ queryKey: ["fam", "bankAccounts"], queryFn: famApi.bankAccounts });
  const ledgerQuery = useQuery({ queryKey: ["fam", "ledgers", "bank-account-picker"], queryFn: famApi.ledgers });
  const bankLedgers = listItems(ledgerQuery.data).filter(ledger => ledger.ledger_type === "bank" && ledger.active !== false && !listItems(query.data).some(account=>account.ledger_id===ledger.id));
  const [draft, setDraft] = useState<FAMRecord>({ ledger_id: "", bank_name: "", branch_name: "", account_number_masked: "", ifsc: "", account_type: "current", opening_balance: 0, active: true });
  const mutation = useMutation({ mutationFn: () => famApi.createBankAccount(draft), onSuccess: () => { toast({ title: "Bank account saved" }); queryClient.invalidateQueries({ queryKey: ["fam"] }); } , onError: showMutationError });
  return <div className="grid gap-4 lg:grid-cols-[24rem_1fr]"><SmartCreateSection title={<>Create bank account</>} size="compact"><Card><CardHeader><CardTitle className="text-base">Create bank account</CardTitle></CardHeader><CardContent className="space-y-3"><Field label="Bank ledger"><NativeSelect aria-label="Bank ledger" value={String(draft.ledger_id || "")} onChange={event => setDraft(current => ({...current,ledger_id:Number(event.target.value)}))}><option value="">Choose bank ledger</option>{bankLedgers.map(ledger => <option key={String(ledger.id)} value={String(ledger.id)}>{String(ledger.ledger_name || ledger.id)}</option>)}</NativeSelect></Field>{ledgerQuery.isError ? <p role="alert">Bank ledgers could not be loaded.</p> : !ledgerQuery.isLoading && !bankLedgers.length ? <p className="text-sm text-muted-foreground">Create an active bank ledger before registering a bank account.</p> : null}{["bank_name", "branch_name", "account_number_masked", "ifsc", "account_type", "opening_balance"].map((field) => <Field key={field} label={field.replace(/_/g, " ")}><Input value={String(draft[field] ?? "")} onChange={(event) => setDraft((current) => ({ ...current, [field]: numericFields.has(field) ? Number(event.target.value) : event.target.value }))} /></Field>)}<Button className="w-full" onClick={() => mutation.mutate()} disabled={!canWrite || mutation.isPending || !Number(draft.ledger_id) || !String(draft.bank_name || "").trim()} title={!canWrite ? "Write permission required" : undefined}>Save bank account</Button></CardContent></Card></SmartCreateSection><Card><CardHeader><CardTitle className="text-base">Bank accounts</CardTitle></CardHeader><CardContent><State label="bank accounts" isLoading={query.isLoading} isError={query.isError} /><DataTable rows={listItems(query.data).filter(row=>row.active!==false)} columns={["bank_name", "branch_name", "ledger_id", "account_number_masked", "ifsc", "account_type", "opening_balance", "active"]} renderActions={row=><RecordMaintenance record={row} name={String(row.bank_name)} endpoint={`/fam/bank-accounts/${row.id}`} fields={[{key:"bank_name",label:"Bank name",required:true},{key:"branch_name",label:"Branch name"}]} queryKeys={["fam"]} canEdit={canEdit} canDelete={canDelete} mergeRecord/>}/></CardContent></Card></div>;
}

function PaymentModesView() {
  const queryClient = useQueryClient();
  const query = useQuery({ queryKey: ["fam", "paymentModes"], queryFn: famApi.paymentModes });
  const [draft, setDraft] = useState<FAMRecord>({ name: "UPI", type: "upi", default_ledger_id: 1, active: true });
  const mutation = useMutation({ mutationFn: () => famApi.createPaymentMode(draft), onSuccess: () => { toast({ title: "Payment mode saved" }); queryClient.invalidateQueries({ queryKey: ["fam"] }); } , onError: showMutationError });
  return <div className="grid gap-4 lg:grid-cols-[24rem_1fr]"><SmartCreateSection title={<>Create payment mode</>} size="compact"><Card><CardHeader><CardTitle className="text-base">Create payment mode</CardTitle></CardHeader><CardContent className="space-y-3">{["name", "type", "default_ledger_id"].map((field) => <Field key={field} label={field.replace(/_/g, " ")}><Input value={String(draft[field] ?? "")} onChange={(event) => setDraft((current) => ({ ...current, [field]: numericFields.has(field) ? Number(event.target.value) : event.target.value }))} /></Field>)}<Button className="w-full" onClick={() => mutation.mutate()}>Save payment mode</Button></CardContent></Card></SmartCreateSection><Card><CardHeader><CardTitle className="text-base">Payment modes</CardTitle></CardHeader><CardContent><State label="payment modes" isLoading={query.isLoading} isError={query.isError} /><DataTable rows={listItems(query.data)} columns={["name", "type", "default_ledger_id", "active"]} /></CardContent></Card></div>;
}

function BankStatementsView() {
  const queryClient = useQueryClient();
  const query = useQuery({ queryKey: ["fam", "bankStatements"], queryFn: famApi.bankStatements });
  const [draft, setDraft] = useState<FAMRecord>({ bank_account_id: defaultId("bank_account_id", "fam") || "", statement_period_start: "2026-06-01", statement_period_end: "2026-06-30", imported_file_name: "hdfc-june.csv", file_content: "transaction_date,description,reference_number,debit_amount,credit_amount,balance\n2026-06-06,Receipt from customer,REF-1,0,1000,1000" });
  const mutation = useMutation({ mutationFn: () => famApi.importBankStatement(draft), onSuccess: () => { toast({ title: "Bank statement imported" }); queryClient.invalidateQueries({ queryKey: ["fam"] }); } , onError: showMutationError });
  return <div className="grid gap-4 lg:grid-cols-[28rem_1fr]"><Card><CardHeader><CardTitle className="text-base">Upload statement</CardTitle></CardHeader><CardContent className="space-y-3">{["bank_account_id", "statement_period_start", "statement_period_end", "imported_file_name"].map((field) => <Field key={field} label={field.replace(/_/g, " ")}><Input type={field.includes("period") ? "date" : "text"} value={String(draft[field] ?? "")} onChange={(event) => setDraft((current) => ({ ...current, [field]: numericFields.has(field) ? Number(event.target.value) : event.target.value }))} /></Field>)}<ImportWizard title="Map bank statement" label="Choose Excel or CSV" fields={bankStatementFields} confirmLabel="Use mapped statement" onImport={async({rows,filename})=>{setDraft(current=>({...current,imported_file_name:filename.replace(/\.[^.]+$/,".csv"),file_content:csvText(rows)}));return {created:rows.length,message:"Statement prepared. Close this dialog, review the account and period, then click Import statement. Nothing has been posted."};}}/><Field label="CSV content"><textarea className="min-h-36 w-full rounded-md border bg-background px-3 py-2 text-sm" value={String(draft.file_content || "")} onChange={(event) => setDraft((current) => ({ ...current, file_content: event.target.value }))} /></Field><p className="text-xs text-muted-foreground">Manual import only. Statement lines are imported for review and are not posted automatically.</p><Button className="w-full" onClick={() => mutation.mutate()}>Import statement</Button></CardContent></Card><Card><CardHeader><CardTitle className="text-base">Bank statements</CardTitle></CardHeader><CardContent><State label="bank statements" isLoading={query.isLoading} isError={query.isError} /><DataTable rows={listItems(query.data)} columns={["id", "bank_account_id", "statement_period_start", "statement_period_end", "status", "imported_file_name"]} />{listItems(query.data).slice(0, 4).map((item) => <Button key={String(item.id)} asChild variant="link" className="px-0"><Link to={`/fam/bank-statements/${item.id}`}>Open statement #{text(item.id)}</Link></Button>)}</CardContent></Card></div>;
}

function BankStatementDetailView() {
  const { id = "1" } = useParams();
  const queryClient = useQueryClient();
  const query = useQuery({ queryKey: ["fam", "bankStatement", id], queryFn: () => famApi.bankStatement(id) });
  const data = (query.data || {}) as FAMRecord;
  const firstLine = (((data.lines as FAMRecord[] | undefined) || [])[0] || {}) as FAMRecord;
  const action = useMutation({ mutationFn: (run: () => Promise<FAMRecord>) => run(), onSuccess: () => { toast({ title: "Bank reconciliation updated" }); queryClient.invalidateQueries({ queryKey: ["fam"] }); } , onError: showMutationError });
  return <div className="space-y-4"><div className="grid gap-3 md:grid-cols-4">{["status", "bank_account_id", "statement_period_start", "statement_period_end"].map((field) => <Card key={field}><CardContent className="p-4"><p className="text-xs text-muted-foreground">{field.replace(/_/g, " ")}</p><p className="text-lg font-semibold">{text(data[field])}</p></CardContent></Card>)}</div><Card><CardHeader><CardTitle className="text-base">Review and match</CardTitle></CardHeader><CardContent className="flex flex-wrap gap-2"><ActionToolbar label="Bank reconciliation actions" actions={[
    {id:"auto",kind:"refresh",label:"Auto-match",prominent:true,primary:true,disabled:action.isPending || query.isPending,onSelect:()=>action.mutate(()=>famApi.autoMatchBankStatement(id))},
    {id:"match",kind:"approve",label:"Confirm match",prominent:true,disabled:action.isPending || !firstLine.id || !firstLine.matched_voucher_id,onSelect:()=>action.mutate(()=>famApi.matchBankStatement(id,{statement_line_id:Number(firstLine.id),voucher_id:Number(firstLine.matched_voucher_id),matched_amount:Number(firstLine.credit_amount || firstLine.debit_amount || 0),confirm:true})),confirm:{title:"Confirm this bank match?",description:`First statement line #${firstLine.id || "—"}, voucher #${firstLine.matched_voucher_id || "—"}. Review the statement lines and amount below before confirming.`,label:"Confirm match"}},
    {id:"reconcile",kind:"complete",label:"Reconcile statement",prominent:true,disabled:action.isPending || query.isPending,onSelect:()=>action.mutate(()=>famApi.reconcileBankStatement(id)),confirm:{title:"Reconcile this statement?",description:"Review all statement lines and unmatched entries before finalizing reconciliation.",label:"Reconcile statement"}},
    {id:"ignore",kind:"review",label:"Ignore first line",disabled:action.isPending || !firstLine.id,onSelect:()=>action.mutate(()=>famApi.ignoreBankStatementLine(id,{statement_line_id:Number(firstLine.id),reason:"Reviewed as non-book item"})),confirm:{title:"Ignore this statement line?",description:`First statement line #${firstLine.id || "—"}: ${firstLine.description || "No description"}. Confirm that this is a non-book item.`,label:"Ignore line"}},
  ]}/></CardContent></Card><Card><CardHeader><CardTitle className="text-base">Statement lines</CardTitle></CardHeader><CardContent><State label="statement" isLoading={query.isLoading} isError={query.isError} /><DataTable rows={(data.lines as FAMRecord[] | undefined) || []} columns={["transaction_date", "description", "reference_number", "debit_amount", "credit_amount", "balance", "matched_status", "matched_voucher_id"]} /></CardContent></Card></div>;
}

function BankReconciliationView() {
  const query = useQuery({ queryKey: ["fam", "bankReconciliation"], queryFn: famApi.bankReconciliation });
  const data = (query.data || {}) as FAMRecord;
  return <div className="space-y-4"><Card><CardContent className="p-4"><p className="text-xs text-muted-foreground">Unmatched statement lines</p><p className="text-2xl font-semibold">{text(data.unmatched_count)}</p></CardContent></Card><Card><CardHeader><CardTitle className="text-base">Reconciliation sessions</CardTitle></CardHeader><CardContent><State label="bank reconciliation" isLoading={query.isLoading} isError={query.isError} /><DataTable rows={(data.sessions as FAMRecord[] | undefined) || []} columns={["statement_id", "bank_account_id", "book_balance", "bank_statement_balance", "status", "reconciled_at"]} /></CardContent></Card><Card><CardHeader><CardTitle className="text-base">Statements</CardTitle></CardHeader><CardContent><DataTable rows={(data.statements as FAMRecord[] | undefined) || []} columns={["id", "bank_account_id", "status", "statement_period_start", "statement_period_end"]} /></CardContent></Card></div>;
}

function BookView({ kind }: { kind: "bank" | "cash" }) {
  const query = useQuery({ queryKey: ["fam", `${kind}Book`], queryFn: kind === "bank" ? famApi.bankBook : famApi.cashBook });
  const data = (query.data || {}) as FAMRecord;
  const summaryCards: Array<[string, unknown]> = [["Opening", data.openingBalance], ["Debit", data.debitTotal], ["Credit", data.creditTotal], ["Closing", data.closingBalance]];
  return <div className="space-y-4"><div className="grid gap-3 md:grid-cols-4">{summaryCards.map(([label, value]) => <Card key={label}><CardContent className="p-4"><p className="text-xs text-muted-foreground">{label}</p><p className="text-lg font-semibold">{money(value)}</p></CardContent></Card>)}</div><Card><CardHeader><CardTitle className="text-base">{kind === "bank" ? "Bank" : "Cash"} ledgers</CardTitle></CardHeader><CardContent><State label={`${kind} book`} isLoading={query.isLoading} isError={query.isError} /><DataTable rows={(data.ledgers as FAMRecord[] | undefined) || []} columns={["ledger_code", "ledger_name", "ledger_type", "current_balance_dr", "current_balance_cr"]} /></CardContent></Card><Card><CardHeader><CardTitle className="text-base">Voucher entries</CardTitle></CardHeader><CardContent><DataTable rows={(data.items as FAMRecord[] | undefined) || []} columns={["voucher_date", "voucher_number", "ledger_id", "debit_amount", "credit_amount", "running_balance", "narration"]} /></CardContent></Card></div>;
}

function ContraView() {
  const [draft, setDraft] = useState<FAMRecord>({ from_ledger_id: 1, to_ledger_id: 2, amount: 1000, contra_date: "2026-06-06", reference_number: "CONTRA-1", narration: "Cash deposited to bank" });
  const mutation = useMutation({ mutationFn: () => famApi.postContra(draft), onSuccess: () => toast({ title: "Contra voucher posted" }) , onError: showMutationError });
  return <Card><CardHeader><CardTitle className="text-base">Post contra entry</CardTitle></CardHeader><CardContent className="grid gap-3 md:grid-cols-2">{["from_ledger_id", "to_ledger_id", "amount", "contra_date", "reference_number", "narration"].map((field) => <Field key={field} label={field.replace(/_/g, " ")}>{["narration","notes","remarks"].includes(field) ? <RichTextField  value={String(draft[field] ?? "")} onChange={(event) => setDraft((current) => ({ ...current, [field]: numericFields.has(field) ? Number(event.target.value) : event.target.value }))} /> : <Input type={field.includes("date") ? "date" : "text"} value={String(draft[field] ?? "")} onChange={(event) => setDraft((current) => ({ ...current, [field]: numericFields.has(field) ? Number(event.target.value) : event.target.value }))} />}</Field>)}<div className="md:col-span-2"><Button onClick={() => mutation.mutate()}>Post contra</Button></div></CardContent></Card>;
}

function BankChargesView() {
  const [draft, setDraft] = useState<FAMRecord>({ bank_account_id: defaultId("bank_account_id", "fam") || "", expense_ledger_id: 1, amount: 250, charge_date: "2026-06-06", reference_number: "CHG-1", narration: "Monthly bank charges" });
  const mutation = useMutation({ mutationFn: () => famApi.postBankCharges(draft), onSuccess: () => toast({ title: "Bank charge voucher posted" }) , onError: showMutationError });
  return <Card><CardHeader><CardTitle className="text-base">Post bank charges</CardTitle></CardHeader><CardContent className="grid gap-3 md:grid-cols-2">{["bank_account_id", "expense_ledger_id", "amount", "charge_date", "reference_number", "narration"].map((field) => <Field key={field} label={field.replace(/_/g, " ")}>{["narration","notes","remarks"].includes(field) ? <RichTextField  value={String(draft[field] ?? "")} onChange={(event) => setDraft((current) => ({ ...current, [field]: numericFields.has(field) ? Number(event.target.value) : event.target.value }))} /> : <Input type={field.includes("date") ? "date" : "text"} value={String(draft[field] ?? "")} onChange={(event) => setDraft((current) => ({ ...current, [field]: numericFields.has(field) ? Number(event.target.value) : event.target.value }))} />}</Field>)}<div className="md:col-span-2"><Button onClick={() => mutation.mutate()}>Post bank charge</Button></div></CardContent></Card>;
}

function GSTHomeView() {
  const links = [["Registrations", "/fam/gst/registrations"], ["Rates", "/fam/gst/rates"], ["HSN/SAC", "/fam/gst/hsn-sac"], ["Sales Register", "/fam/gst/sales-register"], ["Purchase Register", "/fam/gst/purchase-register"], ["GSTR-1", "/fam/gst/gstr1"], ["GSTR-3B", "/fam/gst/gstr3b"], ["E-Invoice", "/fam/gst/einvoice"], ["E-Way Bill", "/fam/gst/ewaybill"], ["Reconciliation", "/fam/gst/reconciliation"]];
  return (
    <div className="space-y-4">
      <ComplianceReadinessPanel />
      <div className="grid gap-3 md:grid-cols-3">
        {links.map(([label, href]) => <Card key={href}><CardContent className="flex items-center justify-between p-4"><span className="font-medium">{label}</span><Button asChild variant="outline"><Link to={href}>Open</Link></Button></CardContent></Card>)}
      </div>
    </div>
  );
}

function GSTMasterView({ kind }: { kind: "registrations" | "rates" | "hsn" }) {
  const queryClient = useQueryClient();
  const config = {
    registrations: { queryKey: "gstRegistrations", queryFn: famApi.gstRegistrations, mutationFn: famApi.createGstRegistration, fields: ["gstin", "legal_name", "trade_name", "state_code", "registration_type", "effective_from"], columns: ["gstin", "legal_name", "state_code", "registration_type", "effective_from", "active"], draft: { registration_type: "regular", effective_from: "2026-04-01", active: true } },
    rates: { queryKey: "gstRates", queryFn: famApi.gstRates, mutationFn: famApi.createGstRate, fields: ["rate_name", "tax_type", "cgst_rate", "sgst_rate", "igst_rate", "cess_rate", "effective_from"], columns: ["rate_name", "tax_type", "cgst_rate", "sgst_rate", "igst_rate", "cess_rate", "effective_from", "active"], draft: { tax_type: "goods", cgst_rate: 9, sgst_rate: 9, igst_rate: 18, cess_rate: 0, effective_from: "2026-04-01", active: true } },
    hsn: { queryKey: "hsnSac", queryFn: famApi.hsnSac, mutationFn: famApi.createHsnSac, fields: ["code", "description", "type", "default_gst_rate_id"], columns: ["code", "description", "type", "default_gst_rate_id", "active"], draft: { type: "hsn", active: true } },
  }[kind];
  const query = useQuery({ queryKey: ["fam", config.queryKey], queryFn: config.queryFn });
  const [draft, setDraft] = useState<FAMRecord>(config.draft);
  const mutation = useMutation({ mutationFn: () => config.mutationFn(draft), onSuccess: () => { toast({ title: "GST master saved" }); queryClient.invalidateQueries({ queryKey: ["fam"] }); } , onError: showMutationError });
  return <div className="grid gap-4 lg:grid-cols-[24rem_1fr]"><SmartCreateSection title={<>Create {kind}</>} size="compact"><Card><CardHeader><CardTitle className="text-base">Create {kind}</CardTitle></CardHeader><CardContent className="space-y-3">{config.fields.map((field) => <Field key={field} label={field.replace(/_/g, " ")}>{["narration","notes","remarks"].includes(field) ? <RichTextField  value={String(draft[field] ?? "")} onChange={(event) => setDraft((current) => ({ ...current, [field]: numericFields.has(field) ? Number(event.target.value) : event.target.value }))} /> : <Input type={field.includes("date") ? "date" : "text"} value={String(draft[field] ?? "")} onChange={(event) => setDraft((current) => ({ ...current, [field]: numericFields.has(field) ? Number(event.target.value) : event.target.value }))} />}</Field>)}<Button className="w-full" onClick={() => mutation.mutate()}>Save</Button></CardContent></Card></SmartCreateSection><Card><CardHeader><CardTitle className="text-base">Records</CardTitle></CardHeader><CardContent><State label={kind} isLoading={query.isLoading} isError={query.isError} /><DataTable rows={listItems(query.data)} columns={config.columns} /></CardContent></Card></div>;
}

function GSTSettingsView() {
  return <div className="space-y-4"><ComplianceReadinessPanel /><div className="grid gap-4 md:grid-cols-2"><ProviderSettingsView kind="einvoice" /><ProviderSettingsView kind="ewaybill" /></div></div>;
}

function ComplianceReadinessPanel() {
  const einvoice = useQuery({ queryKey: ["fam", "einvoice", "settings"], queryFn: famApi.einvoiceSettings });
  const ewaybill = useQuery({ queryKey: ["fam", "ewaybill", "settings"], queryFn: famApi.ewaybillSettings });
  const tds = useQuery({ queryKey: ["fam", "tdsPayable"], queryFn: famApi.tdsPayable });
  const bank = useQuery({ queryKey: ["fam", "bankReconciliation"], queryFn: famApi.bankReconciliation });
  const srm = useQuery({ queryKey: ["fam", "srmIntegrationStatus"], queryFn: famApi.srmIntegrationStatus });
  const einvoiceReady = providerReady(einvoice.data);
  const ewayReady = providerReady(ewaybill.data);
  const bankData = (bank.data || {}) as FAMRecord;
  const tdsData = (tds.data || {}) as FAMRecord;
  const srmData = (srm.data || {}) as FAMRecord;
  const rows = [
    {
      label: "GST Returns",
      status: "prepare_only",
      ready: false,
      detail: "GSTR-1 and GSTR-3B can be prepared and exported. GST portal filing remains blocked until a portal provider is connected.",
      action: "/fam/gst/gstr1",
    },
    {
      label: "E-Invoice IRN",
      status: einvoiceReady ? "configured" : "not_configured",
      ready: einvoiceReady,
      detail: einvoiceReady ? "Provider credentials and active flag are set. IRN generation queues provider jobs." : "Add provider name, API URL, credentials flag, and active status before IRN jobs can queue.",
      action: "/fam/gst/einvoice",
    },
    {
      label: "E-Way Bill",
      status: ewayReady ? "configured" : "not_configured",
      ready: ewayReady,
      detail: ewayReady ? "Provider credentials and threshold are configured. Eligible movement jobs can queue." : "Configure provider credentials, active status, and threshold before EWB jobs can queue.",
      action: "/fam/gst/ewaybill",
    },
    {
      label: "TDS Compliance",
      status: tdsData.filing_status || "not_configured",
      ready: false,
      detail: `TDS payable is tracked at ${money(tdsData.tds_payable)}. Return filing/export remains a prepared-register workflow until filing integration exists.`,
      action: "/fam/tds/payable",
    },
    {
      label: "Bank Feeds",
      status: "manual_import_only",
      ready: false,
      detail: `${text(bankData.unmatched_count)} unmatched statement lines. Bank feeds use CSV import, matching, and reconciliation; automatic API/OFX feeds are not enabled.`,
      action: "/fam/bank-statements",
    },
    {
      label: "SRM Posting",
      status: Number(srmData.failed_postings || 0) ? "warning" : "preflight_ready",
      ready: !Number(srmData.failed_postings || 0),
      detail: `${text(srmData.pending_postings)} pending, ${text(srmData.failed_postings)} failed. Posting rules and ledger mappings are validated before voucher creation.`,
      action: "/fam/integrations/srm",
    },
  ];
  const loading = einvoice.isLoading || ewaybill.isLoading || tds.isLoading || bank.isLoading || srm.isLoading;
  const error = einvoice.isError || ewaybill.isError || tds.isError || bank.isError || srm.isError;
  return (
    <Card>
      <CardHeader><CardTitle className="text-base">Statutory and integration readiness</CardTitle></CardHeader>
      <CardContent className="space-y-3">
        <State label="readiness" isLoading={loading} isError={error} />
        <GroupedRecords scope="apps/fam/FAMWorkspacePage:cards-1" items={(rows) || []} fields={standardRecordGroups((rows) || [])} gridClassName="grid gap-3 lg:grid-cols-2" renderItem={(row) => (
            <div key={row.label} className="rounded-lg border p-3">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="font-medium">{row.label}</p>
                  <p className="mt-1 text-sm text-muted-foreground">{row.detail}</p>
                </div>
                <Badge variant={row.ready ? "default" : statusTone(row.status)}>{text(row.status)}</Badge>
              </div>
              <Button asChild variant="outline" size="sm" className="mt-3"><Link to={row.action}>Open</Link></Button>
            </div>
          )}/>
      </CardContent>
    </Card>
  );
}

function providerReady(data: unknown) {
  const record = (data || {}) as FAMRecord;
  return Boolean(record.credentials_configured && record.active);
}

function GSTRegisterView({ kind }: { kind: "sales" | "purchase" }) {
  const query = useQuery({ queryKey: ["fam", "gst", kind], queryFn: kind === "sales" ? famApi.gstSalesRegister : famApi.gstPurchaseRegister });
  const data = (query.data || {}) as FAMRecord;
  return <Card><CardHeader><CardTitle className="text-base">{kind === "sales" ? "Sales" : "Purchase"} GST register</CardTitle></CardHeader><CardContent><State label={`${kind} register`} isLoading={query.isLoading} isError={query.isError} /><div className="mb-3 grid gap-3 md:grid-cols-5">{["taxable_value", "cgst_amount", "sgst_amount", "igst_amount", "cess_amount"].map((key) => <Card key={key}><CardContent className="p-3"><p className="text-xs text-muted-foreground">{key.replace(/_/g, " ")}</p><p className="font-semibold">{money((data.totals as FAMRecord | undefined)?.[key])}</p></CardContent></Card>)}</div><DataTable rows={listItems(query.data)} columns={["transaction_type", "supply_type", "gstin", "place_of_supply_state", "hsn_sac_code", "taxable_value", "cgst_amount", "sgst_amount", "igst_amount", "itc_eligible", "reverse_charge"]} /></CardContent></Card>;
}

function GSTReturnView({ kind }: { kind: "gstr1" | "gstr3b" }) {
  const queryClient = useQueryClient();
  const query = useQuery({ queryKey: ["fam", kind], queryFn: kind === "gstr1" ? famApi.gstr1 : famApi.gstr3b });
  const data = (query.data || {}) as FAMRecord;
  const [draft, setDraft] = useState<FAMRecord>({ period_month: 6, period_year: 2026 });
  const mutation = useMutation({ mutationFn: () => kind === "gstr1" ? famApi.prepareGstr1(draft) : famApi.prepareGstr3b(draft), onSuccess: () => { toast({ title: `${kind.toUpperCase()} prepared` }); queryClient.invalidateQueries({ queryKey: ["fam"] }); } , onError: showMutationError });
  return <div className="grid gap-4 lg:grid-cols-[20rem_1fr]"><Card><CardHeader><CardTitle className="text-base">Prepare {kind.toUpperCase()}</CardTitle></CardHeader><CardContent className="space-y-3">{["period_month", "period_year"].map((field) => <Field key={field} label={field.replace(/_/g, " ")}><Input value={String(draft[field])} onChange={(event) => setDraft((current) => ({ ...current, [field]: Number(event.target.value) }))} /></Field>)}<Badge variant={statusTone(data.portal_status)}>{text(data.portal_status || "not_configured")}</Badge><p className="text-xs text-muted-foreground">Working return only. GST portal filing is not integrated until a GST provider is connected.</p><Button className="w-full" onClick={() => mutation.mutate()}>Prepare</Button><ExportButton exportType="gst_summary" label="Export GST summary CSV" /></CardContent></Card><Card><CardHeader><CardTitle className="text-base">Prepared records</CardTitle></CardHeader><CardContent><State label={kind} isLoading={query.isLoading} isError={query.isError} /><DataTable rows={listItems(query.data)} columns={["section", "taxable_value", "cgst_amount", "sgst_amount", "igst_amount", "cess_amount", "record_count"]} /></CardContent></Card></div>;
}

function GSTReconciliationView() {
  const query = useQuery({ queryKey: ["fam", "gstReconciliation"], queryFn: famApi.gstReconciliation });
  return <Card><CardHeader><CardTitle className="text-base">GST reconciliation foundation</CardTitle></CardHeader><CardContent><State label="GST reconciliation" isLoading={query.isLoading} isError={query.isError} /><p className="mb-3 text-sm text-muted-foreground">External portal reconciliation is not configured. Exceptions are tracked without pretending portal data exists.</p><DataTable rows={listItems(query.data)} columns={["source_type", "source_record_id", "mismatch_type", "expected_amount", "actual_amount", "status", "notes"]} /></CardContent></Card>;
}

function ProviderSettingsView({ kind }: { kind: "einvoice" | "ewaybill" }) {
  const queryClient = useQueryClient();
  const isEinvoice = kind === "einvoice";
  const query = useQuery({ queryKey: ["fam", kind, "settings"], queryFn: isEinvoice ? famApi.einvoiceSettings : famApi.ewaybillSettings });
  const [draft, setDraft] = useState<FAMRecord>({});
  const [voucherId, setVoucherId] = useState("1");
  const [message, setMessage] = useState("");
  const effective = { ...((query.data || {}) as FAMRecord), ...draft };
  const save = useMutation({
    mutationFn: () => isEinvoice ? famApi.updateEinvoiceSettings(effective) : famApi.updateEwaybillSettings(effective),
    onSuccess: () => { setMessage("Provider settings saved"); toast({ title: "Provider settings saved" }); queryClient.invalidateQueries({ queryKey: ["fam"] }); },
    onError: (err: unknown) => { const textValue = apiErrorMessage(err, "Provider settings failed"); setMessage(textValue); toast({ title: "Provider settings failed", description: textValue, variant: "destructive" }); },
  });
  const generate = useMutation({
    mutationFn: () => isEinvoice ? famApi.generateEinvoice(voucherId) : famApi.generateEwaybill(voucherId),
    onSuccess: (data) => {
      const record = data as FAMRecord;
      const textValue = text(record.message || record.status || "Provider job created");
      setMessage(textValue);
      toast({ title: textValue });
      queryClient.invalidateQueries({ queryKey: ["fam"] });
    },
    onError: (err: unknown) => { const textValue = apiErrorMessage(err, "Provider job failed"); setMessage(textValue); toast({ title: "Provider job failed", description: textValue, variant: "destructive" }); },
  });
  const checks = [
    ["Provider name", Boolean(effective.provider_name)],
    ["API base URL", Boolean(effective.api_base_url)],
    ["Credentials marked configured", Boolean(effective.credentials_configured)],
    ["Provider active", Boolean(effective.active)],
    [isEinvoice ? "Applicable date captured" : "Threshold captured", isEinvoice ? Boolean(effective.applicable_from) : Number(effective.threshold_amount || 0) > 0],
  ] as Array<[string, boolean]>;
  const ready = checks.every(([, passed]) => passed);
  return (
    <Card>
      <CardHeader><CardTitle className="text-base">{isEinvoice ? "E-Invoice" : "E-Way Bill"} provider</CardTitle></CardHeader>
      <CardContent className="space-y-3">
        <State label={`${kind} settings`} isLoading={query.isLoading} isError={query.isError} />
        <Badge variant={ready ? "default" : "secondary"}>{ready ? "configured" : "not configured"}</Badge>
        {["provider_name", "api_base_url", ...(isEinvoice ? ["applicable_from"] : ["threshold_amount"])].map((field) => <Field key={field} label={field.replace(/_/g, " ")}>{["narration","notes","remarks"].includes(field) ? <RichTextField  value={String(effective[field] ?? "")} onChange={(event) => setDraft((current) => ({ ...current, [field]: numericFields.has(field) ? Number(event.target.value) : event.target.value }))} /> : <Input type={field.includes("date") ? "date" : "text"} value={String(effective[field] ?? "")} onChange={(event) => setDraft((current) => ({ ...current, [field]: numericFields.has(field) ? Number(event.target.value) : event.target.value }))} />}</Field>)}
        <div className="grid gap-3 sm:grid-cols-2"><label className="flex items-center justify-between rounded-md border px-3 py-2 text-sm"><span>Credentials configured</span><input type="checkbox" checked={Boolean(effective.credentials_configured)} onChange={(event) => setDraft((current) => ({ ...current, credentials_configured: event.target.checked }))} /></label><label className="flex items-center justify-between rounded-md border px-3 py-2 text-sm"><span>Active</span><input type="checkbox" checked={Boolean(effective.active)} onChange={(event) => setDraft((current) => ({ ...current, active: event.target.checked }))} /></label></div>
        <div className="rounded-lg border p-3">
          <p className="text-sm font-medium">Provider preflight</p>
          <div className="mt-3 grid gap-2">
            {checks.map(([label, passed]) => (
              <div key={label} className="flex items-center justify-between rounded-md border px-3 py-2 text-sm">
                <span>{label}</span>
                <Badge variant={passed ? "default" : "secondary"}>{passed ? "Ready" : "Missing"}</Badge>
              </div>
            ))}
          </div>
        </div>
        <Field label="Voucher ID"><Input inputMode="numeric" value={voucherId} onChange={(event) => setVoucherId(event.target.value)} /></Field>
        <div className="flex flex-wrap gap-2"><Button onClick={() => save.mutate()} disabled={save.isPending}>Save settings</Button><Button variant="outline" onClick={() => generate.mutate()} disabled={generate.isPending || !voucherId}>Generate test job</Button></div>
        {message ? <p className="text-sm text-muted-foreground">{message}</p> : null}
        <p className="text-xs text-muted-foreground">No IRN or EWB number is generated unless a real provider is configured. Test jobs return not_configured when credentials are missing.</p>
      </CardContent>
    </Card>
  );
}

function PurchasesHomeView() {
  const links = [
    ["Purchase Bills", "/fam/purchase-bills"],
    ["Expenses", "/fam/expenses"],
    ["TDS", "/fam/tds"],
    ["Purchase Register", "/fam/purchase-register"],
    ["Expense Register", "/fam/expense-register"],
    ["Vendor Payments", "/fam/vendor-payments"],
    ["Payables Dashboard", "/fam/payables/dashboard"],
  ];
  return <div className="grid gap-3 md:grid-cols-3">{links.map(([label, href]) => <Card key={href}><CardContent className="flex items-center justify-between p-4"><span className="font-medium">{label}</span><Button asChild variant="outline"><Link to={href}>Open</Link></Button></CardContent></Card>)}</div>;
}

function defaultPurchaseBill(): FAMRecord {
  return {
    vendor_id: "",
    bill_number: `PB-${Date.now().toString().slice(-5)}`,
    bill_date: new Date().toLocaleDateString("en-CA"),
    due_date: defaultDateAfter("payment_terms_days", "fam"),
    gstin: "",
    place_of_supply: "",
    discount_total: 0,
    lines: [{ expense_ledger_id: "", description: "", hsn_sac: "", quantity: 1, rate: 0, taxable_value: 0, gst_amount: 0, tds_section_id: "", tds_amount: 0, line_total: 0 }],
  };
}

function PurchaseBillFormView({ detail }: { detail?: boolean }) {
  const phone=useMobile(480);
  const financialSettings = useQuery({ queryKey: ["fam", "settings"], queryFn: famApi.settings });
  const isUAE = ["AE", "UAE"].includes(String(financialSettings.data?.country_code || "").toUpperCase());
  const taxFieldLabel = (field: string) => isUAE && field === "gst_amount" ? "Recoverable VAT" : isUAE && field === "gstin" ? "TRN" : field.replace(/_/g, " ");
  const billLineFields = ["expense_ledger_id", "description", "hsn_sac", "quantity", "rate", "taxable_value", "gst_amount", "tds_section_id", "tds_amount", "line_total"].filter(field => !isUAE || !["hsn_sac", "tds_section_id", "tds_amount"].includes(field));
  const params = useParams();
  const queryClient = useQueryClient();
  const billQuery = useQuery({ queryKey: ["fam", "purchaseBill", params.id], queryFn: () => famApi.purchaseBill(params.id || "1"), enabled: Boolean(detail && params.id) });
  const [draft, setDraft] = useState<FAMRecord>(defaultPurchaseBill());
  const effective = (detail && billQuery.data ? billQuery.data : draft) as FAMRecord;
  const lines = ((effective.lines as FAMRecord[] | undefined) || []) as FAMRecord[];
  const subtotal = lines.reduce((sum, line) => sum + Number(line.taxable_value || (Number(line.quantity || 0) * Number(line.rate || 0))), 0);
  const gstTotal = lines.reduce((sum, line) => sum + Number(line.gst_amount || 0), 0);
  const tdsTotal = lines.reduce((sum, line) => sum + Number(line.tds_amount || 0), 0);
  const grandTotal = subtotal + gstTotal - Number(effective.discount_total || 0) - tdsTotal;
  const billId = String(effective.id || params.id || "");
  const canEdit = String(effective.status || "draft") === "draft" && !detail;
  const patch = (key: string, value: unknown) => setDraft((current) => ({ ...effective, ...current, [key]: numericFields.has(key) ? Number(value) : value }));
  const patchLine = (index: number, key: string, value: unknown) => patch("lines", lines.map((line, lineIndex) => lineIndex === index ? { ...line, [key]: numericFields.has(key) ? Number(value) : value } : line));
  const save = useMutation({ mutationFn: () => detail && billId ? famApi.updatePurchaseBill(billId, effective) : famApi.createPurchaseBill(effective), onSuccess: () => { toast({ title: "Purchase bill saved" }); queryClient.invalidateQueries({ queryKey: ["fam"] }); } , onError: showMutationError });
  const post = useMutation({ mutationFn: () => famApi.postPurchaseBill(billId), onSuccess: () => { toast({ title: "Purchase bill posted" }); queryClient.invalidateQueries({ queryKey: ["fam"] }); } , onError: showMutationError });
  const cancel = useMutation({ mutationFn: () => famApi.cancelPurchaseBill(billId), onSuccess: () => { toast({ title: "Purchase bill cancelled" }); queryClient.invalidateQueries({ queryKey: ["fam"] }); } , onError: showMutationError });
  const addLine=() => patch("lines", [...lines, { expense_ledger_id: "", description: "", quantity: 1, rate: 0, taxable_value: 0, gst_amount: 0, tds_amount: 0, line_total: 0 }]);
  const phoneDetailUnavailable=Boolean(phone&&detail&&(!billQuery.data||billQuery.isFetching||billQuery.isError));
  const fieldsEditable=canEdit&&!(phone&&save.isPending);
  if(phone&&detail&&!billQuery.data)return <State label="purchase bill" isLoading={billQuery.isLoading} isError={billQuery.isError}/>;
  return (
    <CompactFields className="space-y-4 fam-mobile-purchase-form">
      {isUAE && <p className="text-sm text-muted-foreground">Enter recoverable VAT in the company base currency. Include non-recoverable VAT in the expense amount. Configure the existing input VAT account in UAE tax settings; VAT201 workings require reconciled AED figures.</p>}
      <State label="purchase bill" isLoading={billQuery.isLoading} isError={billQuery.isError} />
      <div data-form-section-label="Bill details" className="grid gap-3 md:grid-cols-4 fam-purchase-details">
        {["vendor_id", "bill_number", "bill_date", "due_date", "gstin", "place_of_supply", "discount_total"].map((field) => <Field key={field} label={phone&&field==="vendor_id"?"Vendor":taxFieldLabel(field)}>{phone&&field==="vendor_id"?<FinancialRecordLookup kind="vendor" value={String(effective.vendor_id??"")} onChange={value=>patch("vendor_id",value)} disabled={!fieldsEditable}/>: ["narration","notes","remarks"].includes(field) ? <RichTextField  value={String(effective[field] ?? "")} onChange={(event) => patch(field, event.target.value)} disabled={phone?!fieldsEditable:detail&&!canEdit} /> : <Input type={field.includes("date") ? "date" : "text"} value={String(effective[field] ?? "")} onChange={(event) => patch(field, event.target.value)} disabled={phone?!fieldsEditable:detail&&!canEdit} />}</Field>)}
        <Card><CardContent className="p-4"><p className="text-xs text-muted-foreground">Status</p><Badge variant={statusTone(effective.status || "draft")}>{text(effective.status || "draft")}</Badge></CardContent></Card>
      </div>
      <Card className="fam-purchase-lines"><CardHeader><CardTitle className="text-base">Bill lines</CardTitle></CardHeader><CardContent className="space-y-3">{phone&&<FinancialMobileLineEditor title="Bill line" lines={lines} fields={billLineFields.map(key=>({key,label:taxFieldLabel(key),wide:key==="description",lookup:key==="expense_ledger_id"?"ledger":undefined,inputMode:numericFields.has(key)?"decimal":undefined}))} canEdit={fieldsEditable} onChange={patchLine} onAdd={!detail?addLine:undefined}/>}<div className="overflow-x-auto rounded-lg border fam-purchase-line-grid" role={phone?"region":undefined} aria-label={phone?"Full bill lines, scroll for all fields":undefined} tabIndex={phone?0:undefined}><GridTable gridId="apps/fam/FAMWorkspacePage:table-3" className="w-full min-w-[980px] text-sm"><thead className="bg-muted/60 text-left text-xs uppercase text-muted-foreground"><tr>{billLineFields.map((column) => <th key={column} className="px-3 py-2">{taxFieldLabel(column)}</th>)}</tr></thead><tbody>{lines.map((line, index) => <tr {...recordPreviewProps(line)} key={index} className="border-t">{billLineFields.map((field) => <td key={field} className="px-3 py-2"><Input aria-label={phone?`Line ${index+1} ${taxFieldLabel(field)}`:undefined} value={String(line[field] ?? "")} onChange={(event) => patchLine(index, field, event.target.value)} disabled={phone?!fieldsEditable:detail&&!canEdit} /></td>)}</tr>)}</tbody></GridTable></div>{!detail ? <Button variant="outline" onClick={addLine}><Plus className="h-4 w-4" />Add line</Button> : null}</CardContent></Card>
      <div className="grid gap-3 md:grid-cols-4 fam-purchase-totals">
        <Card><CardContent className="p-4"><p className="text-xs text-muted-foreground">Subtotal</p><p className="text-lg font-semibold">{money(effective.subtotal || subtotal)}</p></CardContent></Card>
        <Card><CardContent className="p-4"><p className="text-xs text-muted-foreground">{isUAE ? "Recoverable input VAT" : "Input GST"}</p><p className="text-lg font-semibold">{money(effective.gst_total || gstTotal)}</p></CardContent></Card>
        {!isUAE && <Card><CardContent className="p-4"><p className="text-xs text-muted-foreground">TDS deduction</p><p className="text-lg font-semibold">{money(effective.tds_amount || tdsTotal)}</p></CardContent></Card>}
        <Card><CardContent className="p-4"><p className="text-xs text-muted-foreground">Grand total</p><p className="text-lg font-semibold">{money(effective.grand_total || grandTotal)}</p></CardContent></Card>
      </div>
      <div className="flex flex-wrap gap-2 fam-financial-save-actions">
        <Button onClick={() => save.mutate()} disabled={save.isPending||phoneDetailUnavailable}><Save className="h-4 w-4" />Save bill</Button>
        {billId ? <Button variant="outline" onClick={() => post.mutate()} disabled={phoneDetailUnavailable||post.isPending || String(effective.status) !== "draft"}>Post bill</Button> : null}
        {billId ? <Button variant="outline" onClick={() => cancel.mutate()} disabled={phoneDetailUnavailable||cancel.isPending || ["paid", "cancelled"].includes(String(effective.status))}>Cancel bill</Button> : null}
      </div>
      {detail ? <Card><CardHeader><CardTitle className="text-base">Audit trail</CardTitle></CardHeader><CardContent><DataTable rows={(effective.audit_logs as FAMRecord[] | undefined) || []} columns={["action", "performed_by", "performed_at", "remarks"]} /></CardContent></Card> : null}
    </CompactFields>
  );
}

function PurchaseBillsView() {
  const query = useQuery({ queryKey: ["fam", "purchaseBills"], queryFn: famApi.purchaseBills });
  const rows = listItems(query.data);
  return <Card><CardHeader><CardTitle className="text-base">Vendor bills</CardTitle></CardHeader><CardContent className="space-y-3"><Button asChild><Link to="/fam/purchase-bills/new"><Plus className="h-4 w-4" />New purchase bill</Link></Button><State label="purchase bills" isLoading={query.isLoading} isError={query.isError} /><DataTable rows={rows} columns={["bill_number", "vendor_id", "bill_date", "due_date", "subtotal", "gst_total", "tds_amount", "grand_total", "status", "voucher_id"]} />{rows.slice(0, 4).map((item) => <Button key={String(item.id)} asChild variant="link" className="px-0"><Link to={`/fam/purchase-bills/${item.id}`}>Open bill {text(item.bill_number)}</Link></Button>)}</CardContent></Card>;
}

function ExpenseFormView() {
  const phone=useMobile(480);
  const queryClient = useQueryClient();
  const financialSettings = useQuery({ queryKey: ["fam", "settings"], queryFn: famApi.settings });
  const isUAE = ["AE", "UAE"].includes(String(financialSettings.data?.country_code || "").toUpperCase());
  const [draft, setDraft] = useState<FAMRecord>({ claimant_name: "Finance User", claim_number: "EXP-001", claim_date: "2026-06-06", status: "draft", lines: [{ expense_ledger_id: 1, description: "Travel expense", taxable_value: 1200, gst_amount: 0 }] });
  const lines = (draft.lines as FAMRecord[]) || [];
  const total = lines.reduce((sum, line) => sum + Number(line.taxable_value || 0) + Number(line.gst_amount || 0), 0);
  const mutation = useMutation({ mutationFn: () => famApi.createExpense(draft), onSuccess: () => { toast({ title: "Expense claim saved" }); queryClient.invalidateQueries({ queryKey: ["fam"] }); } , onError: showMutationError });
  const addLine=() => setDraft((current) => ({ ...current, lines: [...lines, { expense_ledger_id: 1, description: "", taxable_value: 0, gst_amount: 0 }] }));
  const patchLine=(index:number,key:string,value:string)=>setDraft(current=>({...current,lines:lines.map((line,i)=>i===index?{...line,[key]:numericFields.has(key)?Number(value):value}:line)}));
  return <CompactFields className="space-y-4 fam-mobile-expense-form"><div data-form-section-label="Claim details" className="grid gap-3 md:grid-cols-4 fam-expense-details">{["claimant_name", "claim_number", "claim_date", "status"].map((field) => <Field key={field} label={isUAE && field === "gst_amount" ? "Recoverable VAT" : field.replace(/_/g, " ")}>{["narration","notes","remarks"].includes(field) ? <RichTextField  value={String(draft[field] ?? "")} onChange={(event) => setDraft((current) => ({ ...current, [field]: numericFields.has(field) ? Number(event.target.value) : event.target.value }))} /> : <Input type={field.includes("date") ? "date" : "text"} value={String(draft[field] ?? "")} onChange={(event) => setDraft((current) => ({ ...current, [field]: numericFields.has(field) ? Number(event.target.value) : event.target.value }))} />}</Field>)}</div><Card className="fam-expense-lines"><CardHeader><CardTitle className="text-base">Expense lines</CardTitle></CardHeader><CardContent className="space-y-3">{phone&&<FinancialMobileLineEditor title="Expense line" lines={lines} fields={["expense_ledger_id","description","taxable_value","gst_amount"].map(key=>({key,label:isUAE&&key==="gst_amount"?"Recoverable VAT":key.replace(/_/g," "),wide:key==="description",lookup:key==="expense_ledger_id"?"ledger":undefined,inputMode:numericFields.has(key)?"decimal":undefined}))} canEdit={!mutation.isPending} onChange={patchLine} onAdd={addLine} addLabel="Add expense line"/>}{lines.map((line, index) => <div key={index} className="grid gap-3 md:grid-cols-4 fam-expense-line">{["expense_ledger_id", "description", "taxable_value", "gst_amount"].map((field) => <Field key={field} label={isUAE && field === "gst_amount" ? "Recoverable VAT" : field.replace(/_/g, " ")}><Input aria-label={phone?`Line ${index+1} ${isUAE&&field==="gst_amount"?"Recoverable VAT":field.replace(/_/g," ")}`:undefined} value={String(line[field] ?? "")} onChange={(event) => setDraft((current) => ({ ...current, lines: lines.map((item, lineIndex) => lineIndex === index ? { ...item, [field]: numericFields.has(field) ? Number(event.target.value) : event.target.value } : item) }))} /></Field>)}</div>)}<Button variant="outline" onClick={addLine}><Plus className="h-4 w-4" />Add expense line</Button></CardContent></Card><Card><CardContent className="p-4"><p className="text-xs text-muted-foreground">Claim total</p><p className="text-lg font-semibold">{money(total)}</p></CardContent></Card><Button className="fam-financial-save-actions" onClick={() => mutation.mutate()} disabled={mutation.isPending}>Save expense claim</Button></CompactFields>;
}

function ExpensesView() {
  const queryClient = useQueryClient();
  const query = useQuery({ queryKey: ["fam", "expenses"], queryFn: famApi.expenses });
  const rows = listItems(query.data);
  const post = useMutation({ mutationFn: (id: number | string) => famApi.postExpense(id), onSuccess: () => { toast({ title: "Expense posted" }); queryClient.invalidateQueries({ queryKey: ["fam"] }); } , onError: showMutationError });
  return <Card><CardHeader><CardTitle className="text-base">Expense claims</CardTitle></CardHeader><CardContent className="space-y-3"><Button asChild><Link to="/fam/expenses/new"><Plus className="h-4 w-4" />New expense</Link></Button><State label="expenses" isLoading={query.isLoading} isError={query.isError} /><DataTable rows={rows} columns={["claim_number", "employee_id", "claim_date", "total_amount", "status", "voucher_id"]} />{rows.slice(0, 3).map((item) => <Button key={String(item.id)} variant="outline" onClick={() => post.mutate(String(item.id))} disabled={String(item.status) !== "draft"}>Post {text(item.claim_number)}</Button>)}</CardContent></Card>;
}

function TDSHomeView() {
  const [draft, setDraft] = useState<FAMRecord>({ vendor_id: 2, section_id: 1, taxable_amount: 1000, deduction_date: "2026-06-06" });
  const calc = useMutation({ mutationFn: () => famApi.calculateTds(draft), onSuccess: (data) => toast({ title: `TDS ${money((data as FAMRecord).tds_amount)}` }) , onError: showMutationError });
  return <div className="grid gap-4 lg:grid-cols-[24rem_1fr]"><Card><CardHeader><CardTitle className="text-base">Calculate TDS</CardTitle></CardHeader><CardContent className="space-y-3">{["vendor_id", "section_id", "taxable_amount", "deduction_date"].map((field) => <Field key={field} label={field.replace(/_/g, " ")}>{["narration","notes","remarks"].includes(field) ? <RichTextField  value={String(draft[field] ?? "")} onChange={(event) => setDraft((current) => ({ ...current, [field]: numericFields.has(field) ? Number(event.target.value) : event.target.value }))} /> : <Input type={field.includes("date") ? "date" : "text"} value={String(draft[field] ?? "")} onChange={(event) => setDraft((current) => ({ ...current, [field]: numericFields.has(field) ? Number(event.target.value) : event.target.value }))} />}</Field>)}<Button className="w-full" onClick={() => calc.mutate()}>Calculate TDS</Button></CardContent></Card><Card><CardHeader><CardTitle className="text-base">TDS workbench</CardTitle></CardHeader><CardContent className="grid gap-2 sm:grid-cols-2">{[["Sections", "/fam/tds/sections"], ["Transactions", "/fam/tds/transactions"], ["Payable", "/fam/tds/payable"]].map(([label, href]) => <Button key={href} asChild variant="outline"><Link to={href}>{label}</Link></Button>)}<p className="text-xs text-muted-foreground sm:col-span-2">TDS return filing is not implemented or simulated in this phase.</p></CardContent></Card></div>;
}

function TDSSectionsView() {
  const queryClient = useQueryClient();
  const query = useQuery({ queryKey: ["fam", "tdsSections"], queryFn: famApi.tdsSections });
  const [draft, setDraft] = useState<FAMRecord>({ section_code: "194J", description: "Professional fees", default_rate: 10, threshold_amount: 30000, effective_from: "2026-04-01", active: true });
  const mutation = useMutation({ mutationFn: () => famApi.createTdsSection(draft), onSuccess: () => { toast({ title: "TDS section saved" }); queryClient.invalidateQueries({ queryKey: ["fam"] }); } , onError: showMutationError });
  return <div className="grid gap-4 lg:grid-cols-[24rem_1fr]"><SmartCreateSection title={<>Create TDS section</>} size="compact"><Card><CardHeader><CardTitle className="text-base">Create TDS section</CardTitle></CardHeader><CardContent className="space-y-3">{["section_code", "description", "default_rate", "threshold_amount", "effective_from"].map((field) => <Field key={field} label={field.replace(/_/g, " ")}>{["narration","notes","remarks"].includes(field) ? <RichTextField  value={String(draft[field] ?? "")} onChange={(event) => setDraft((current) => ({ ...current, [field]: numericFields.has(field) ? Number(event.target.value) : event.target.value }))} /> : <Input type={field.includes("date") ? "date" : "text"} value={String(draft[field] ?? "")} onChange={(event) => setDraft((current) => ({ ...current, [field]: numericFields.has(field) ? Number(event.target.value) : event.target.value }))} />}</Field>)}<Button className="w-full" onClick={() => mutation.mutate()}>Save section</Button></CardContent></Card></SmartCreateSection><Card><CardHeader><CardTitle className="text-base">Sections</CardTitle></CardHeader><CardContent><State label="TDS sections" isLoading={query.isLoading} isError={query.isError} /><DataTable rows={listItems(query.data)} columns={["section_code", "description", "default_rate", "threshold_amount", "effective_from", "active"]} /></CardContent></Card></div>;
}

function TDSTransactionsView() {
  const query = useQuery({ queryKey: ["fam", "tdsTransactions"], queryFn: famApi.tdsTransactions });
  return <Card><CardHeader><CardTitle className="text-base">TDS transaction register</CardTitle></CardHeader><CardContent><State label="TDS transactions" isLoading={query.isLoading} isError={query.isError} /><DataTable rows={listItems(query.data)} columns={["voucher_id", "vendor_id", "section_id", "taxable_amount", "tds_rate", "tds_amount", "deduction_date", "status"]} /></CardContent></Card>;
}

function TDSPayableView() {
  const query = useQuery({ queryKey: ["fam", "tdsPayable"], queryFn: famApi.tdsPayable });
  const data = (query.data || {}) as FAMRecord;
  return <div className="space-y-4"><div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between"><Card className="sm:min-w-72"><CardContent className="p-4"><p className="text-xs text-muted-foreground">TDS payable</p><p className="text-2xl font-semibold">{money(data.total_payable || data.totalPayable)}</p></CardContent></Card><ExportButton exportType="tds_summary" label="Export TDS summary CSV" /></div><Card><CardHeader><CardTitle className="text-base">Section-wise payable</CardTitle></CardHeader><CardContent><State label="TDS payable" isLoading={query.isLoading} isError={query.isError} /><DataTable rows={(data.items as FAMRecord[] | undefined) || []} columns={["section_id", "section_code", "vendor_id", "taxable_amount", "tds_amount", "status"]} /><p className="mt-3 text-xs text-muted-foreground">TDS filing/challan integration is not implemented in this phase; CSV summary export is available.</p></CardContent></Card></div>;
}

function PurchaseRegisterView() {
  const query = useQuery({ queryKey: ["fam", "purchaseRegister"], queryFn: famApi.purchaseRegister });
  const data = (query.data || {}) as FAMRecord;
  return <Card><CardHeader><CardTitle className="text-base">Purchase register</CardTitle></CardHeader><CardContent className="space-y-3"><State label="purchase register" isLoading={query.isLoading} isError={query.isError} /><div className="grid gap-3 md:grid-cols-4">{["subtotal", "gst_total", "tds_amount", "grand_total"].map((key) => <Card key={key}><CardContent className="p-3"><p className="text-xs text-muted-foreground">{key.replace(/_/g, " ")}</p><p className="font-semibold">{money((data.totals as FAMRecord | undefined)?.[key] || data[key])}</p></CardContent></Card>)}</div><DataTable rows={listItems(data)} columns={["bill_number", "vendor_id", "bill_date", "gstin", "place_of_supply", "subtotal", "gst_total", "tds_amount", "grand_total", "status"]} /></CardContent></Card>;
}

function ExpenseRegisterView() {
  const query = useQuery({ queryKey: ["fam", "expenseRegister"], queryFn: famApi.expenseRegister });
  const data = (query.data || {}) as FAMRecord;
  return <Card><CardHeader><CardTitle className="text-base">Expense register</CardTitle></CardHeader><CardContent className="space-y-3"><State label="expense register" isLoading={query.isLoading} isError={query.isError} /><Card><CardContent className="p-3"><p className="text-xs text-muted-foreground">Total expenses</p><p className="font-semibold">{money(data.total_amount || (data.totals as FAMRecord | undefined)?.total_amount)}</p></CardContent></Card><DataTable rows={listItems(data)} columns={["claim_number", "employee_id", "claim_date", "total_amount", "status", "voucher_id"]} /></CardContent></Card>;
}

function VendorPaymentsView() {
  const queryClient = useQueryClient();
  const dashboard = useQuery({ queryKey: ["fam", "payablesDashboard"], queryFn: famApi.payablesDashboard });
  const [draft, setDraft] = useState<FAMRecord>({ payment_date: "2026-06-06", bank_ledger_id: 3, items: [{ vendor_id: 2, purchase_bill_id: 1, bill_reference_id: 2, amount: 900 }] });
  const line = ((draft.items as FAMRecord[]) || [])[0] || {};
  const prepare = useMutation({ mutationFn: () => famApi.prepareVendorPayment(draft), onSuccess: () => toast({ title: "Payment run prepared" }) , onError: showMutationError });
  const post = useMutation({ mutationFn: () => famApi.postVendorPayment(draft), onSuccess: () => { toast({ title: "Vendor payment posted" }); queryClient.invalidateQueries({ queryKey: ["fam"] }); } , onError: showMutationError });
  return <div className="grid gap-4 lg:grid-cols-[24rem_1fr]"><Card><CardHeader><CardTitle className="text-base">Vendor payment run</CardTitle></CardHeader><CardContent className="space-y-3">{["payment_date", "bank_ledger_id"].map((field) => <Field key={field} label={field.replace(/_/g, " ")}>{["narration","notes","remarks"].includes(field) ? <RichTextField  value={String(draft[field] ?? "")} onChange={(event) => setDraft((current) => ({ ...current, [field]: numericFields.has(field) ? Number(event.target.value) : event.target.value }))} /> : <Input type={field.includes("date") ? "date" : "text"} value={String(draft[field] ?? "")} onChange={(event) => setDraft((current) => ({ ...current, [field]: numericFields.has(field) ? Number(event.target.value) : event.target.value }))} />}</Field>)}{["vendor_id", "purchase_bill_id", "bill_reference_id", "amount"].map((field) => <Field key={field} label={field.replace(/_/g, " ")}><Input value={String(line[field] ?? "")} onChange={(event) => setDraft((current) => ({ ...current, items: [{ ...line, [field]: numericFields.has(field) ? Number(event.target.value) : event.target.value }] }))} /></Field>)}<div className="flex gap-2"><Button variant="outline" onClick={() => prepare.mutate()}>Prepare</Button><Button onClick={() => post.mutate()}>Post payment</Button></div></CardContent></Card><Card><CardHeader><CardTitle className="text-base">Open payables</CardTitle></CardHeader><CardContent><State label="payables" isLoading={dashboard.isLoading} isError={dashboard.isError} /><DataTable rows={(dashboard.data as FAMRecord | undefined)?.items as FAMRecord[] || []} columns={["bill_number", "party_id", "due_date", "outstanding_amount", "status"]} /></CardContent></Card></div>;
}

function PayablesDashboardView() {
  const query = useQuery({ queryKey: ["fam", "payablesDashboard"], queryFn: famApi.payablesDashboard });
  const data = (query.data || {}) as FAMRecord;
  const buckets = (data.buckets || {}) as FAMRecord;
  return <div className="space-y-4"><div className="grid gap-3 md:grid-cols-4"><Card><CardContent className="p-4"><p className="text-xs text-muted-foreground">Total payable</p><p className="text-lg font-semibold">{money(data.totalOutstanding || data.total_payable)}</p></CardContent></Card><Card><CardContent className="p-4"><p className="text-xs text-muted-foreground">Draft bills</p><p className="text-lg font-semibold">{text(data.draftBills)}</p></CardContent></Card><Card><CardContent className="p-4"><p className="text-xs text-muted-foreground">Posted bills</p><p className="text-lg font-semibold">{text(data.postedBills)}</p></CardContent></Card><Card><CardContent className="p-4"><p className="text-xs text-muted-foreground">Paid bills</p><p className="text-lg font-semibold">{text(data.paidBills)}</p></CardContent></Card></div><div className="grid gap-3 md:grid-cols-6">{["Not due", "0-30", "31-60", "61-90", "91-180", ">180"].map((bucket) => <Card key={bucket}><CardContent className="p-3"><p className="text-xs text-muted-foreground">{bucket}</p><p className="font-semibold">{money(buckets[bucket])}</p></CardContent></Card>)}</div><Card><CardHeader><CardTitle className="text-base">Payable bills</CardTitle></CardHeader><CardContent><State label="payables dashboard" isLoading={query.isLoading} isError={query.isError} /><DataTable rows={(data.items as FAMRecord[] | undefined) || []} columns={["bill_number", "party_id", "due_date", "aging_bucket", "outstanding_amount", "status"]} /></CardContent></Card></div>;
}

function InventoryDashboardView() {
  const location = useLocation();
  const isSrmInventory = location.pathname.startsWith("/srm/inventory");
  const dashboard = useQuery({ queryKey: [isSrmInventory ? "srm" : "fam", "inventoryDashboard"], queryFn: () => isSrmInventory ? srmApi.inventoryItems() : famApi.inventoryDashboard() });
  const warehouses = useQuery({ queryKey: ["srm", "inventoryWarehouses", "dashboard"], queryFn: srmApi.inventoryWarehouses, enabled: isSrmInventory });
  const source = useQuery({ queryKey: ["fam", "inventorySourceAudit"], queryFn: famApi.inventorySourceAudit, enabled: !isSrmInventory });
  const data = (dashboard.data || {}) as FAMRecord;
  const [warehouseId, setWarehouseId] = useState("all");
  const products = isSrmInventory ? listItems(dashboard.data) : [];
  const warehouseRows = listItems(warehouses.data);
  const filteredProducts = useMemo(() => {
    if (warehouseId === "all") return products;
    return products.filter((item) => String(item.default_warehouse_id || item.warehouse_id || "") === warehouseId);
  }, [products, warehouseId]);
  const inventorySummary = useMemo(() => buildInventorySummary(filteredProducts), [filteredProducts]);
  const kpis: Array<[string, React.ReactNode]> = isSrmInventory
    ? [
        ["Items", text(filteredProducts.length)],
        ["Warehouses", text(warehouseRows.length)],
        ["Stock value", money(inventorySummary.inventoryValue)],
        ["Low stock", text(inventorySummary.lowStock)],
      ]
    : [["Items", text(data.items_count)], ["Warehouses", text(data.warehouses_count)], ["Stock value", money(data.total_stock_value)], ["Low stock", text(data.low_stock_count)]];
  const links: Array<[string, string]> = [["Accounting", "/srm/inventory/reconciliation"], ["Items", "/srm/inventory/items"], ["Warehouses", "/srm/inventory/warehouses"], ["Stock In", "/srm/inventory/stock-in"], ["Stock Out", "/srm/inventory/stock-out"], ["Transfers", "/srm/inventory/stock-transfers"], ["Adjustments", "/srm/inventory/stock-adjustments"], ["Summary", "/srm/inventory/stock-summary"], ["Valuation", "/srm/inventory/valuation"], ["AI", "/srm/inventory/ai"]];
  if (!isSrmInventory) {
    return <div className="space-y-4"><State label="inventory dashboard" isLoading={dashboard.isLoading} isError={dashboard.isError} /><div className="grid gap-3 md:grid-cols-4">{kpis.map(([label, value]) => <Card key={label}><SuiteMetric label={label} value={value} icon={label === "Cash and bank" ? Landmark : label === "Overdue AR" ? AlertTriangle : Receipt}/></Card>)}</div><Card><CardHeader><CardTitle className="text-base">Inventory workbench</CardTitle></CardHeader><CardContent className="grid gap-2 sm:grid-cols-3">{links.map(([label, href]) => <Button key={href} asChild variant="outline"><Link to={href}>{label}</Link></Button>)}</CardContent></Card><Card><CardHeader><CardTitle className="text-base">Source merge audit</CardTitle></CardHeader><CardContent><State label="source audit" isLoading={source.isLoading} isError={source.isError} /><DataTable rows={((source.data as FAMRecord | undefined)?.files as FAMRecord[] | undefined) || []} columns={["path", "exists"]} /></CardContent></Card></div>;
  }
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap justify-start gap-2 md:justify-end">
          <NativeSelect loading={warehouses.isFetching} error={warehouses.isError} aria-label="Warehouse filter" className="h-9 w-full rounded-md border bg-background px-3 text-sm sm:w-64" value={warehouseId} onChange={(event) => setWarehouseId(event.target.value)}>
            <option value="all">All warehouses</option>
            {warehouseRows.map((warehouse) => <option key={String(warehouse.id)} value={String(warehouse.id)}>{text(warehouse.warehouse_name || warehouse.name)}</option>)}
          </NativeSelect>
          <Button asChild variant="outline" size="sm" className="h-9"><Link to="/srm/inventory/items"><Plus className="h-4 w-4" />Add item</Link></Button>
          <Button asChild size="sm" className="h-9"><Link to="/srm/inventory/stock-transfers"><GitCompareArrows className="h-4 w-4" />Stock transfer</Link></Button>
      </div>
      <State label="inventory dashboard" isLoading={dashboard.isLoading || warehouses.isLoading} isError={dashboard.isError || warehouses.isError} />
      {!dashboard.isLoading && !dashboard.isError ? (
        <>
          <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
            <InventoryMetricCard icon={Box} label="Items & SKUs" value={filteredProducts.length ? text(filteredProducts.length) : "-"} detail={filteredProducts.length ? `${inventorySummary.skus} SKUs tracked` : "No data for current filters"} />
            <InventoryMetricCard icon={BoxesIcon} label="Stock on hand" value={filteredProducts.length ? text(inventorySummary.stockOnHand) : "-"} detail={filteredProducts.length ? "Current quantity" : "No data for current filters"} />
            <InventoryMetricCard icon={AlertTriangle} label="Low-stock items" value={filteredProducts.length ? text(inventorySummary.lowStock) : "-"} detail={filteredProducts.length ? `${inventorySummary.outOfStock} out of stock` : "No data for current filters"} tone="warning" />
            <InventoryMetricCard icon={BadgeIndianRupee} label="Inventory value" value={filteredProducts.length ? money(inventorySummary.inventoryValue) : "-"} detail={filteredProducts.length ? "Weighted from item costs" : "No data for current filters"} tone="success" />
          </div>
          <div className="grid gap-4 xl:grid-cols-12">
            <StockMovementCard />
            <InventoryHealthCard healthy={inventorySummary.healthy} lowStock={inventorySummary.lowStock} outOfStock={inventorySummary.outOfStock} hasData={filteredProducts.length > 0} />
          </div>
          <div className="grid gap-4 xl:grid-cols-12">
            <ItemsAttentionCard items={inventorySummary.attentionItems} />
            <WarehouseSummaryCard warehouses={warehouseRows} products={filteredProducts} />
            <QuickOperationsCard />
          </div>
        </>
      ) : null}
    </div>
  );
}

const BoxesIcon = Boxes;

function itemQuantity(item: FAMRecord) {
  return numberValue(item.current_quantity ?? item.available_quantity ?? item.quantity);
}

function itemReorderLevel(item: FAMRecord) {
  return numberValue(item.reorder_level ?? item.min_stock);
}

function itemValue(item: FAMRecord) {
  const explicit = item.stock_value;
  if (explicit !== null && explicit !== undefined && explicit !== "") return numberValue(explicit);
  return itemQuantity(item) * numberValue(item.average_cost ?? item.purchase_rate);
}

function inventoryStatus(item: FAMRecord) {
  const quantity = itemQuantity(item);
  const reorder = itemReorderLevel(item);
  if (quantity <= 0) return "Out of stock";
  if (reorder > 0 && quantity <= reorder) return "Low stock";
  return "Healthy";
}

function buildInventorySummary(products: FAMRecord[]) {
  const attentionItems = products.filter((item) => inventoryStatus(item) !== "Healthy");
  return {
    skus: new Set(products.map((item) => String(item.sku || item.id || "")).filter(Boolean)).size,
    stockOnHand: products.reduce((sum, item) => sum + itemQuantity(item), 0),
    inventoryValue: products.reduce((sum, item) => sum + itemValue(item), 0),
    lowStock: products.filter((item) => inventoryStatus(item) === "Low stock").length,
    outOfStock: products.filter((item) => inventoryStatus(item) === "Out of stock").length,
    healthy: products.filter((item) => inventoryStatus(item) === "Healthy").length,
    attentionItems,
  };
}

function InventoryMetricCard({ icon: Icon, label, value, detail, tone = "default" }: { icon: ElementType; label: string; value: React.ReactNode; detail: string; tone?: "default" | "success" | "warning" }) {
  const toneClass = tone === "success" ? "text-emerald-700 dark:text-emerald-300" : tone === "warning" ? "text-amber-700 dark:text-amber-300" : "text-primary";
  return (
    <Card className="rounded-xl shadow-sm">
      <CardContent className="flex items-center gap-4 p-4">
        <div className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-muted ${toneClass}`}><Icon className="h-6 w-6" /></div>
        <div className="min-w-0">
          <p className="text-sm font-semibold">{label}</p>
          <p className="mt-1 text-xl font-semibold">{value}</p>
          <p className="mt-1 text-xs text-muted-foreground">{detail}</p>
        </div>
      </CardContent>
    </Card>
  );
}

function StockMovementCard() {
  const emptyData = ["Received", "Issued", "Transfers", "Adjustments"].map((name) => ({ name, value: 0 }));
  return (
    <Card className="rounded-xl shadow-sm xl:col-span-7">
      <CardHeader className="pb-2">
        <CardTitle className="text-base">Stock movement</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="relative h-64">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={emptyData}>
              <XAxis dataKey="name" tickLine={false} axisLine={false} fontSize={12} />
              <YAxis tickLine={false} axisLine={false} fontSize={12} />
              <Tooltip />
              <Bar dataKey="value" fill="#2563eb" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
          <div className="absolute inset-0 flex flex-col items-center justify-center text-sm text-muted-foreground">
            <BarChart3 className="mb-2 h-8 w-8 opacity-50" />
            No movement data for current filters.
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function InventoryHealthCard({ healthy, lowStock, outOfStock, hasData }: { healthy: number; lowStock: number; outOfStock: number; hasData: boolean }) {
  const items = [
    { label: "Healthy", value: healthy, color: "#16a34a" },
    { label: "Low stock", value: lowStock, color: "#f59e0b" },
    { label: "Out of stock", value: outOfStock, color: "#ef4444" },
  ];
  const chartData = hasData ? items : [{ label: "No data", value: 1, color: "#e2e8f0" }];
  return (
    <Card className="rounded-xl shadow-sm xl:col-span-5">
      <CardHeader className="pb-2"><CardTitle className="text-base">Inventory health</CardTitle></CardHeader>
      <CardContent className="grid gap-4 sm:grid-cols-[12rem_1fr] sm:items-center">
        <div className="relative h-48">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie data={chartData} innerRadius={58} outerRadius={86} dataKey="value">
                {chartData.map((item) => <Cell key={item.label} fill={item.color} />)}
              </Pie>
              <Tooltip formatter={(value, name) => [hasData ? text(value) : "-", name]} />
            </PieChart>
          </ResponsiveContainer>
          <div className="pointer-events-none absolute inset-0 flex items-center justify-center"><Package className="h-7 w-7 text-muted-foreground" /></div>
        </div>
        <div className="space-y-3 text-sm">
          {items.map((item) => (
            <div key={item.label} className="flex items-center justify-between gap-3">
              <span className="flex items-center gap-2 text-muted-foreground"><span className="h-3 w-3 rounded-full" style={{ backgroundColor: item.color }} />{item.label}</span>
              <span className="font-semibold">{hasData ? item.value.toLocaleString("en-IN") : "-"}</span>
            </div>
          ))}
          {!hasData ? <p className="pt-2 text-muted-foreground">No data for current filters.</p> : null}
        </div>
      </CardContent>
    </Card>
  );
}

function ItemsAttentionCard({ items }: { items: FAMRecord[] }) {
  return (
    <Card className="rounded-xl shadow-sm xl:col-span-5">
      <CardHeader className="pb-2"><CardTitle className="text-base">Items requiring attention</CardTitle></CardHeader>
      <CardContent>
        {items.length ? (
          <div className="overflow-x-auto">
            <GridTable gridId="apps/fam/FAMWorkspacePage:table-4" className="w-full min-w-[620px] text-left text-sm">
              <thead className="text-xs text-muted-foreground"><tr>{["Item", "SKU", "Warehouse", "On hand", "Reorder level", "Status"].map((column) => <th key={column} className="px-3 py-2 font-medium">{column}</th>)}</tr></thead>
              <tbody>{items.slice(0, 8).map((item, index) => (
                <tr {...recordPreviewProps(item)} key={String(item.id || index)} className="border-t">
                  <td className="px-3 py-2"><Link to={`/srm/inventory/items/${item.id || ""}`} className="font-medium hover:text-primary">{text(item.item_name || item.name)}</Link></td>
                  <td className="px-3 py-2">{optionalText(item.sku)}</td>
                  <td className="px-3 py-2">{optionalText(item.warehouse_name || item.default_warehouse_id || item.warehouse_id)}</td>
                  <td className="px-3 py-2">{text(itemQuantity(item))}</td>
                  <td className="px-3 py-2">{text(itemReorderLevel(item))}</td>
                  <td className="px-3 py-2"><Badge variant={inventoryStatus(item) === "Out of stock" ? "destructive" : "secondary"}>{inventoryStatus(item)}</Badge></td>
                </tr>
              ))}</tbody>
            </GridTable>
          </div>
        ) : <InventoryEmptyState icon={Package} message="No items require attention." />}
      </CardContent>
    </Card>
  );
}

function WarehouseSummaryCard({ warehouses, products }: { warehouses: FAMRecord[]; products: FAMRecord[] }) {
  return (
    <Card className="rounded-xl shadow-sm xl:col-span-3">
      <CardHeader className="pb-2"><CardTitle className="text-base">Warehouse summary</CardTitle></CardHeader>
      <CardContent className="space-y-3">
        {warehouses.length ? warehouses.slice(0, 4).map((warehouse) => {
          const warehouseProducts = products.filter((item) => String(item.default_warehouse_id || item.warehouse_id || "") === String(warehouse.id || ""));
          return (
            <div key={String(warehouse.id)} className="rounded-lg border p-3">
              <p className="font-medium">{text(warehouse.warehouse_name || warehouse.name)}</p>
              <p className="text-xs text-muted-foreground">{text(warehouse.warehouse_code || warehouse.code || "Warehouse")}</p>
              <div className="mt-2 grid grid-cols-2 gap-2 text-xs">
                <span className="text-muted-foreground">Items</span><span className="text-right font-medium">{warehouseProducts.length.toLocaleString("en-IN")}</span>
                <span className="text-muted-foreground">Value</span><span className="text-right font-medium">{money(warehouseProducts.reduce((sum, item) => sum + itemValue(item), 0))}</span>
              </div>
            </div>
          );
        }) : <InventoryEmptyState icon={Warehouse} message="No data for current filters." />}
        <Button asChild variant="link" className="h-8 px-0"><Link to="/srm/inventory/warehouse-stock">View inventory<ArrowRight className="h-4 w-4" /></Link></Button>
      </CardContent>
    </Card>
  );
}

function QuickOperationsCard() {
  const operations = [
    { label: "Items & SKUs", description: "Maintain item masters, codes, units, and reorder controls.", to: "/srm/inventory/items", icon: Box },
    { label: "Stock summary", description: "Review warehouse stock, movement, and balances.", to: "/srm/inventory/stock-summary", icon: BoxesIcon },
    { label: "Reconciliation", description: "Compare physical stock with system balances.", to: "/srm/inventory/reconciliation", icon: GitCompareArrows },
    { label: "Purchases & receipts", description: "Manage purchase orders, receipts, and supplier returns.", to: "/srm/inventory/purchase-orders", icon: Receipt },
    { label: "Batch & serial tracking", description: "Track batches, expiry dates, and serial numbers.", to: "/srm/inventory/batches", icon: ShieldCheck },
  ];
  return (
    <Card className="rounded-xl shadow-sm xl:col-span-4">
      <CardHeader className="pb-2"><CardTitle className="text-base">Quick operations</CardTitle></CardHeader>
      <CardContent className="space-y-2">
        {operations.map((operation) => {
          const Icon = operation.icon;
          return (
            <Link key={operation.to} to={operation.to} className="flex items-center justify-between gap-3 rounded-lg border p-3 transition hover:border-primary/60 hover:bg-muted/40">
              <span className="flex min-w-0 items-center gap-3">
                <Icon className="h-4 w-4 shrink-0" />
                <span className="min-w-0">
                  <span className="block truncate text-sm font-semibold">{operation.label}</span>
                  <div className="block truncate text-xs text-muted-foreground"><RichTextContent legacyFormat="plain" value={operation.description}/></div>
                </span>
              </span>
              <ArrowRight className="h-4 w-4 shrink-0 text-muted-foreground" />
            </Link>
          );
        })}
      </CardContent>
    </Card>
  );
}

function InventoryEmptyState({ icon: Icon, message }: { icon: ElementType; message: string }) {
  return (
    <div className="flex min-h-36 flex-col items-center justify-center rounded-lg border border-dashed bg-muted/20 p-6 text-center text-sm text-muted-foreground">
      <Icon className="mb-2 h-7 w-7 opacity-60" />
      {message}
    </div>
  );
}

function InventoryAccountingView() {
  const query = useQuery({ queryKey: ["fam", "inventoryAccounting"], queryFn: famApi.inventoryAccounting });
  const data = (query.data || {}) as FAMRecord;
  const gl = (data.gl_reconciliation || {}) as FAMRecord;
  const grni = (data.grni_reconciliation || {}) as FAMRecord;
  const cogs = (data.cogs_reconciliation || {}) as FAMRecord;
  const gst = (data.gst_reconciliation || {}) as FAMRecord;
  return <div className="space-y-4"><State label="inventory accounting" isLoading={query.isLoading} isError={query.isError} /><MetricGrid items={[["Status", text(data.status)], ["Unmapped items", text(data.unmapped_items)], ["GL difference", money(gl.difference)], ["GRNI outstanding", money(grni.grni_outstanding)], ["COGS difference", money(cogs.difference)], ["GST exceptions", text(gst.exceptions)]]} /><Card><CardHeader><CardTitle className="text-base">Accounting controls</CardTitle></CardHeader><CardContent className="grid gap-2 sm:grid-cols-3">{[["Ledger Mapping", "/fam/inventory/items"], ["GL Reconciliation", "/srm/inventory/reconciliation/gl"], ["GRNI", "/srm/inventory/reconciliation/grni"], ["COGS", "/srm/inventory/reconciliation/cogs"], ["GST", "/srm/inventory/reconciliation/gst"], ["HSN Summary", "/srm/inventory/reports/hsn-summary"]].map(([label, href]) => <Button key={href} asChild variant="outline"><Link to={href}>{label}</Link></Button>)}</CardContent></Card></div>;
}

function InventoryItemsView() {
  const scope = useRecordScope();
  const location = useLocation();
  const isSrmInventory = location.pathname.startsWith("/srm/inventory");
  const api = isSrmInventory ? srmApi : famApi;
  const query = useQuery({ queryKey: [isSrmInventory ? "srm" : "fam", "inventoryItems", scope], queryFn: () => api.inventoryItems(), refetchInterval: isSrmInventory ? 3000 : false, refetchIntervalInBackground: isSrmInventory, refetchOnWindowFocus: true });
  return <div className="grid gap-4 lg:grid-cols-[24rem_1fr]"><InventoryItemCreateForm source={isSrmInventory ? "srm" : "fam"} /><Card><CardHeader><CardTitle className="text-base">{isSrmInventory ? "SRM products" : "Stock items"}</CardTitle></CardHeader><CardContent><State label={isSrmInventory ? "SRM products" : "stock items"} isLoading={query.isLoading} isError={query.isError} /><DataTable rows={listItems(query.data)} columns={["sku", "item_name", "category_name", "hsn_code", "current_quantity", "sales_rate", "reorder_level", "active"]} />{listItems(query.data).slice(0, 4).map((item) => <Button key={String(item.id)} asChild variant="link" className="px-0"><Link to={`/${isSrmInventory ? "srm" : "fam"}/inventory/items/${item.id}`}>Open {text(item.item_name)}</Link></Button>)}</CardContent></Card></div>;
}

function InventoryLedgerMappingView() {
  return <InventoryLedgerMappingPage/>;
}

function InventoryItemDetailView({ ledger = false }: { ledger?: boolean }) {
  const { id } = useParams();
  const location = useLocation(), scope=useRecordScope();
  const isSrmInventory = location.pathname.startsWith("/srm/inventory");
  const query = useQuery({ queryKey: [isSrmInventory ? "srm" : "fam", ledger ? "inventoryItemLedger" : "inventoryItem", id], queryFn: () => isSrmInventory && !ledger ? srmApi.inventoryItem(id || "0") : ledger ? famApi.inventoryItemLedger(id || "0") : famApi.inventoryItem(id || "0"), refetchInterval: isSrmInventory ? 3000 : false, refetchIntervalInBackground: isSrmInventory, refetchOnWindowFocus: true });
  const data = (query.data || {}) as FAMRecord;
  const rows = ledger ? listItems(query.data) : ((data.ledger as FAMRecord[] | undefined) || []);
  const stats: Array<[string, React.ReactNode]> = [["SKU", text(data.sku)], ["Quantity", text(data.current_quantity)], ["Average cost", text(data.average_cost)], ["Stock value", money(data.stock_value)]];
  return <Card><CardHeader><CardTitle className="text-base">{ledger ? "Item ledger" : text(data.item_name || "Item detail")}</CardTitle></CardHeader><CardContent className="space-y-3"><State label="item detail" isLoading={query.isLoading} isError={query.isError} />{!ledger ? <div className="grid gap-3 md:grid-cols-4">{stats.map(([label, value]) => <Card key={label}><CardContent className="p-3"><p className="text-xs text-muted-foreground">{label}</p><p className="font-semibold">{value}</p></CardContent></Card>)}</div> : null}{!ledger&&id&&<Button asChild variant="outline"><Link to={`/${isSrmInventory?"srm":"fam"}/inventory/items/${id}/ledger-mapping`}>Map item accounts</Link></Button>}<>{isSrmInventory&&!ledger&&query.isSuccess&&id&&<StockAlertSettings key={`${scope}:${id}`} id={id} reorder={Number(data.reorder_level||0)} minimum={Number(data.min_stock||0)}/>}<DataTable rows={rows} columns={["movement_id", "warehouse_id", "quantity_in", "quantity_out", "rate", "value", "balance_quantity"]} /></></CardContent></Card>;
}

function InventoryMasterView({ kind }: { kind: "groups" | "units" | "warehouses" }) {
  const scope=useRecordScope(),location=useLocation();
  return <InventoryMasterForm key={`${scope}:${kind}:${location.pathname}`} kind={kind} scope={scope}/>;
}

function InventoryMasterForm({kind,scope}:{kind:"groups"|"units"|"warehouses";scope:string}) {
  const location=useLocation();
  const isSrmWarehouse=kind === "warehouses" && location.pathname.startsWith("/srm/inventory");
  const queryClient = useQueryClient();
  const permissions=isSrmWarehouse?["srm_admin","srm_manage"]:["fam_admin","fam_inventory_manage"];
  const canCreate=useFinanceWrite(permissions,"create"),canEdit=useFinanceWrite(permissions,"edit"),canDelete=useFinanceWrite(permissions,"delete");
  const config = {
    groups: { queryKey: "inventoryGroups", query: famApi.inventoryStockGroups, create: famApi.createInventoryStockGroup, initial: { group_code: "", group_name: "", parent_group_id: null }, fields: ["group_code", "group_name", "parent_group_id"], columns: ["group_code", "group_name", "parent_group_id", "active"] },
    units: { queryKey: "inventoryUnits", query: famApi.inventoryUnits, create: famApi.createInventoryUnit, initial: { unit_code: "", unit_name: "", symbol: "", decimal_allowed: true }, fields: ["unit_code", "unit_name", "symbol"], columns: ["unit_code", "unit_name", "symbol", "decimal_allowed", "active"] },
    warehouses: { queryKey: "inventoryWarehouses", query: isSrmWarehouse ? srmApi.inventoryWarehouses : famApi.inventoryWarehouses, create: isSrmWarehouse ? srmApi.createInventoryWarehouse : famApi.createInventoryWarehouse, initial: { warehouse_code: "", warehouse_name: "" }, fields: ["warehouse_code", "warehouse_name", isSrmWarehouse ? "branch" : "branch_id", "address"], columns: ["warehouse_code", "warehouse_name", "branch_id", "active"] },
  }[kind];
  const query = useQuery({ queryKey: [isSrmWarehouse ? "srm" : "fam", config.queryKey,scope], queryFn: config.query, retry:false });
  const branches=useQuery({queryKey:["fam","inventory-master-branches",scope],queryFn:famApi.branches,enabled:kind==="warehouses"&&!isSrmWarehouse,retry:false,staleTime:30000});
  const [formError,setFormError]=useState("");
  const [draft, setDraft] = useState<FAMRecord>(config.initial);
  const [editing,setEditing]=useState<FAMRecord|null>(null),[deleting,setDeleting]=useState<FAMRecord|null>(null);
  const endpoint=isSrmWarehouse?"/srm/inventory/warehouses":`/fam/inventory/${kind==="groups"?"stock-groups":kind}`;
  const mutation = useMutation({ mutationFn: () => editing ? api.put(`${endpoint}/${editing.id}`,draft) : config.create(draft), onSuccess: () => { toast({ title: "Inventory master saved" }); setEditing(null);setDraft(config.initial);setFormError(""); queryClient.invalidateQueries({ queryKey: [isSrmWarehouse ? "srm" : "fam"] }); } , onError: error=>{setFormError(apiErrorMessage(error,"Inventory master could not be saved"));showMutationError(error);} });
  const removeMutation=useMutation({mutationFn:()=>api.delete(`${endpoint}/${deleting?.id}`),onSuccess:()=>{setDeleting(null);queryClient.invalidateQueries({queryKey:[isSrmWarehouse?"srm":"fam"]});},onError:showMutationError});
  const excluded=new Set<string>(editing?[String(editing.id)]:[]);
  if(kind==="groups")for(let changed=true;changed;){changed=false;for(const row of listItems(query.data))if(excluded.has(String(row.parent_group_id))&&!excluded.has(String(row.id))){excluded.add(String(row.id));changed=true;}}
  const groupChoices=listItems(query.data).filter(row=>row.active!==false&&!excluded.has(String(row.id)));
  const branchChoices=listItems(branches.data).filter(row=>row.active!==false);
  const editor = <Card><CardHeader><CardTitle className="text-base">{editing?"Edit":"Create"}</CardTitle></CardHeader><CardContent><CompactForm compactTabs={false} className="space-y-3" onSubmit={event=>{event.preventDefault();setFormError("");if(!(editing?canEdit:canCreate)||mutation.isPending)return;
    if(kind==="groups"&&draft.parent_group_id&&(query.isError||!groupChoices.some(row=>String(row.id)===String(draft.parent_group_id)))){setFormError("Choose an available parent group outside this group's descendants.");return;}
    if(kind==="warehouses"&&!isSrmWarehouse&&draft.branch_id&&(branches.isError||!branchChoices.some(row=>String(row.id)===String(draft.branch_id)))){setFormError("Choose an available branch.");return;}
    mutation.mutate();}}><fieldset disabled={!(editing?canEdit:canCreate)||mutation.isPending} className="space-y-3">{config.fields.map((field) => <Field key={field} label={field==="parent_group_id"?"Parent group":field==="branch_id"?"Branch":field.replace(/_/g," ")}>{["parent_group_id","branch_id"].includes(field)?<NativeSelect searchable disabled={field==="branch_id"&&!!editing} aria-label={field==="parent_group_id"?"Parent group":"Branch"} value={String(draft[field]??"")} onChange={event=>setDraft(current=>({...current,[field]:event.target.value?Number(event.target.value):null}))}><option value="">Not assigned</option>{(field==="parent_group_id"?groupChoices:branchChoices).map(row=><option key={String(row.id)} value={String(row.id)}>{String(field==="parent_group_id"?row.group_name:row.branch_name)}</option>)}{draft[field]&&!(field==="parent_group_id"?groupChoices:branchChoices).some(row=>String(row.id)===String(draft[field]))?<option value={String(draft[field])}>Unavailable selection</option>:null}</NativeSelect>:<Input required={/_code$|_name$/.test(field)} maxLength={field==="unit_code"?40:field==="unit_name"?120:/_code$/.test(field)?80:180} value={String(draft[field]??"")} onChange={event=>setDraft(current=>({...current,[field]:event.target.value}))}/>}</Field>)}
    {kind==="groups"&&query.isError&&<p role="alert">Parent groups could not load. <Button type="button" onClick={()=>void query.refetch()}>Retry parent groups</Button></p>}{kind==="warehouses"&&!isSrmWarehouse&&branches.isError&&<p role="alert">Branches could not load. <Button type="button" onClick={()=>void branches.refetch()}>Retry branches</Button></p>}
    {editing&&kind==="warehouses"&&!isSrmWarehouse&&<p className="text-sm text-muted-foreground">Use branch transfer to move this warehouse to another branch.</p>}{formError&&<p role="alert">{formError}</p>}<Button data-save-action className="w-full inventory-master-submit" type="submit">{editing?"Save changes":"Save"}</Button>{editing&&<Button className="inventory-master-cancel" type="button" variant="outline" onClick={()=>{setEditing(null);setDraft(config.initial);setFormError("");}}>Cancel editing</Button>}</fieldset></CompactForm></CardContent></Card>;
  return <><div className="grid gap-4 lg:grid-cols-[24rem_1fr]">{!editing && <SmartCreateSection title={`Create ${kind === "groups" ? "stock group" : kind === "units" ? "unit" : "warehouse"}`}>{editor}</SmartCreateSection>}<Card><CardHeader><CardTitle className="text-base">Records</CardTitle></CardHeader><CardContent><State label="inventory masters" isLoading={query.isLoading} isError={query.isError} /><DataTable rows={listItems(query.data).map(row=>({...row,parent_group_name:row.parent_group_id?String(listItems(query.data).find(group=>group.id===row.parent_group_id)?.group_name||"Unavailable group"):"Not assigned",branch_name:isSrmWarehouse?row.branch:row.branch_id?String(branchChoices.find(branch=>branch.id===row.branch_id)?.branch_name||"Unavailable branch"):"Not assigned"}))} columns={config.columns.map(column=>column==="parent_group_id"?"parent_group_name":column==="branch_id"?"branch_name":column)} renderActions={row=><div className="flex gap-2"><Button variant="outline" disabled={!canEdit} aria-label={`Edit ${row.group_name||row.unit_name||row.warehouse_name}`} onClick={()=>{setFormError("");setEditing(row);setDraft({...row});}}>Edit</Button><Button variant="outline" disabled={!canDelete} aria-label={`Delete ${row.group_name||row.unit_name||row.warehouse_name}`} onClick={()=>setDeleting(row)}>Delete</Button></div>}/></CardContent></Card></div>{editing && <SmartCreateModal definition={{entity:"inventoryMaster",title:`Edit ${kind === "groups" ? "stock group" : kind === "units" ? "unit" : "warehouse"}`,presentation:"page",size:"compact",mode:"edit"}} busy={mutation.isPending} onClose={()=>{setEditing(null);setDraft(config.initial);}}>{editor}</SmartCreateModal>}<Dialog open={!!deleting} onOpenChange={v=>{if(!v&&!removeMutation.isPending)setDeleting(null);}}><DialogContent><DialogTitle>Delete inventory master?</DialogTitle><p>This retires the selected record from active use and retains its stock history.</p><Button disabled={removeMutation.isPending||!canDelete} onClick={()=>removeMutation.mutate()}>Confirm delete master</Button><Button variant="outline" onClick={()=>setDeleting(null)}>Keep record</Button></DialogContent></Dialog></>;
}

function InventoryMovementView({ mode }: { mode: "in" | "out" | "purchase" | "delivery" }) {
  return <InventoryMovementForm kind={mode}/>;
}

function InventoryOpeningStockView() {
  return <div className="grid gap-4 lg:grid-cols-[24rem_1fr]"><SmartCreateSection title="Create opening stock" size="compact"><InventoryMovementForm kind="opening"/></SmartCreateSection><InventorySummaryView kind="summary"/></div>;
}

function InventorySourceBridgeView({ kind }: { kind: FAMViewKind }) {
  const keywords: Partial<Record<FAMViewKind, string[]>> = {
    inventoryBatches: ["batch", "serial", "expiry"],
    inventoryPriceLists: ["price list"],
    inventoryPurchaseOrders: ["purchase order", "grn"],
    inventoryManufacturing: ["manufacturing", "bom", "repacking", "composite"],
  };
  const terms = keywords[kind] || [];
  const matches = inventorySourceFeatures.filter((feature) => {
    const haystack = `${feature.label} ${feature.route} ${feature.appPath} ${feature.group}`.toLowerCase();
    return terms.some((term) => haystack.includes(term));
  });
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base">Mapped operational entry points</CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {matches.length ? matches.map((feature) => (
          <div key={`${feature.group}-${feature.appPath}`} className="flex flex-col gap-2 rounded-lg border p-3 md:flex-row md:items-center md:justify-between">
            <div>
              <p className="font-medium">{feature.label}</p>
              <p className="text-xs text-muted-foreground">{feature.group} / owner: {feature.owner} / source: {feature.route}</p>
            </div>
            <Button asChild variant="outline" size="sm"><Link to={feature.appPath || "/srm/inventory/source"}>Open</Link></Button>
          </div>
        )) : (
          <div className="rounded-lg border border-dashed p-6 text-sm text-muted-foreground">No mapped source entries found for this inventory area.</div>
        )}
      </CardContent>
    </Card>
  );
}

function InventoryBatchesView() {
  const location=useLocation();
  return location.pathname.startsWith('/srm/inventory') ? <PharmaInventory fallback={<NativeInventoryBatchesView/>} renderTable={rows=><DataTable gridId="business-packs/pharma:batches" preview={false} rows={rows} columns={["batch_number","item_name","warehouse_name","expiry_date","quantity","available_quantity","status","fefo_eligible"]}/>}/> : <NativeInventoryBatchesView/>;
}

function NativeInventoryBatchesView() {
  const scope = useRecordScope();
  const location = useLocation();
  const isSrmInventory = location.pathname.startsWith("/srm/inventory");
  const batches = useQuery({ queryKey: ["srm", "inventoryBatches", scope], queryFn: srmApi.inventoryBatches, enabled: isSrmInventory });
  const serials = useQuery({ queryKey: ["srm", "serialNumbers", scope], queryFn: srmApi.serialNumbers, enabled: isSrmInventory });
  if (!isSrmInventory) return <InventorySourceBridgeView kind="inventoryBatches" />;
  return (
    <div className="space-y-4">
      <InventoryTrackingForms />
      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader><CardTitle className="text-base">Batches</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            <State label="batches" isLoading={batches.isLoading} isError={batches.isError} />
            <DataTable rows={listItems(batches.data)} columns={["batch_number", "product_id", "warehouse_id", "manufacture_date", "expiry_date", "quantity", "available_quantity", "status", "serial_count"]} />
          </CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle className="text-base">Serial numbers</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            <State label="serial numbers" isLoading={serials.isLoading} isError={serials.isError} />
            <DataTable rows={listItems(serials.data)} columns={["serial_number", "product_id", "batch_id", "warehouse_id", "status", "received_date", "reference_number"]} />
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function InventoryPriceListsView() {
  const scope = useRecordScope();
  const location = useLocation();
  const isSrmInventory = location.pathname.startsWith("/srm/inventory");
  const priceLists = useQuery({ queryKey: ["srm", "priceLists", scope], queryFn: srmApi.priceLists, enabled: isSrmInventory });
  if (!isSrmInventory) return <InventorySourceBridgeView kind="inventoryPriceLists" />;
  return (
    <div className="space-y-4">
      <InventoryPriceListForm />
      <Card>
        <CardHeader><CardTitle className="text-base">Price lists</CardTitle></CardHeader>
        <CardContent className="space-y-3">
          <State label="price lists" isLoading={priceLists.isLoading} isError={priceLists.isError} />
          <DataTable rows={listItems(priceLists.data)} columns={["price_list_code", "price_list_name", "channel", "customer_type", "currency", "priority", "active"]} />
        </CardContent>
      </Card>
    </div>
  );
}

function InventoryManufacturingView() {
  const location = useLocation();
  const isSrmInventory = location.pathname.startsWith("/srm/inventory");
  const scope = useRecordScope();
  const boms = useQuery({ queryKey: ["srm", "boms", scope], queryFn: srmApi.boms, enabled: isSrmInventory });
  const orders = useQuery({ queryKey: ["srm", "productionOrders", scope], queryFn: srmApi.productionOrders, enabled: isSrmInventory });
  if (!isSrmInventory) return <InventorySourceBridgeView kind="inventoryManufacturing" />;
  return (
    <div className="space-y-4">
      <div className="grid gap-4 lg:grid-cols-3">
        <InventoryBomForm />
        <InventoryProductionOrderForm />
        <InventoryProductionPostingForm />
      </div>
      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader><CardTitle className="text-base">BOMs</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            <State label="BOMs" isLoading={boms.isLoading} isError={boms.isError} />
            <DataTable rows={listItems(boms.data)} columns={["bom_number", "bom_name", "finished_product_id", "output_quantity", "status"]} />
          </CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle className="text-base">Production orders</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            <State label="production orders" isLoading={orders.isLoading} isError={orders.isError} />
            <DataTable rows={listItems(orders.data)} columns={["production_number", "bom_id", "finished_product_id", "planned_quantity", "completed_quantity", "status", "total_component_cost"]} />
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function InventoryPurchaseOrdersView() {
  const scope = useRecordScope();
  const location = useLocation();
  const isSrmInventory = location.pathname.startsWith("/srm/inventory");
  const purchaseOrders = useQuery({ queryKey: ["srm", "purchaseOrders", scope], queryFn: srmApi.purchaseOrders, enabled: isSrmInventory });
  const goodsReceipts = useQuery({ queryKey: ["srm", "goodsReceipts", scope], queryFn: srmApi.goodsReceipts, enabled: isSrmInventory });
  if (!isSrmInventory) return <InventorySourceBridgeView kind="inventoryPurchaseOrders" />;
  return (
    <div className="space-y-4">
      <InventoryProcurementForms />
      <div className="grid gap-4 lg:grid-cols-2">
        <Card><CardHeader><CardTitle className="text-base">Purchase orders</CardTitle></CardHeader><CardContent><State label="purchase orders" isLoading={purchaseOrders.isLoading} isError={purchaseOrders.isError} /><DataTable rows={listItems(purchaseOrders.data)} columns={["po_number", "vendor_name", "status", "order_date", "subtotal", "tax_amount", "total_amount"]} /></CardContent></Card>
        <Card><CardHeader><CardTitle className="text-base">Goods receipts</CardTitle></CardHeader><CardContent><State label="goods receipts" isLoading={goodsReceipts.isLoading} isError={goodsReceipts.isError} /><DataTable rows={listItems(goodsReceipts.data)} columns={["grn_number", "vendor_name", "status", "receipt_date", "reference_number", "total_amount"]} /></CardContent></Card>
      </div>
    </div>
  );
}

function InventoryTransferView() {
  return <InventoryMovementForm kind="transfer" />;
}

function InventoryAdjustmentView() {
  return <InventoryMovementForm kind="adjustment" />;
}

type InventoryReportKind = "summary" | "valuation" | "reorder" | "reports" | "warehouse" | "aging" | "dead" | "fastSlow" | "grossMargin" | "cogs" | "hsnSummary" | "audit" | "crmLink" | "srmLink";

function InventorySummaryView({ kind }: { kind: InventoryReportKind }) {
  const location = useLocation(), scope = useRecordScope();
  const isSrmInventory = location.pathname.startsWith("/srm/inventory");
  const financialReport = ["grossMargin", "cogs", "hsnSummary"].includes(kind);
  const activityReport = ["aging", "dead", "fastSlow"].includes(kind);
  const salesActivity = isSrmInventory && activityReport;
  const stockReport = kind === "summary" || kind === "reorder";
  const salesStock = isSrmInventory && stockReport;
  const salesValuation = isSrmInventory && kind === "valuation";
  const salesWarehouse = isSrmInventory && kind === "warehouse";
  const salesCatalog = isSrmInventory && !financialReport && !salesWarehouse && !salesActivity && !salesValuation && !salesStock;
  const query = useQuery({
    queryKey: [isSrmInventory && !financialReport ? "srm" : "fam", `inventory-${kind}`, scope],
    queryFn: () => {
      if (salesActivity && kind === "aging") return srmApi.inventoryStockAging();
      if (salesActivity && kind === "dead") return srmApi.inventoryDeadStock();
      if (salesActivity && kind === "fastSlow") return srmApi.inventoryFastSlowMoving();
      if (salesStock && kind === "summary") return srmApi.inventoryStockSummary();
      if (salesStock && kind === "reorder") return srmApi.inventoryReorderAlerts();
      if (salesValuation) return srmApi.inventoryValuation();
      if (salesWarehouse) return srmApi.inventoryWarehouseStock();
      if (salesCatalog) return srmApi.inventoryItems();
      if (kind === "valuation") return famApi.inventoryValuation();
      if (kind === "reorder") return famApi.inventoryReorderAlerts();
      if (kind === "reports") return famApi.inventoryReports();
      if (kind === "warehouse") return famApi.inventoryWarehouseStock();
      if (kind === "aging") return famApi.inventoryStockAging();
      if (kind === "dead") return famApi.inventoryDeadStock();
      if (kind === "fastSlow") return famApi.inventoryFastSlowMoving();
      if (kind === "grossMargin") return famApi.inventoryGrossMargin();
      if (kind === "cogs") return famApi.inventoryCogsReport();
      if (kind === "hsnSummary") return famApi.inventoryHsnSummary();
      if (kind === "audit") return famApi.inventoryAudit();
      if (kind === "crmLink") return famApi.inventoryCrmLink();
      if (kind === "srmLink") return famApi.inventorySrmLink();
      return famApi.inventoryStockSummary();
    },
    retry: false,
    refetchInterval: salesStock ? 60000 : false,
  });
  const data = (query.isError ? {} : query.data || {}) as FAMRecord;
  const sourceRows = listItems(query.isError ? undefined : query.data);
  const rows = kind === "reports" && !salesCatalog ? ((data.summary as FAMRecord | undefined)?.items as FAMRecord[] | undefined) || [] : sourceRows;
  const valuationTotals: FAMRecord[] = !query.isSuccess || kind !== "valuation" ? [] : salesValuation
    ? (Array.isArray(data.totals_by_currency) ? data.totals_by_currency as FAMRecord[] : [])
    : data.currency && data.total_inventory_value != null ? [{currency:data.currency,total_inventory_value:data.total_inventory_value}] : [];
  const columns = kind === "summary" ? (salesStock
    ? ["sku", "item_name", "current_quantity", "stock_value", "currency", "is_low_stock"]
    : ["sku", "item_name", "current_quantity", "reserved_quantity", "available_quantity", "stock_value", "currency", "is_low_stock"])
    : kind === "reorder" ? ["sku", "item_name", "current_quantity", "reorder_level", "min_stock", "is_low_stock"]
    : kind === "valuation" ? ["sku", "item_name", "current_quantity", "stock_value", "currency"] : kind === "aging" || kind === "dead"
    ? ["sku", "item_name", "last_movement_date", "age_days"]
    : kind === "fastSlow"
      ? ["sku", "item_name", "quantity_out", "movement_class"]
    : kind === "audit"
    ? ["action", "record_type", "record_id", "performed_at"]
    : kind === "warehouse"
      ? ["warehouse_name", "sku", "item_name", "quantity", "stock_value", "currency"]
      : kind === "grossMargin"
        ? ["sku", "item_name", "revenue_status", "revenue", "cogs", "gross_margin", "gross_margin_percent"]
        : kind === "cogs"
          ? ["movement_number", "movement_date", "movement_type", "cogs_value", "voucher_posted", "status"]
          : kind === "hsnSummary"
            ? ["hsn_code", "items", "quantity", "stock_value"]
        : kind === "srmLink"
          ? ["reservation_number", "source_record_type", "source_record_id", "status"]
          : ["sku", "item_name", "current_quantity", "available_quantity", "average_cost", "stock_value", "is_low_stock"];
  const reportRows = activityReport ? rows.map(row => ({...row,
    last_movement_date: row.last_movement_date ?? "No recorded movement",
    age_days: row.age_days ?? "Not available",
    movement_class: ({fast:"Fast moving",slow:"Slow moving",non_moving:"No issues recorded"} as Record<string,string>)[String(row.movement_class)] || "Not available",
  })) : kind === "grossMargin" ? rows.map(row => ({...row, gross_margin: row.gross_margin == null ? "Not available" : row.gross_margin, gross_margin_percent: row.gross_margin_percent == null ? "Not available" : row.gross_margin_percent})) : (kind === "warehouse" || kind === "valuation" || kind === "summary") ? rows.map(row=>({...row,currency:row.currency || data.currency || "Not available"})) : rows;
  return <Card><CardHeader><CardTitle className="text-base">{kind === "summary" ? "Stock summary" : kind === "reorder" ? "Reorder alerts" : kind === "aging" ? "Stock movement age" : kind === "dead" ? "Stock without recent activity" : kind === "fastSlow" ? "Fast and slow moving stock" : kind === "warehouse" ? "Warehouse stock" : kind === "valuation" ? "Stock valuation" : kind === "grossMargin" ? "Inventory gross margin" : kind === "cogs" ? "Cost of goods issued" : kind === "hsnSummary" ? "HSN stock summary" : "Inventory records"}</CardTitle></CardHeader><CardContent className="space-y-3"><State label="inventory report" isLoading={query.isLoading} isError={query.isError} />{stockReport && <div className="space-y-2"><p className="text-sm">{salesStock ? "On-hand quantities total the warehouse balances you can access." : "Shows on-hand stock, with reserved and available quantities in the stock summary."} Reorder alerts compare on-hand quantity with a positive reorder level, or minimum stock when no reorder level is set. An item without either threshold has no reorder alert.</p>{query.isError && <p role="alert">{apiErrorMessage(query.error,"Stock report unavailable")}</p>}<Button type="button" variant="outline" disabled={query.isFetching} onClick={()=>void query.refetch()}>Retry inventory report</Button></div>}{kind === "valuation" && <div className="space-y-2"><p className="text-sm">{salesValuation ? "Each item sums its warehouse balance values in its recorded currency. Currency totals are separate; no currency conversion is applied." : "Finance stock quantities valued at each stock item's current average cost in the company base currency."}</p>{query.isError && <p role="alert">{apiErrorMessage(query.error,"Stock valuation unavailable")}</p>}{query.isSuccess && valuationTotals.length > 0 && <div aria-label="Valuation totals" className="flex flex-wrap gap-4">{valuationTotals.map(total=><p key={String(total.currency)} className="font-medium">{String(total.currency)} {Number(total.total_inventory_value).toLocaleString("en-US",{minimumFractionDigits:2,maximumFractionDigits:2})}</p>)}</div>}{query.isSuccess && Number(data.unpriced_currency_items || 0) > 0 && <p role="alert">Some items have no valid currency. They are excluded from currency totals.</p>}{query.isSuccess && !salesValuation && !data.currency && <p role="alert">Report currency unavailable. A monetary total cannot be displayed.</p>}<Button type="button" variant="outline" disabled={query.isFetching} onClick={()=>void query.refetch()}>Retry inventory report</Button></div>}{activityReport && <div className="space-y-2"><p className="text-sm">{kind === "fastSlow" ? `Classification uses all recorded ${salesActivity ? "Sales" : "posted Finance"} delivery and stock issue quantities, excluding transfers and adjustments. Fast moving means at least ${Number(data.fast_threshold ?? 10)} units; slow moving means more than zero below that threshold.` : `Age means days since the last ${salesActivity ? "recorded Sales" : "posted Finance"} stock movement. Items without movement history have no known age.${kind === "dead" ? ` This list includes items with no history or at least ${Number(data.threshold_days ?? 90)} days without movement.` : ""}`}</p>{query.isError && <p role="alert">{apiErrorMessage(query.error,"Stock activity report unavailable")}</p>}<Button type="button" variant="outline" disabled={query.isFetching} onClick={()=>void query.refetch()}>Retry inventory report</Button></div>}{kind === "warehouse" && <div className="space-y-2"><p className="text-sm">{salesWarehouse ? "Sales warehouse balances valued at each warehouse's average cost. Currency is shown for each item." : "Finance posted stock quantities valued at each stock item's current average cost."}</p>{query.isError && <p role="alert">{apiErrorMessage(query.error,"Warehouse stock report unavailable")}</p>}<Button type="button" variant="outline" disabled={query.isFetching} onClick={()=>void query.refetch()}>Retry inventory report</Button></div>}{financialReport && kind !== "grossMargin" && <div className="space-y-2">{isSrmInventory && <p className="text-sm">This report uses Finance stock records and requires the corresponding Finance reporting access.</p>}{query.isError && <p role="alert">{apiErrorMessage(query.error,"Inventory report unavailable")}</p>}{query.isSuccess && <p className="text-sm">{data.currency?`Report currency: ${String(data.currency)}`:"Report currency unavailable"}</p>}<Button type="button" variant="outline" disabled={query.isFetching} onClick={()=>void query.refetch()}>Retry inventory report</Button></div>}{kind === "grossMargin" && <div className="space-y-2">{isSrmInventory && <p className="text-sm">This financial report uses Finance stock records and requires Finance inventory reporting access.</p>}{query.isError && <p role="alert">{apiErrorMessage(query.error, "Inventory report unavailable")}</p>}{!!(data.attribution as FAMRecord | undefined)?.currency && <p className="text-sm">Report currency: {String((data.attribution as FAMRecord).currency)}</p>}<Button type="button" variant="outline" disabled={query.isFetching} onClick={()=>void query.refetch()}>{query.isFetching ? "Refreshing inventory report..." : "Retry inventory report"}</Button><p className="text-sm text-muted-foreground">Revenue includes only issued invoice lines attributed through explicit Sales product links, excluding tax. COGS uses historical posted delivery and issue values.</p>{rows.some(row => row.revenue_complete === false) && <p role="alert" className="text-sm">Some rows have incomplete revenue attribution. Revenue shows the attributed amount only; gross margin is unavailable until missing or ambiguous links and unsupported invoice sources or currencies are resolved.</p>}</div>}<>{salesStock && query.isSuccess && <LowStockPanel items={rows.map(row=>({id:Number(row.id),name:String(row.item_name),sku:String(row.sku),quantity:Number(row.current_quantity),threshold:Number(row.reorder_threshold ?? (Number(row.reorder_level)>0?row.reorder_level:row.min_stock) ?? 0)}))} updatedAt={query.dataUpdatedAt} loading={query.isFetching} onRefresh={()=>void query.refetch()}/>}<DataTable rows={reportRows} columns={columns} /></></CardContent></Card>;
}

function InventorySalesIntegrationView() {
  const location = useLocation(), scope = useRecordScope();
  const fromSales = location.pathname.startsWith("/srm/inventory");
  const query = useQuery({queryKey:["fam","inventory-sales-integration",scope],queryFn:famApi.inventorySrmLink,retry:false});
  const data = (query.isSuccess ? query.data || {} : {}) as FAMRecord;
  const valid = query.isSuccess && Array.isArray(data.reservations) && Array.isArray(data.movements);
  const reservations = valid ? data.reservations as FAMRecord[] : [];
  const movements = valid ? data.movements as FAMRecord[] : [];
  return <Card><CardHeader><CardTitle className="text-base">Sales inventory integration</CardTitle></CardHeader><CardContent className="space-y-4">
    <p className="text-sm">Recorded Finance stock reservations and movements with Sales as their source.</p>
    {fromSales && <p className="text-sm">These Finance records require Finance inventory viewing access.</p>}
    <State label="Sales inventory integration" isLoading={query.isLoading} isError={query.isError}/>
    {query.isError && <p role="alert">{apiErrorMessage(query.error,"Inventory integration unavailable")}</p>}
    {query.isSuccess && !valid && <p role="alert">Incomplete integration response. Please retry.</p>}
    <Button type="button" variant="outline" disabled={query.isFetching} onClick={()=>void query.refetch()}>Retry inventory report</Button>
    {valid && <>
      <section aria-label="Sales stock reservations" className="space-y-2"><h3 className="font-medium">Stock reservations</h3><DataTable rows={reservations} columns={["reservation_number","quantity","status","source_record_type","source_record_id"]}/></section>
      <section aria-label="Sales stock movements" className="space-y-2"><h3 className="font-medium">Stock movements</h3><DataTable rows={movements} columns={["movement_number","movement_date","movement_type","status","source_record_type","source_record_id"]}/></section>
    </>}
  </CardContent></Card>;
}

function InventoryReconciliationView() {
  const location = useLocation(), scope = useRecordScope();
  const isSrmInventory = location.pathname.startsWith("/srm/inventory");
  const gl = useQuery({queryKey:["fam","inventory-gl-reconciliation",scope],queryFn:famApi.inventoryGlReconciliation,retry:false});
  const sales = useQuery({queryKey:["fam","inventory-srm-reconciliation",scope],queryFn:famApi.inventorySrmReconciliation,retry:false});
  const glData = (gl.isSuccess ? gl.data || {} : {}) as FAMRecord;
  const salesData = (sales.isSuccess ? sales.data || {} : {}) as FAMRecord;
  const amount = (value:unknown) => value == null || value === "" || !Number.isFinite(Number(value)) ? "Not available" : !glData.currency ? "Currency unavailable" : `${String(glData.currency)} ${Number(value).toLocaleString("en-IN",{minimumFractionDigits:2,maximumFractionDigits:2})}`;
  return <div className="grid gap-4 lg:grid-cols-2">
    {isSrmInventory&&<p className="text-sm lg:col-span-2">These reconciliation reports use Finance records and require Finance reconciliation access.</p>}
    <Card><CardHeader><CardTitle className="text-base">Inventory to GL</CardTitle></CardHeader><CardContent className="space-y-3">
      <State label="GL reconciliation" isLoading={gl.isPending} isError={gl.isError}/>
      {gl.isError&&<p role="alert">{apiErrorMessage(gl.error,"GL reconciliation unavailable")}</p>}
      <Button type="button" variant="outline" disabled={gl.isFetching} onClick={()=>void gl.refetch()}>Retry GL reconciliation</Button>
      {gl.isSuccess&&<MetricGrid items={[["Stock valuation",amount(glData.stock_valuation)],["Ledger balance",amount(glData.ledger_balance)],["Difference",amount(glData.difference)],["Status",text(glData.status)]]}/>}
    </CardContent></Card>
    <Card><CardHeader><CardTitle className="text-base">Inventory to Sales</CardTitle></CardHeader><CardContent className="space-y-3">
      <State label="Sales reconciliation" isLoading={sales.isPending} isError={sales.isError}/>
      {sales.isError&&<p role="alert">{apiErrorMessage(sales.error,"Sales reconciliation unavailable")}</p>}
      <Button type="button" variant="outline" disabled={sales.isFetching} onClick={()=>void sales.refetch()}>Retry Sales reconciliation</Button>
      {sales.isSuccess&&<><MetricGrid items={[["Sales orders",text(salesData.srm_sales_orders)],["Invoices",text(salesData.srm_invoices)],["Reservations",text(salesData.inventory_reservations)],["Posted movements",text(salesData.posted_inventory_movements)]]}/><p className="text-sm text-muted-foreground">{text(salesData.duplicate_deduction_guard)}</p></>}
    </CardContent></Card>
  </div>;
}

function InventoryReconciliationDetailView({ kind }: { kind: "gl" | "grni" | "cogs" | "gst" }) {
  const scope=useRecordScope(),location=useLocation();
  const query = useQuery({queryKey:["fam","inventory-reconciliation",kind,scope],retry:false,queryFn:()=>{
    if(kind==="grni")return famApi.inventoryGrniReconciliation();
    if(kind==="cogs")return famApi.inventoryCogsReconciliation();
    if(kind==="gst")return famApi.inventoryGstReconciliation();
    return famApi.inventoryGlReconciliation();
  }});
  const data=(query.isSuccess?query.data||{}:{}) as FAMRecord;
  const rows=listItems(query.isSuccess?query.data:undefined);
  const amount=(value:unknown)=>value==null||value===""||!Number.isFinite(Number(value))?"Not available":!data.currency?"Currency unavailable":`${String(data.currency)} ${Number(value).toLocaleString("en-IN",{minimumFractionDigits:2,maximumFractionDigits:2})}`;
  const metrics:Array<[string,React.ReactNode]>=kind==="gst"?[["Stock items",text(data.total)],["Missing mappings",text(data.exceptions)]]:kind==="grni"?[["Status",text(data.status)],["Goods received, not invoiced",amount(data.grni_outstanding)],["Unbilled receipts",text(data.total)]]:kind==="cogs"?[["Status",text(data.status)],["Stock issue value",amount(data.stock_issue_value)],["Cost posted",amount(data.cogs_posted)],["Difference",amount(data.difference)]]:[["Status",text(data.status)],["Stock valuation",amount(data.stock_valuation)],["Ledger balance",amount(data.ledger_balance)],["Difference",amount(data.difference)]];
  const columns=kind==="gst"?["sku","hsn_code","gst_rate_id","gst_rate_configured","gst_register_lines","status"]:kind==="cogs"?["movement_number","stock_issue_value","cogs_posted","difference","status"]:kind==="grni"?["movement_number","reference_number","grni_value","purchase_bill_status","status"]:["inventory_ledger_id","stock_valuation","ledger_balance","difference","status"];
  const tableRows=kind==="gl"?(data.inventory_ledger_id==null?[]:[{...data,id:data.inventory_ledger_id}]):rows;
  return <Card><CardHeader><CardTitle className="text-base">Inventory {kind.toUpperCase()} reconciliation</CardTitle></CardHeader><CardContent className="space-y-3">
    {location.pathname.startsWith("/srm/")&&<p className="text-sm">This report uses Finance records and requires the corresponding Finance reporting access.</p>}
    <State label={`${kind} reconciliation`} isLoading={query.isPending} isError={query.isError}/>
    {query.isError&&<p role="alert">{apiErrorMessage(query.error,"Reconciliation unavailable")}</p>}
    <Button type="button" variant="outline" disabled={query.isFetching} onClick={()=>void query.refetch()}>Retry {kind.toUpperCase()} reconciliation</Button>
    {query.isSuccess&&<>{kind!=="gst"&&<p className="text-sm">{data.currency?`Report currency: ${String(data.currency)}`:"Report currency unavailable"}</p>}<MetricGrid items={metrics}/><DataTable rows={tableRows} columns={columns}/></>}
  </CardContent></Card>;
}

function MetricGrid({ items }: { items: Array<[string, React.ReactNode]> }) {
  return <div className="grid gap-3 sm:grid-cols-2">{items.map(([label, value]) => <Card key={label}><SuiteMetric label={label} value={value} icon={BarChart3}/></Card>)}</div>;
}

function InventoryAIView() {
  const [prompt, setPrompt] = useState("Show reorder and dead stock risks.");
  const mutation = useMutation({ mutationFn: () => famApi.inventoryAI({ prompt }) , onError: showMutationError });
  const data = (mutation.data || {}) as FAMRecord;
  const response = (data.response || data.response_json || {}) as FAMRecord;
  return <div className="grid gap-4 lg:grid-cols-[28rem_1fr]"><Card><CardHeader><CardTitle className="text-base">Audited AI request</CardTitle></CardHeader><CardContent className="space-y-3"><Field label="Prompt"><textarea className="min-h-28 w-full rounded-md border bg-background px-3 py-2 text-sm" value={prompt} onChange={(event) => setPrompt(event.target.value)} /></Field><Button onClick={() => mutation.mutate()}>Run inventory AI</Button></CardContent></Card><Card><CardHeader><CardTitle className="text-base">Result</CardTitle></CardHeader><CardContent className="space-y-2 text-sm"><State label="inventory AI" isLoading={mutation.isPending} isError={mutation.isError} /><div><RichTextContent legacyFormat="plain" value={text(response.message || "No request submitted.")}/></div><Badge variant="outline">{text(data.status)}</Badge><p className="text-xs text-muted-foreground">Requests are logged in fam_inventory_ai_logs. Unsupported providers remain labelled as not configured.</p></CardContent></Card></div>;
}

function parseJson(value: unknown) {
  if (!value) return undefined;
  try {
    return typeof value === "string" ? JSON.parse(value) : value;
  } catch {
    return { raw: String(value) };
  }
}

const numericFields = new Set(["financial_year_id", "ledger_id", "ledger_group_id", "voucher_type_id", "debit_amount", "credit_amount", "opening_balance_dr", "opening_balance_cr", "opening_balance", "sequence_order", "numbering_sequence", "cost_center_id", "party_id", "payment_terms_days", "credit_limit", "original_amount", "outstanding_amount", "from_bill_reference_id", "to_bill_reference_id", "allocated_amount", "invoice_id", "receipt_id", "allocation_id", "source_record_id", "roundoff_ledger_id", "bank_account_id", "default_ledger_id", "statement_line_id", "voucher_id", "ledger_entry_id", "matched_amount", "expense_ledger_id", "from_ledger_id", "to_ledger_id", "amount", "cgst_rate", "sgst_rate", "igst_rate", "cess_rate", "default_gst_rate_id", "period_month", "period_year", "threshold_amount", "taxable_value", "vendor_id", "quantity", "quantity_in", "quantity_out", "available_quantity", "rate", "unit_cost", "gst_rate_id", "gst_amount", "tds_section_id", "tds_amount", "line_total", "subtotal", "discount_total", "gst_total", "grand_total", "employee_id", "total_amount", "default_rate", "section_id", "taxable_amount", "tds_rate", "bank_ledger_id", "purchase_bill_id", "bill_reference_id", "stock_group_id", "unit_id", "default_warehouse_id", "inventory_ledger_id", "purchase_ledger_id", "sales_ledger_id", "cogs_ledger_id", "adjustment_gain_ledger_id", "adjustment_loss_ledger_id", "grni_ledger_id", "warehouse_id", "from_warehouse_id", "to_warehouse_id", "stock_item_id", "product_id", "batch_id", "bom_id", "order_id", "finished_product_id", "component_product_id", "output_quantity", "planned_quantity", "completed_quantity", "purchase_rate", "sales_rate", "price", "discount_percent", "discount_amount", "min_quantity", "priority", "reorder_level", "min_stock", "max_stock", "parent_group_id", "branch_id", "adjustment_ledger_id"]);

function getListConfig(kind: FAMViewKind) {
  if (kind === "financialYears") return { label: "financial year", query: famApi.financialYears, create: famApi.createFinancialYear, initial: { ...defaultFiscalYear("fam"), status: "open", is_current: false }, fields: ["name", "start_date", "end_date"], columns: ["name", "start_date", "end_date", "status", "is_current"] };
  if (kind === "ledgerGroups") return { label: "ledger group", query: famApi.ledgerGroups, create: famApi.createLedgerGroup, initial: { group_name: "", group_code: "", nature: "asset", sequence_order: 100 }, fields: ["group_name", "group_code", "nature", "sequence_order"], columns: ["group_code", "group_name", "nature", "system_group", "active"] };
  if (kind === "ledgers") return { label: "ledger", query: famApi.ledgers, create: famApi.createLedger, initial: { ledger_code: "", ledger_name: "", ledger_group_id: "", nature: "", ledger_type: "general" }, fields: ["ledger_code", "ledger_name", "ledger_group_id", "nature", "ledger_type"], columns: ["ledger_code", "ledger_name", "nature", "ledger_type", "current_balance_dr", "current_balance_cr", "active"] };
  if (kind === "voucherTypes") return { label: "voucher type", query: famApi.voucherTypes, create: famApi.createVoucherType, initial: { voucher_type_code: "", voucher_type_name: "", category: "journal", numbering_prefix: "JV", numbering_sequence: 1, auto_numbering: true }, fields: ["voucher_type_code", "voucher_type_name", "category", "numbering_prefix", "numbering_sequence"], columns: ["voucher_type_code", "voucher_type_name", "category", "numbering_prefix", "numbering_sequence", "active"] };
  if (kind === "costCenters") return { label: "cost center", query: famApi.costCenters, create: famApi.createCostCenter, initial: { code: "", name: "" }, fields: ["code", "name"], columns: ["code", "name", "parent_id", "active"] };
  return { label: "branch", query: famApi.branches, create: famApi.createBranch, initial: { branch_code: "", branch_name: "", gstin: "", state_code: "" }, fields: ["branch_code", "branch_name", "gstin", "state_code"], columns: ["branch_code", "branch_name", "gstin", "state_code", "active"] };
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  const id = `fam-${label.toLowerCase().replace(/[^a-z0-9]+/g, "-")}`;
  const control = isValidElement(children)
    ? cloneElement(children as React.ReactElement<{ id?: string; "aria-label"?: string }>, { id, "aria-label": label })
    : children;
  return <div className="space-y-2"><Label htmlFor={id} className="capitalize">{label}</Label>{control}</div>;
}

function AuditRow({ item }: { item: FAMRecord }) {
  return <div className="flex items-center justify-between rounded-md border p-3 text-sm"><span>{text(item.action)} {text(item.record_type)} #{text(item.record_id)}</span><span className="text-xs text-muted-foreground">{text(item.performed_at)}</span></div>;
}

export default function FAMWorkspacePage({ kind }: { kind: FAMViewKind }) {
  let meta = viewMeta[kind];
  const queryClient = useQueryClient();
  const location = useLocation();
  const isSrmInventoryContext = location.pathname.startsWith("/srm/inventory");
  if (isSrmInventoryContext && (kind === "inventory" || kind === "inventoryDashboard")) {
    meta = {
      title: "Inventory Management",
      description: "Stock health, movement, warehouses and replenishment",
      icon: Package,
    };
  }
  useSrmRealtimeInvalidation(queryClient, isSrmInventoryContext);
  let content: React.ReactNode = null;
  if (kind === "dashboard") content = <DashboardView />;
  else if (kind === "settings") content = <SettingsView />;
  else if (kind === "chartOfAccounts") content = <ChartView />;
  else if (kind === "openingBalances") content = <OpeningBalancesView />;
  else if (kind === "voucherNew") content = <VoucherEntryView mode="new" />;
  else if (kind === "journal") content = <VoucherEntryView mode="journal" />;
  else if (kind === "voucherDetail") content = <VoucherEntryView mode="detail" />;
  else if (kind === "vouchers") content = <VouchersView />;
  else if (kind === "dayBook") content = <DayBookView />;
  else if (kind === "ledgerEntries") content = <LedgerEntriesView />;
  else if (kind === "ledgerDetailEntries") content = <LedgerEntriesView detail />;
  else if (kind === "parties") content = <PartiesView />;
  else if (kind === "customers") content = <PartiesView partyType="customer" />;
  else if (kind === "vendors") content = <PartiesView partyType="vendor" />;
  else if (kind === "partyDetail") content = <PartyDetailView />;
  else if (kind === "ar") content = <OutstandingView kind="ar" />;
  else if (kind === "arAging") content = <AgingView kind="ar" />;
  else if (kind === "arOutstanding") content = <OutstandingView kind="ar" />;
  else if (kind === "ap") content = <OutstandingView kind="ap" />;
  else if (kind === "apAging") content = <AgingView kind="ap" />;
  else if (kind === "apOutstanding") content = <OutstandingView kind="ap" />;
  else if (kind === "billReferences") content = <BillReferencesView />;
  else if (kind === "billAllocations") content = <BillAllocationsView />;
  else if (kind === "srmIntegration") content = <SRMIntegrationView />;
  else if (kind === "postingJobs") content = <PostingJobsView />;
  else if (kind === "postingJobDetail") content = <PostingJobDetailView />;
  else if (kind === "postingRules") content = <PostingRulesView />;
  else if (kind === "banking") content = <BankingView />;
  else if (kind === "bankAccounts") content = <BankAccountsView />;
  else if (kind === "paymentModes") content = <PaymentModesView />;
  else if (kind === "bankStatements") content = <BankStatementsView />;
  else if (kind === "bankStatementDetail") content = <BankStatementDetailView />;
  else if (kind === "bankReconciliation") content = <BankReconciliationView />;
  else if (kind === "bankBook") content = <BookView kind="bank" />;
  else if (kind === "cashBook") content = <BookView kind="cash" />;
  else if (kind === "contra") content = <ContraView />;
  else if (kind === "bankCharges") content = <BankChargesView />;
  else if (kind === "gst") content = <GSTHomeView />;
  else if (kind === "gstSettings") content = <GSTSettingsView />;
  else if (kind === "gstRegistrations") content = <GSTMasterView kind="registrations" />;
  else if (kind === "gstRates") content = <GSTMasterView kind="rates" />;
  else if (kind === "gstHsnSac") content = <GSTMasterView kind="hsn" />;
  else if (kind === "gstSalesRegister") content = <GSTRegisterView kind="sales" />;
  else if (kind === "gstPurchaseRegister") content = <GSTRegisterView kind="purchase" />;
  else if (kind === "gstr1") content = <GSTReturnView kind="gstr1" />;
  else if (kind === "gstr3b") content = <GSTReturnView kind="gstr3b" />;
  else if (kind === "gstReconciliation") content = <GSTReconciliationView />;
  else if (kind === "einvoice") content = <ProviderSettingsView kind="einvoice" />;
  else if (kind === "ewaybill") content = <ProviderSettingsView kind="ewaybill" />;
  else if (kind === "purchases") content = <PurchasesHomeView />;
  else if (kind === "purchaseBills") content = <PurchaseBillsView />;
  else if (kind === "purchaseBillNew") content = <PurchaseBillFormView />;
  else if (kind === "purchaseBillDetail") content = <PurchaseBillFormView detail />;
  else if (kind === "expenses") content = <ExpensesView />;
  else if (kind === "expenseNew") content = <ExpenseFormView />;
  else if (kind === "tds") content = <TDSHomeView />;
  else if (kind === "tdsSections") content = <TDSSectionsView />;
  else if (kind === "tdsTransactions") content = <TDSTransactionsView />;
  else if (kind === "tdsPayable") content = <TDSPayableView />;
  else if (kind === "purchaseRegister") content = <PurchaseRegisterView />;
  else if (kind === "expenseRegister") content = <ExpenseRegisterView />;
  else if (kind === "vendorPayments") content = <VendorPaymentsView />;
  else if (kind === "payablesDashboard") content = <PayablesDashboardView />;
  else if (kind === "inventory" || kind === "inventoryDashboard") content = <InventoryDashboardView />;
  else if (kind === "inventoryAccounting") content = <InventoryAccountingView />;
  else if (kind === "inventoryItems" || kind === "inventoryProducts") content = <InventoryItemsView />;
  else if (kind === "inventoryItemDetail") content = <InventoryItemDetailView />;
  else if (kind === "inventoryLedgerMapping") content = <InventoryLedgerMappingView />;
  else if (kind === "inventoryCategories" || kind === "inventoryStockGroups") content = <InventoryMasterView kind="groups" />;
  else if (kind === "inventoryUnits") content = <InventoryMasterView kind="units" />;
  else if (kind === "inventoryWarehouses") content = <InventoryMasterView kind="warehouses" />;
  else if (kind === "inventoryStockIn") content = <InventoryMovementView mode="in" />;
  else if (kind === "inventoryStockOut") content = <InventoryMovementView mode="out" />;
  else if (kind === "inventoryPurchaseReceipts") content = <InventoryMovementView mode="purchase" />;
  else if (kind === "inventoryDeliveryNotes") content = <InventoryMovementView mode="delivery" />;
  else if (kind === "inventoryStockTransfers") content = <InventoryTransferView />;
  else if (kind === "inventoryStockAdjustments") content = <InventoryAdjustmentView />;
  else if (kind === "inventoryOpeningStock") content = <InventoryOpeningStockView />;
  else if (kind === "inventoryStockSummary") content = <InventorySummaryView kind="summary" />;
  else if (kind === "inventoryItemLedger") content = <InventoryItemDetailView ledger />;
  else if (kind === "inventoryWarehouseStock") content = <InventorySummaryView kind="warehouse" />;
  else if (kind === "inventoryStockAging") content = <InventorySummaryView kind="aging" />;
  else if (kind === "inventoryReorderReport") content = <InventorySummaryView kind="reorder" />;
  else if (kind === "inventoryDeadStock") content = <InventorySummaryView kind="dead" />;
  else if (kind === "inventoryFastSlowMoving") content = <InventorySummaryView kind="fastSlow" />;
  else if (kind === "inventoryValuation") content = <InventorySummaryView kind="valuation" />;
  else if (kind === "inventoryGrossMargin") content = <InventorySummaryView kind="grossMargin" />;
  else if (kind === "inventoryCogs") content = <InventorySummaryView kind="cogs" />;
  else if (kind === "inventoryGrni") content = <InventoryReconciliationDetailView kind="grni" />;
  else if (kind === "inventoryHsnSummary") content = <InventorySummaryView kind="hsnSummary" />;
  else if (kind === "inventoryReconciliation") content = <InventoryReconciliationView />;
  else if (kind === "inventoryReconciliationGl") content = <InventoryReconciliationDetailView kind="gl" />;
  else if (kind === "inventoryReconciliationGrni") content = <InventoryReconciliationDetailView kind="grni" />;
  else if (kind === "inventoryReconciliationCogs") content = <InventoryReconciliationDetailView kind="cogs" />;
  else if (kind === "inventoryReconciliationGst") content = <InventoryReconciliationDetailView kind="gst" />;
  else if (kind === "inventoryAudit") content = <InventorySummaryView kind="audit" />;
  else if (kind === "inventoryCrmLink") content = <InventorySummaryView kind="crmLink" />;
  else if (kind === "inventorySrmLink") content = <InventorySalesIntegrationView />;
  else if (kind === "inventoryReorderAlerts") content = <InventorySummaryView kind="reorder" />;
  else if (kind === "inventoryReports" || kind === "inventoryCompleteReports") content = <InventorySummaryView kind="reports" />;
  else if (kind === "inventoryPurchaseOrders") content = <InventoryPurchaseOrdersView />;
  else if (kind === "inventoryPriceLists") content = <InventoryPriceListsView />;
  else if (kind === "inventoryBatches") content = <InventoryBatchesView />;
  else if (kind === "inventoryManufacturing") content = <InventoryManufacturingView />;
  else if (kind === "inventoryAI") content = <InventoryAIView />;
  else if (kind === "audit") content = <AuditView />;
  else content = <ListCreateView kind={kind} />;

  const retailModes = {inventoryStockIn:"receipt",inventoryPurchaseReceipts:"receipt",inventoryPurchaseOrders:"receipt",inventoryStockSummary:"stock",inventoryReorderAlerts:"alerts",inventoryReorderReport:"alerts",inventoryWarehouseStock:"warehouse",inventoryReports:"daily",inventoryCompleteReports:"daily"} as const;
  const retailMode = kind === "inventoryPurchaseOrders" && location.pathname !== "/srm/inventory/grn" ? undefined : retailModes[kind as keyof typeof retailModes];
  if (isSrmInventoryContext && retailMode) content = <RetailWorkspace mode={retailMode} receiptTitle={kind === "inventoryStockIn" ? "Stock in" : "Purchase receipt"} fallback={content} renderTable={(rows,columns)=><DataTable gridId={`business-packs/retail:${kind}:${columns.join("-")}`} preview={false} rows={rows} columns={columns}/>}/>;

  return (
    <section className={`space-y-5${["voucherNew","journal","voucherDetail"].includes(kind)?" fam-mobile-voucher-page":["purchaseBillNew","purchaseBillDetail","expenseNew"].includes(kind)?" fam-mobile-purchase-page":""}`}>
      <PageHeader meta={meta} onRefresh={() => { void queryClient.invalidateQueries({ queryKey: ["fam"] }); if (isSrmInventoryContext && retailMode) void queryClient.invalidateQueries({ queryKey: ["srm", "retail"] }); }} />
      {content}
    </section>
  );
}

function showMutationError(error: unknown) {
  const detail=(error as {response?:{data?:{detail?:unknown}}})?.response?.data?.detail;
  const message=typeof detail === "string" ? detail : Array.isArray(detail) ? detail.map(item => typeof item === "object" && item && "msg" in item ? String(item.msg) : String(item)).join("; ") : error instanceof Error ? error.message : "Could not save. Your details are kept for retry.";
  toast({title:"Action failed",description:message,variant:"destructive"});
}

function financialToday() { return new Date().toLocaleDateString("en-CA", {timeZone:defaultText("timezone", "fam")}); }
