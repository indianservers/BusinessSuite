import EmployeeCategories from "@/shared/EmployeeCategories";
import GroupedRecords from "@/shared/data-grid/GroupedRecords";
import { openPerson } from "@/apps/project-management/components/people/peopleTypes";
import { NativeSelect } from "@/components/ui/native-select";
import CompactForm from "@/components/forms/CompactForm";
import ProfileListCard, { ProfileAction } from "./ProfileListCard";
import PersonRecordPreview from "./PersonRecordPreview";
import { useRefreshableEffect } from "@/lib/page-refresh";
import { useEffect, useMemo, useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { api } from "@/services/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useAuthStore } from "@/store/authStore";
import { canAccessRoute } from "@/lib/roles";
import { canExplorePeopleDirectory } from "@/lib/people-directory-access";
import { useMobileContext } from "@/components/mobile/useMobileContext";
import { syncScope } from "@/shared/record-sync/store";

type Person = { work_categories?: string[]; id: number; email: string; name: string; role: string; is_active: boolean; workspace_ids: number[]; profile_photo_url?: string | null };
type Group = { id: number; name: string };
type Team = Group & { workspace_id: number; member_ids: number[] };
type Directory = { items: Person[]; total: number; workspaces: Group[]; teams: Team[] };
export default function PeopleDirectoryPage() {
  const user = useAuthStore(s => s.user);
  const location = useLocation();
  const scope = useMobileContext(true);
  if (scope !== syncScope()) return <p role="status">Updating directory context…</p>;
  if (!user || !canExplorePeopleDirectory(user.primary_role === undefined ? user.role : user.primary_role, user.is_superuser) || !canAccessRoute(location.pathname, user.role, user.is_superuser)) {
    return <main className="mx-auto w-full max-w-7xl space-y-3 p-4 md:p-8"><h1 className="text-2xl font-semibold">People directory unavailable</h1><p>Organization directory access requires an administrator, HR, manager or executive role.</p></main>;
  }
  return <PeopleDirectoryContent key={scope} />;
}

function PeopleDirectoryContent() {
  const userId = useAuthStore(s => s.user?.id);
  const viewKey = `people-directory-views:${userId}`;
  type SavedView = { name: string; query: string; workspace: string; team: string; role: string; categories?: string[] };
  const [savedViews, setSavedViews] = useState<SavedView[]>(() => { try { const value = JSON.parse(localStorage.getItem(viewKey) || "[]"); return Array.isArray(value) ? value.filter(v => typeof v.name === "string") : []; } catch { return []; } });
  const [viewName, setViewName] = useState("");
  const [viewMessage, setViewMessage] = useState("");
  const [data, setData] = useState<Directory>();
  const [error, setError] = useState("");
  const [query, setQuery] = useState("");
  const [workspace, setWorkspace] = useState("");
  const [team, setTeam] = useState("");
  const [role, setRole] = useState("");
  const [categories,setCategories] = useState<string[]>([]);
  const [attempt, setAttempt] = useState(0);
  const [selectedPerson, setSelectedPerson] = useState<Person | null>(null);
  useRefreshableEffect(() => {
    let cancelled = false;
    setError("");
    async function load() {
      const first = (await api.get<Directory>("/users/directory", { params: { page: 1, page_size: 200 } })).data;
      const items = [...first.items];
      for (let page = 2; items.length < first.total; page++) {
        if (cancelled) return;
        const next = (await api.get<Directory>("/users/directory", { params: { page, page_size: 200 } })).data;
        if (!next.items.length) break;
        items.push(...next.items);
      }
      if (!cancelled) setData({ ...first, items });
    }
    void load().catch(e => { if (!cancelled) setError(e.response?.data?.detail || "Unable to load people. Please retry."); });
    return () => { cancelled = true; };
  }, [attempt]);
  useEffect(() => { const refresh = () => setAttempt(a => a + 1); window.addEventListener("pms:people-changed", refresh); return () => window.removeEventListener("pms:people-changed", refresh); }, []);
  const teams = data?.teams.filter(t => !workspace || t.workspace_id === Number(workspace)) || [];
  const people = useMemo(() => data?.items.filter(p =>
    (!query || `${p.name} ${p.email}`.toLowerCase().includes(query.toLowerCase())) &&
    (!workspace || p.workspace_ids.includes(Number(workspace))) &&
    (!team || data.teams.find(t => t.id === Number(team))?.member_ids.includes(p.id)) &&
    (!role || p.role === role) && (!categories.length || p.work_categories?.some(category=>categories.includes(category)))) || [], [data, query, workspace, team, role, categories]);
  return <main className="mx-auto w-full max-w-7xl space-y-5 p-4 md:p-8">
    <div><h1 className="text-2xl font-semibold">People directory</h1><p className="text-muted-foreground">Explore registered users across all workspaces available to your account, including people without a workspace.</p></div>
    <div className="flex flex-wrap gap-3"><Link to="/pms">Workspaces</Link><Link to="/pms/teams?manage=1">Manage workspace teams</Link></div>
    {error ? <div role="alert">{error} <Button onClick={() => setAttempt(a => a + 1)}>Retry</Button></div> : !data ? <p role="status">Loading people…</p> : <>
      <div className="flex flex-wrap gap-3">
        <Input className="max-w-sm" aria-label="Search people" placeholder="Search name or email" value={query} onChange={e => setQuery(e.target.value)} />
        <NativeSelect className="rounded border p-2" aria-label="Workspace filter" value={workspace} onChange={e => { setWorkspace(e.target.value); setTeam(""); }}><option value="">All workspaces</option>{data.workspaces.map(w => <option key={w.id} value={w.id}>{w.name}</option>)}</NativeSelect>
        <NativeSelect className="rounded border p-2" aria-label="Team filter" value={team} onChange={e => setTeam(e.target.value)}><option value="">All teams</option>{teams.map(t => <option key={t.id} value={t.id}>{t.name} · {data.workspaces.find(w => w.id === t.workspace_id)?.name}</option>)}</NativeSelect>
        <NativeSelect className="rounded border p-2" aria-label="Role filter" value={role} onChange={e => setRole(e.target.value)}><option value="">All roles</option>{[...new Set(data.items.map(p => p.role))].sort().map(r => <option key={r}>{r}</option>)}</NativeSelect>
        <Button variant="outline" onClick={() => { setQuery(""); setWorkspace(""); setTeam(""); setRole(""); setCategories([]); }}>Clear filters</Button>
      </div>
      <EmployeeCategories value={categories} onChange={setCategories} options={[...new Set(data.items.flatMap(person=>person.work_categories || []))]}/>
      <p role="status">{people.length} of {data.total} users</p>
      <div className="space-y-2 rounded-lg border p-3"><div className="flex flex-wrap items-center gap-2"><label className="text-sm">Load saved directory view<NativeSelect className="ml-2 rounded border bg-background p-2" value="" onChange={e => { const view = savedViews.find(v => v.name === e.target.value); if (view) { setQuery(view.query); setWorkspace(view.workspace); setTeam(view.team); setRole(view.role); setCategories(view.categories || []); } }}><option value="">Choose a saved view</option>{savedViews.map(v => <option key={v.name}>{v.name}</option>)}</NativeSelect></label><CompactForm className="flex flex-wrap gap-2" onSubmit={e => { e.preventDefault(); const next = [...savedViews.filter(v => v.name !== viewName.trim()), { name: viewName.trim(), query, workspace, team, role, categories }].slice(-20); try { localStorage.setItem(viewKey, JSON.stringify(next)); setSavedViews(next); setViewName(""); setViewMessage("Directory view saved on this browser."); } catch { setViewMessage("This browser could not save the view. Your filters are unchanged."); } }}><Input aria-label="Directory view name" placeholder="Save current filters as…" required maxLength={60} value={viewName} onChange={e => setViewName(e.target.value)} /><Button variant="outline" disabled={!viewName.trim()}>Save directory view</Button></CompactForm></div>{viewMessage && <p role="status" className="text-xs text-muted-foreground">{viewMessage}</p>}{savedViews.length > 0 && <details><summary className="cursor-pointer text-xs">Manage saved views</summary>{savedViews.map(v => <div key={v.name} className="mt-2 flex gap-3 text-sm"><span>{v.name}</span><button className="underline" onClick={() => { const next = savedViews.filter(item => item.name !== v.name); try { localStorage.setItem(viewKey, JSON.stringify(next)); setSavedViews(next); } catch { setViewMessage("Could not remove saved view."); } }}>Remove</button></div>)}</details>}</div>
      <GroupedRecords scope="people-directory" hideSearch items={people} gridClassName="grid gap-2.5 lg:grid-cols-2 xl:grid-cols-3" fields={[
        {id:"role",label:"Role",value:person=>person.role.replace(/_/g," ")},
        {id:"status",label:"Status",value:person=>person.is_active?"Active":"Inactive"},
      ]} tableColumns={[
        {id:"name",title:"Person",width:220,accessor:person=>person.name},
        {id:"email",title:"Email",accessor:person=>person.email},
        {id:"categories",title:"Employee categories",accessor:person=>(person.work_categories || []).join(", ")},
        {id:"role",title:"Role",accessor:person=>person.role.replace(/_/g," ")},
        {id:"status",title:"Status",accessor:person=>person.is_active?"Active":"Inactive"},
        {id:"workspaces",title:"Workspaces",accessor:person=>person.workspace_ids.map(id=>data.workspaces.find(workspace=>workspace.id===id)?.name).filter(Boolean).join(", ")||"Unassigned"},
        {id:"teams",title:"Teams",accessor:person=>data.teams.filter(team=>team.member_ids.includes(person.id)).map(team=>team.name).join(", ")||"Unassigned"},
      ]} onOpenRecord={setSelectedPerson} renderItem={p => {
        const workspaces = p.workspace_ids.map(id => ({ id, name: data.workspaces.find(w => w.id === id)?.name })).filter(w => !!w.name);
        const memberTeams = data.teams.filter(t => t.member_ids.includes(p.id));
        return <ProfileListCard key={p.id} name={p.name} photoUrl={p.profile_photo_url}
          location={workspaces[0]?.name} subtitle={<><strong>{p.role.replace(/_/g, " ")}</strong> · {p.email}</>}
          status={{ label: p.is_active ? "Active" : "Inactive", tone: p.is_active ? "positive" : "muted" }}
          onOpen={() => setSelectedPerson(p)}
          tags={[
            ...(p.work_categories || []).map(label=>({label,onClick:()=>setCategories([label])})),
            ...workspaces.slice(0, 2).map(w => ({ label: w.name!, onClick: () => { setWorkspace(String(w.id)); setTeam(""); } })),
            ...memberTeams.slice(0, 2).map(t => ({ label: t.name, onClick: () => { setWorkspace(String(t.workspace_id)); setTeam(String(t.id)); } })),
            ...(workspaces.length + memberTeams.length > 4 ? [{ label: "More memberships", onClick: () => setSelectedPerson(p) }] : []),
          ]}
          actions={<>{p.is_active && <ProfileAction onClick={() => openPerson({ userId: p.id, compactMemberships: true })} label={`Add ${p.name} to workspace or project`}>Add to workspace / project</ProfileAction>}<ProfileAction onClick={() => setSelectedPerson(p)} label={`View profile of ${p.name}`}>View profile</ProfileAction><ProfileAction href={`mailto:${p.email}`} label={`Email ${p.name}`}>Email</ProfileAction></>} />;
      }}/>
      {selectedPerson && <PersonRecordPreview key={selectedPerson.id} record={{ ...selectedPerson, status: selectedPerson.is_active ? "Active" : "Inactive", workspaces: selectedPerson.workspace_ids.map(id => data.workspaces.find(w => w.id === id)).filter(Boolean), teams: data.teams.filter(t => t.member_ids.includes(selectedPerson.id)) }} onClose={() => setSelectedPerson(null)} actions={selectedPerson.is_active && <button onClick={() => openPerson({ userId: selectedPerson.id, compactMemberships: true })}>Add to workspace / project</button>} work={<div><h3 className="mb-2 text-sm font-medium">Workspaces &amp; teams</h3><div className="flex flex-wrap gap-2">
            {selectedPerson.workspace_ids.map(id => <ProfileAction key={id} onClick={() => {setWorkspace(String(id));setTeam("");setSelectedPerson(null);}}>{data.workspaces.find(w => w.id === id)?.name || "Workspace"}</ProfileAction>)}
            {data.teams.filter(t => t.member_ids.includes(selectedPerson.id)).map(t => <ProfileAction key={`team-${t.id}`} onClick={() => {setWorkspace(String(t.workspace_id));setTeam(String(t.id));setSelectedPerson(null);}}>{t.name}</ProfileAction>)}
            {!selectedPerson.workspace_ids.length && <p className="text-sm text-muted-foreground">No workspace membership</p>}
          </div></div>} />}
      {!people.length && <p>No users match these filters.</p>}
    </>}
  </main>;
}
