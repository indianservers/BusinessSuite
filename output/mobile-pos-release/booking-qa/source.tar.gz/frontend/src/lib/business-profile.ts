import catalog from '../../../backend/app/core/business_profiles.json';

export type TermKey = keyof typeof catalog.terms;
export type TermPair = [string, string];
export type ProfileValues = { business_type?: string; terms?: Partial<Record<TermKey, TermPair>> };
export type ResolvedProfile = { business_type: string; terms: Record<TermKey, TermPair> };
export { catalog as businessProfileCatalog };

/** Explicit concept keys only: never replace arbitrary user-authored text. */
export function resolveBusinessProfile(layers: ProfileValues[]): ResolvedProfile {
  let business_type = 'general';
  let overrides: ProfileValues['terms'] = {};
  for (const layer of layers) {
    business_type = layer.business_type ?? business_type;
    overrides = { ...overrides, ...layer.terms };
  }
  const template = catalog.profiles.find(profile => profile.id === business_type) ?? catalog.profiles[0];
  return { business_type, terms: { ...catalog.terms, ...template.terms, ...overrides } as ResolvedProfile['terms'] };
}

export function profileTerm(profile: ResolvedProfile, key: TermKey, plural = false): string {
  return profile.terms[key][plural ? 1 : 0];
}

/** Translate built-in metadata by semantic field ID, preserving customized captions. */
export function businessFieldLabel(profile: ResolvedProfile, field: string, fallback: string): string {
  const key = (catalog.field_terms as Record<string, TermKey>)[field];
  if (!key) return fallback;
  const [singular, plural] = catalog.terms[key];
  if (fallback === singular) return profile.terms[key][0];
  if (fallback === plural) return profile.terms[key][1];
  for (const suffix of [' ID', ' Name', ' name', ' Code', ' code', ' Reference', ' reference', ' Date', ' date', ' Time', ' time']) {
    if (fallback === singular + suffix) return profile.terms[key][0] + suffix;
  }
  return fallback;
}

/** Only known application routes receive labels; record names and custom menus stay intact. */
export function businessRouteLabel(profile: ResolvedProfile, path: string, fallback: string): string {
  const terms: Record<string, TermKey> = {
    '/crm/customers': 'customer', '/srm/customers': 'customer',
    '/crm/services': 'service', '/srm/services': 'service',
    '/hrms/employees': 'employee', '/hrms/employee-directory': 'employee',
    '/pms/projects': 'project', '/srm/appointments': 'appointment',
  };
  const key = terms[path.split(/[?#]/)[0].replace(/\/$/, '')];
  if (!key) return fallback;
  const [singular, plural] = catalog.terms[key];
  if (fallback === singular || fallback === plural) return profileTerm(profile, key, fallback === plural);
  if (key === 'employee' && /^Employee [Dd]irectory$/.test(fallback)) return profileTerm(profile, key) + fallback.slice(singular.length);
  return fallback;
}
