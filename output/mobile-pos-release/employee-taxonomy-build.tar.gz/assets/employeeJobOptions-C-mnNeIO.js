import{a as t}from"./index-nEQsN5cn.js";async function n(){const{data:a}=await t.get("/employees/reporting-managers");return a}export{n as l};
