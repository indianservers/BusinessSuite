import{s as i}from"./index-C87NarFY.js";function o(t){return i(t)||"/dashboard"}export{o as l};
