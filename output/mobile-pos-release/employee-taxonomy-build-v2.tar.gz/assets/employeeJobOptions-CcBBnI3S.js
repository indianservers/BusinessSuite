import{a as t}from"./index-C87NarFY.js";async function n(){const{data:a}=await t.get("/employees/reporting-managers");return a}export{n as l};
