import{s as i}from"./index-AjsJokwP.js";function o(t){return i(t)||"/dashboard"}export{o as l};
