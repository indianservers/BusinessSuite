import{s as i}from"./index-CCJ_jF2I.js";function o(t){return i(t)||"/dashboard"}export{o as l};
