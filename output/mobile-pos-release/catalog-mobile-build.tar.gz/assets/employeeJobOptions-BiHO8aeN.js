import{a as t}from"./index-BoSP9NNv.js";async function n(){const{data:a}=await t.get("/employees/reporting-managers");return a}export{n as l};
