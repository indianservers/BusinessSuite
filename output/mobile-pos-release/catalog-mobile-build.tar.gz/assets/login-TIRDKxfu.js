import{s as i}from"./index-BoSP9NNv.js";function o(t){return i(t)||"/dashboard"}export{o as l};
