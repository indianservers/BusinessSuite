import{s as i}from"./index-CoKrASGa.js";function o(t){return i(t)||"/dashboard"}export{o as l};
