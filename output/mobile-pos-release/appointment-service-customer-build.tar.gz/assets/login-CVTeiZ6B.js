import{s as i}from"./index-BLjyvPLL.js";function o(t){return i(t)||"/dashboard"}export{o as l};
