import{s as i}from"./index-BcBOcFMZ.js";function o(t){return i(t)||"/dashboard"}export{o as l};
