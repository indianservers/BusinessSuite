import{ag as n}from"./index-BcBOcFMZ.js";function m({name:s,plural:e=!1}){const{term:r}=n();return r(s,e)}export{m as B};
